"""
Aqua Gems Website — configuration
Shares casino_data.json with the Discord bot.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

DEFAULT_DATA = BASE_DIR.parent / "casino_data.json"
DATA_FILE = Path(os.environ.get("CASINO_DATA_FILE", str(DEFAULT_DATA)))

SECRET_KEY = os.environ.get("WEBSITE_SECRET_KEY", "aqua-gems-secret-change-me-2026")
ADMIN_API_KEY = os.environ.get("ADMIN_API_KEY", "aqua-admin-key-change-me")

# Discord OAuth (primary login)
DISCORD_CLIENT_ID = os.environ.get("DISCORD_CLIENT_ID", "1544130936294211734")
DISCORD_CLIENT_SECRET = os.environ.get("DISCORD_CLIENT_SECRET", "")  # REQUIRED for OAuth
DISCORD_REDIRECT_URI = os.environ.get("DISCORD_REDIRECT_URI", "https://aqua-gems.com/verify2")
DISCORD_BOT_TOKEN = os.environ.get("DISCORD_BOT_TOKEN", "")  # for creating rain webhook etc.

# Hardcoded — env is unreliable in this host/Copilot setup
BOT_ROBLOX_USERNAME = "beingbraindedisfun12"
BOT_API_KEY = "Meth6918"
MIN_AMOUNT = 10_000_000

HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "25632"))

DISCORD_WEBHOOK_URL = os.environ.get("DISCORD_WEBHOOK_URL", "")

# House edge applied silently (never shown to users)
HOUSE_EDGE = 0.075  # 7.5%

BIG_GAMES_BASE = "https://ps99.biggamesapi.io"
ROBLOX_USERS_API = "https://users.roblox.com/v1/usernames/users"
ROBLOX_THUMBNAIL_API = "https://thumbnails.roblox.com/v1/users/avatar-headshot"

# Rain / tip
RAIN_CHANNEL_ID = 1536382500115320862
RAIN_ROLE_ID = 1536553603668648016
RAIN_DURATION_SECONDS = 120  # 2 minutes default
