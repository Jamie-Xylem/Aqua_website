--[[
  Aqua Gems — Auto Trade Bot
  Bot account: beingbraindedisfun12

  - Deposits: trade only (Huges/Titanics in pets_db)
  - Withdraws: trade only (poll API every 60s)
  - Accepts trades when the right pets are present
  - Runs deposit scan + withdraw poll at the same time
]]

local CONFIG = {
    API_BASE = "https://aqua-gems.com", -- no trailing slash
    BOT_KEY = "Meth6918",
    BOT_USERNAME = "beingbraindedisfun12",
    SCAN_INTERVAL = 0.8,          -- trade UI scan
    WITHDRAW_POLL_SEC = 60,       -- pending withdraws every minute
    ACCEPT_RETRIES = 8,
}

local Players = game:GetService("Players")
local LP = Players.LocalPlayer
local HttpService = game:GetService("HttpService")
local RS = game:GetService("ReplicatedStorage")
local VIM = game:GetService("VirtualInputManager")

local function parentGui(gui)
    local ok = pcall(function() gui.Parent = game:GetService("CoreGui") end)
    if not ok or not gui.Parent then
        gui.Parent = LP:WaitForChild("PlayerGui")
    end
end

local gui = Instance.new("ScreenGui")
gui.Name = "AquaBotDiag"
gui.ResetOnSpawn = false
gui.DisplayOrder = 99999
gui.IgnoreGuiInset = true
parentGui(gui)

local frame = Instance.new("Frame")
frame.Size = UDim2.new(0, 360, 0, 280)
frame.Position = UDim2.new(0, 10, 0.32, 0)
frame.BackgroundColor3 = Color3.fromRGB(8, 12, 24)
frame.BackgroundTransparency = 0.05
frame.BorderSizePixel = 0
frame.Active = true
frame.Draggable = true
frame.Parent = gui
Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 14)
local stroke = Instance.new("UIStroke", frame)
stroke.Color = Color3.fromRGB(91, 140, 255)
stroke.Thickness = 2

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -50, 0, 28)
title.Position = UDim2.new(0, 12, 0, 8)
title.BackgroundTransparency = 1
title.Text = "AQUA BOT · " .. CONFIG.BOT_USERNAME
title.Font = Enum.Font.GothamBold
title.TextSize = 16
title.TextColor3 = Color3.fromRGB(91, 140, 255)
title.TextXAlignment = Enum.TextXAlignment.Left
title.Parent = frame

local pulse = Instance.new("Frame")
pulse.Size = UDim2.new(0, 14, 0, 14)
pulse.Position = UDim2.new(1, -28, 0, 14)
pulse.BackgroundColor3 = Color3.fromRGB(60, 255, 140)
pulse.BorderSizePixel = 0
pulse.Parent = frame
Instance.new("UICorner", pulse).CornerRadius = UDim.new(1, 0)

local body = Instance.new("TextLabel")
body.Size = UDim2.new(1, -20, 1, -48)
body.Position = UDim2.new(0, 10, 0, 40)
body.BackgroundTransparency = 1
body.Text = "Booting…"
body.Font = Enum.Font.Code
body.TextSize = 12
body.TextColor3 = Color3.fromRGB(220, 230, 245)
body.TextXAlignment = Enum.TextXAlignment.Left
body.TextYAlignment = Enum.TextYAlignment.Top
body.TextWrapped = true
body.Parent = frame

local logLines = {}
local function ui(msg)
    table.insert(logLines, os.date("%H:%M:%S") .. " " .. tostring(msg))
    while #logLines > 14 do table.remove(logLines, 1) end
    body.Text = table.concat(logLines, "\n")
end

task.spawn(function()
    local on = true
    while gui.Parent do
        pulse.BackgroundColor3 = on and Color3.fromRGB(60, 255, 140) or Color3.fromRGB(20, 40, 30)
        on = not on
        task.wait(0.5)
    end
end)

ui("Script loaded · " .. (LP and LP.Name or "?"))
ui("Bot target: " .. CONFIG.BOT_USERNAME)

-- =========================================================
-- HTTP
-- =========================================================
local function rawRequest(opts)
    local fns = {
        function() return request(opts) end,
        function() return http_request(opts) end,
        function() return syn and syn.request and syn.request(opts) end,
        function() return fluxus and fluxus.request and fluxus.request(opts) end,
        function() return http and http.request and http.request(opts) end,
        function() return (getgenv and getgenv().request) and getgenv().request(opts) end,
    }
    for _, fn in ipairs(fns) do
        local ok, res = pcall(fn)
        if ok and res and (res.Body or res.body) then
            return {
                StatusCode = res.StatusCode or res.Status or res.status_code,
                Body = res.Body or res.body,
            }
        end
    end
    return nil
end

local function http(method, path, bodyTable)
    local url = CONFIG.API_BASE .. path
    local opts = {
        Url = url,
        Method = method,
        Headers = {
            ["X-Bot-Key"] = CONFIG.BOT_KEY,
            ["Content-Type"] = "application/json",
        },
    }
    if bodyTable then
        opts.Body = HttpService:JSONEncode(bodyTable)
    end
    local res = rawRequest(opts)
    if not res then
        ui("HTTP FAIL — no request fn")
        return nil
    end
    local code = tonumber(res.StatusCode) or 0
    local ok, data = pcall(function()
        return HttpService:JSONDecode(res.Body)
    end)
    if not ok then
        ui("Bad JSON " .. tostring(code) .. ": " .. string.sub(tostring(res.Body), 1, 50))
        return nil
    end
    if code == 401 then
        ui("401 unauthorized — BOT_KEY mismatch")
    end
    return data
end

-- =========================================================
-- Whitelist
-- =========================================================
ui("Testing API…")
local wl = http("GET", "/api/bot/pet_whitelist")
local WHITELIST = {}
if wl and wl.ok and wl.names then
    for _, n in ipairs(wl.names) do WHITELIST[n:lower()] = true end
    ui("API OK · " .. #wl.names .. " pets")
else
    ui("API FAIL — check key/URL")
    ui("Key: " .. string.sub(CONFIG.BOT_KEY, 1, 6) .. "…")
    -- keep trying in background
    task.spawn(function()
        while true do
            task.wait(30)
            local w2 = http("GET", "/api/bot/pet_whitelist")
            if w2 and w2.ok and w2.names then
                WHITELIST = {}
                for _, n in ipairs(w2.names) do WHITELIST[n:lower()] = true end
                ui("API recovered · " .. #w2.names)
                break
            end
        end
    end)
end

local function isAllowed(name)
    local n = (name or ""):lower()
    if not (n:find("huge") or n:find("titanic")) then return false end
    if next(WHITELIST) == nil then
        -- if whitelist empty (API down), still allow any huge/titanic name
        return true
    end
    return WHITELIST[n] == true
end

-- =========================================================
-- Click / Accept
-- =========================================================
local function clickBtn(btn)
    pcall(function()
        if getconnections then
            for _, c in ipairs(getconnections(btn.MouseButton1Click) or {}) do
                pcall(function() c:Fire() end)
            end
        end
    end)
    pcall(function() if firesignal then firesignal(btn.MouseButton1Click) end end)
    pcall(function()
        local p, s = btn.AbsolutePosition, btn.AbsoluteSize
        VIM:SendMouseButtonEvent(p.X + s.X/2, p.Y + s.Y/2, 0, true, game, 0)
        task.wait(0.04)
        VIM:SendMouseButtonEvent(p.X + s.X/2, p.Y + s.Y/2, 0, false, game, 0)
    end)
end

local function tryAccept()
    local found = false
    pcall(function()
        for _, d in ipairs(LP.PlayerGui:GetDescendants()) do
            if d:IsA("TextButton") or d:IsA("ImageButton") then
                local t = ((d.Text or "") .. " " .. d.Name):lower()
                if (t:find("accept") or t:find("confirm") or t:find("ok")) and d.AbsoluteSize.X > 6 and d.Visible then
                    clickBtn(d)
                    found = true
                end
            end
        end
    end)
    pcall(function()
        for _, r in ipairs(RS:GetDescendants()) do
            if r:IsA("RemoteEvent") or r:IsA("RemoteFunction") then
                local n = r.Name:lower()
                if n:find("trade") and (n:find("accept") or n:find("confirm") or n:find("process")) then
                    pcall(function()
                        if r:IsA("RemoteEvent") then
                            r:FireServer()
                            r:FireServer(true)
                        else
                            r:InvokeServer()
                            r:InvokeServer(true)
                        end
                    end)
                    found = true
                end
            end
        end
    end)
    return found
end

local function tryDecline()
    pcall(function()
        for _, d in ipairs(LP.PlayerGui:GetDescendants()) do
            if d:IsA("TextButton") then
                local t = (d.Text or ""):lower()
                if t:find("decline") or t:find("cancel") or t:find("reject") then
                    clickBtn(d)
                end
            end
        end
    end)
end

local function forceAcceptBurst()
    for i = 1, CONFIG.ACCEPT_RETRIES do
        tryAccept()
        task.wait(0.25)
    end
end

-- =========================================================
-- Deposit trade scan
-- =========================================================
local lastHash, cool = "", 0

local function scanTrade()
    if tick() < cool then return end
    local pets, seen = {}, {}
    pcall(function()
        for _, d in ipairs(LP.PlayerGui:GetDescendants()) do
            if d:IsA("TextLabel") or d:IsA("TextButton") then
                local t = (d.Text or ""):match("^%s*(.-)%s*$") or ""
                local low = t:lower()
                if #t > 3 and (low:find("huge") or low:find("titanic"))
                    and not seen[low]
                    and not low:find("accept") and not low:find("decline")
                    and not low:find("cancel") and not low:find("confirm") then
                    seen[low] = true
                    table.insert(pets, t)
                end
            end
        end
    end)
    if #pets == 0 then return end

    local hash = table.concat(pets, "|")
    if hash == lastHash then
        -- still in same trade UI — keep hammering Accept in case user just added items
        forceAcceptBurst()
        return
    end
    ui("TRADE: " .. hash:sub(1, 48))

    local allOk = true
    for _, p in ipairs(pets) do
        if not isAllowed(p) then
            ui("Refuse: " .. p)
            tryDecline()
            lastHash = hash
            cool = tick() + 3
            allOk = false
            break
        end
    end
    if not allOk then return end

    local other = "unknown"
    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= LP then
            other = plr.Name
            break
        end
    end
    ui("Trader: " .. other)

    -- Credit first, then ALWAYS accept if API ok (or if whitelist empty / offline credit fails, still accept valid pets)
    local res = http("POST", "/api/bot/deposit", {
        roblox_user = other,
        pets = pets,
        bot = CONFIG.BOT_USERNAME,
    })

    if res and res.ok then
        ui("CREDITED " .. tostring(res.credit_fmt or res.credit))
        forceAcceptBurst()
        ui("Accepted deposit trade")
        lastHash = hash
        cool = tick() + 5
    else
        local err = tostring(res and res.error or "api fail")
        ui("NO CREDIT: " .. err:sub(1, 40))
        -- If pets are allowed locally, still accept so trade completes; site can be fixed later
        if isAllowed(pets[1]) then
            ui("Local OK → force accept")
            forceAcceptBurst()
            lastHash = hash
            cool = tick() + 5
        else
            tryDecline()
            lastHash = hash
            cool = tick() + 3
        end
    end
end

-- =========================================================
-- Pending withdraws (every minute) + accept outbound trades
-- =========================================================
local pendingWithdraws = {}
local lastWithdrawPoll = 0

local function pollWithdraws()
    local res = http("GET", "/api/bot/pending_withdraws")
    if not (res and res.ok and res.withdraws) then
        ui("Withdraw poll fail")
        return
    end
    pendingWithdraws = res.withdraws
    local n = #pendingWithdraws
    if n > 0 then
        ui("Pending WDs: " .. n)
        for _, w in ipairs(pendingWithdraws) do
            ui("  → " .. tostring(w.roblox_user) .. " " .. tostring(w.amount_fmt or w.amount))
        end
    end
end

local function markWithdrawDone(wid)
    local res = http("POST", "/api/bot/withdraw_claimed", { id = wid })
    if res and res.ok then
        ui("WD claimed " .. tostring(wid):sub(1, 8))
    end
end

-- When we are trading WITH a user who has a pending withdraw, accept + claim
local function handleWithdrawTrade()
    if #pendingWithdraws == 0 then return end
    local others = {}
    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= LP then
            others[plr.Name:lower()] = plr.Name
        end
    end
    for _, w in ipairs(pendingWithdraws) do
        local target = (w.roblox_user or ""):lower()
        if target ~= "" and others[target] then
            ui("WD trade with " .. others[target])
            forceAcceptBurst()
            -- after accept attempts, mark claimed (bot must put items in trade manually or via game tools)
            markWithdrawDone(w.id)
            task.wait(1)
        end
    end
end

-- =========================================================
-- Main loops (deposit + withdraw concurrent)
-- =========================================================
task.spawn(function()
    while gui.Parent do
        pcall(scanTrade)
        pcall(handleWithdrawTrade)
        task.wait(CONFIG.SCAN_INTERVAL)
    end
end)

task.spawn(function()
    pollWithdraws()
    while gui.Parent do
        task.wait(CONFIG.WITHDRAW_POLL_SEC)
        pcall(pollWithdraws)
    end
end)

ui("Ready. Trade only · WD poll 60s")
ui("Drag panel if it covers UI.")
