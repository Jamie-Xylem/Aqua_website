"""Aqua Gems Casino — Blackjack"""
import asyncio
import random

import discord
from discord import app_commands

from bot_instance import tree, game_cooldown
from config import MIN_GAME_AMOUNT
from data import DATA, save_data, ensure_user, add_history, parse_amount, format_amount
from utils import (
    verification_check,
    normal_embed,
    send_log,
    update_milestone_roles,
    game_paused,
)


SUITS = ["♤", "♡", "♧", "♢"]


def card_rank(card):
    return card[0] if isinstance(card, tuple) else card


def card_text(card):
    rank = card_rank(card)
    rank_name = {11: "A", 10: "10"}.get(rank, str(rank))
    suit = card[1] if isinstance(card, tuple) else ""
    return f"{rank_name} {suit}".strip()


def blackjack_total(cards):
    ranks = [card_rank(card) for card in cards]
    total = sum(ranks)
    aces = ranks.count(11)
    while total > 21 and aces:
        total -= 10
        aces -= 1
    return total


def new_deck():
    # A full 52-card deck with suits randomly distributed.
    ranks = [2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 11]
    deck = [(rank, suit) for suit in SUITS for rank in ranks]
    random.shuffle(deck)
    return deck


class AnimatedBlackjackView(discord.ui.View):
    def __init__(self, owner_id, amount, deck, player, dealer):
        super().__init__(timeout=120)
        self.owner_id = owner_id
        self.amount = amount
        self.deck = deck
        self.player = player
        self.dealer = dealer
        self.finished = False
        self.doubled = False

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "❌ This blackjack game isn't yours.", ephemeral=True
            )
            return False
        if await game_paused(interaction):
            return False
        return True

    def build_embed(
        self,
        title="🃏 Blackjack Table",
        description="",
        reveal_dealer=False,
        status=None,
        status_colour=None,
    ):
        embed = normal_embed(
            title, description, status_colour or discord.Colour.blurple()
        )

        p_cards = " ".join(f"`{card_text(x)}`" for x in self.player) if self.player else "—"
        embed.add_field(
            name="👤 Your Hand",
            value=f"Cards: {p_cards}\nTotal Value: **{blackjack_total(self.player)}**",
            inline=True,
        )

        if reveal_dealer or self.finished:
            d_cards = " ".join(f"`{card_text(x)}`" for x in self.dealer) if self.dealer else "—"
            embed.add_field(
                name="🤖 Dealer Hand",
                value=f"Cards: {d_cards}\nTotal Value: **{blackjack_total(self.dealer)}**",
                inline=True,
            )
        elif self.dealer:
            embed.add_field(
                name="🤖 Dealer Hand",
                value=f"Cards: `{card_text(self.dealer[0])}` `🎴`\nTotal Value: **?**",
                inline=True,
            )
        else:
            embed.add_field(
                name="🤖 Dealer Hand", value="Cards: —\nTotal Value: **?**", inline=True
            )

        embed.add_field(
            name="💰 Wager", value=f"**{format_amount(self.amount)}**", inline=False
        )

        if status:
            embed.add_field(name="🎰 Status", value=status, inline=False)

        embed.set_footer(text="Aqua Gems")
        return embed

    def _disable_double(self):
        for child in self.children:
            if isinstance(child, discord.ui.Button) and child.custom_id == "bj_double":
                child.disabled = True

    @discord.ui.button(label="Hit", emoji="🃏", style=discord.ButtonStyle.primary, custom_id="bj_hit")
    async def hit(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(
            embed=self.build_embed(description="🎴 Drawing a card..."),
            view=None,
        )
        await asyncio.sleep(0.8)

        if not self.deck:
            self.deck = new_deck()
        self.player.append(self.deck.pop())
        self._disable_double()

        if blackjack_total(self.player) > 21:
            await self.finish(interaction, forced_result="loss")
            return

        await interaction.edit_original_response(
            embed=self.build_embed(status="Card drawn. What's your next move?"),
            view=self,
        )

    @discord.ui.button(label="Stand", emoji="✋", style=discord.ButtonStyle.success, custom_id="bj_stand")
    async def stand(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.finish(interaction, forced_result=None)

    @discord.ui.button(
        label="Double Down",
        emoji="💵",
        style=discord.ButtonStyle.secondary,
        custom_id="bj_double",
    )
    async def double_down(self, interaction: discord.Interaction, button: discord.ui.Button):
        if len(self.player) != 2:
            await interaction.response.send_message(
                "❌ You can only double down before hitting.", ephemeral=True
            )
            return

        user = ensure_user(self.owner_id)
        if user["balance"] < self.amount:
            await interaction.response.send_message(
                "❌ Insufficient balance to double down.", ephemeral=True
            )
            return

        user["balance"] -= self.amount
        self.amount *= 2
        self.doubled = True
        save_data()

        await interaction.response.edit_message(
            embed=self.build_embed(
                description="💵 Doubling down — drawing your final card..."
            ),
            view=None,
        )
        await asyncio.sleep(0.8)

        if not self.deck:
            self.deck = new_deck()
        self.player.append(self.deck.pop())

        if blackjack_total(self.player) > 21:
            await self.finish(interaction, forced_result="loss")
            return

        await self.finish(interaction, forced_result=None)

    async def finish(self, interaction: discord.Interaction, forced_result):
        self.finished = True

        reveal = self.build_embed(
            description="🎴 Dealer is revealing their hidden card...",
            reveal_dealer=True,
        )
        if not interaction.response.is_done():
            await interaction.response.edit_message(embed=reveal, view=None)
        else:
            await interaction.edit_original_response(embed=reveal, view=None)

        await asyncio.sleep(1.0)

        # Standard Dealer Logic: Dealer hits on under 17 and stands on 17+
        if forced_result != "loss":
            while blackjack_total(self.dealer) < 17:
                if not self.deck:
                    self.deck = new_deck()
                self.dealer.append(self.deck.pop())
                await interaction.edit_original_response(
                    embed=self.build_embed(
                        description="🎴 Dealer hits another card...",
                        reveal_dealer=True,
                    ),
                    view=None,
                )
                await asyncio.sleep(0.9)

        player_total = blackjack_total(self.player)
        dealer_total = blackjack_total(self.dealer)
        user = ensure_user(self.owner_id)

        if forced_result == "loss" or player_total > 21:
            result = "Loss"
        elif dealer_total > 21 or player_total > dealer_total:
            result = "Win"
        elif player_total == dealer_total:
            result = "Push"
        else:
            result = "Loss"

        if "global_stats" not in DATA:
            DATA["global_stats"] = {}
        if "bot_game_profit" not in DATA["global_stats"]:
            DATA["global_stats"]["bot_game_profit"] = 0

        if result == "Win":
            payout = int(self.amount * 1.95)
            user["balance"] += payout
            DATA["global_stats"]["bot_game_profit"] -= self.amount * 0.95
            status = (
                f"🏆 **You Win!** ({player_total} vs {dealer_total})\n"
                f"Payout: **{format_amount(payout)}**"
            )
            colour = discord.Colour.green()
        elif result == "Push":
            payout = self.amount
            user["balance"] += payout
            status = (
                f"🟡 **Push!** ({player_total} vs {dealer_total})\nWager returned."
            )
            colour = discord.Colour.orange()
        else:
            payout = 0
            DATA["global_stats"]["bot_game_profit"] += self.amount
            status = (
                f"💀 **You Lost!** ({player_total} vs {dealer_total})\n"
                f"Lost: **{format_amount(self.amount)}**"
            )
            colour = discord.Colour.red()

        user["wagered"] = user.get("wagered", 0) + self.amount
        if user.get("to_wager", 0) > 0:
            user["to_wager"] = max(0, user["to_wager"] - self.amount)

        add_history(self.owner_id, "Blackjack", self.amount, result)
        save_data()

        try:
            await update_milestone_roles(interaction.user)
        except Exception:
            pass

        final_embed = self.build_embed(
            reveal_dealer=True, status=status, status_colour=colour
        )
        await interaction.edit_original_response(embed=final_embed, view=None)

        try:
            await send_log(
                interaction.guild,
                "🃏 Blackjack Finished",
                f"Player: {interaction.user.mention}\n"
                f"Amount: **{format_amount(self.amount)}**\n"
                f"Result: **{result}**",
                colour,
            )
        except Exception:
            pass

        self.stop()


@tree.command(name="blackjack", description="Play animated Blackjack.")
@game_cooldown()
@app_commands.describe(amount="Example: 10m or 1b")
async def blackjack(interaction: discord.Interaction, amount: str):
    if not await verification_check(interaction):
        return

    if await game_paused(interaction):
        return

    parsed = parse_amount(amount)
    if parsed is None or parsed < MIN_GAME_AMOUNT:
        await interaction.response.send_message(
            "❌ Minimum amount is **10M**.", ephemeral=True
        )
        return

    user = ensure_user(interaction.user.id)
    if user["balance"] < parsed:
        await interaction.response.send_message(
            "❌ Insufficient balance.", ephemeral=True
        )
        return

    user["balance"] -= parsed
    save_data()

    await interaction.response.send_message(
        embed=normal_embed(
            "🃏 Blackjack Table",
            "<a:BlackjackDealing:1542837340458975242>",
            discord.Colour.blurple(),
        )
    )

    try:
        await asyncio.sleep(1.5)

        deck = new_deck()
        player = [deck.pop(), deck.pop()]
        dealer = [deck.pop(), deck.pop()]

        view = AnimatedBlackjackView(
            interaction.user.id, parsed, deck, player, dealer
        )

        if blackjack_total(player) == 21:
            await view.finish(interaction, forced_result=None)
            return

        await interaction.edit_original_response(
            embed=view.build_embed(description="Choose your move!"),
            view=view,
        )
    except Exception as e:
        print(f"Blackjack deal error: {e}")
        user = ensure_user(interaction.user.id)
        user["balance"] += parsed
        save_data()
        try:
            await interaction.edit_original_response(
                embed=normal_embed(
                    "❌ Blackjack Error",
                    "Something went wrong starting the game. Your balance was refunded.",
                    discord.Colour.red(),
                ),
                view=None,
            )
        except Exception:
            pass
