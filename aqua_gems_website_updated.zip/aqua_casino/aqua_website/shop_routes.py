"""Shop + rakeback route registration."""
import time
from flask import session, request, redirect, url_for, flash, render_template

NAME_COLORS = [
    {"name": "Cyan", "hex": "#2ee6d6", "price": 10_000_000},
    {"name": "Gold", "hex": "#ffc857", "price": 25_000_000},
    {"name": "Red", "hex": "#ff3b4a", "price": 15_000_000},
    {"name": "Purple", "hex": "#7c5cff", "price": 20_000_000},
    {"name": "Lime", "hex": "#3dff9a", "price": 15_000_000},
    {"name": "Pink", "hex": "#ff6bcb", "price": 20_000_000},
]
TEXT_COLORS = [
    {"name": "White", "hex": "#e8ecf4", "price": 5_000_000},
    {"name": "Soft gold", "hex": "#ffe0a0", "price": 15_000_000},
    {"name": "Ice", "hex": "#b8e0ff", "price": 15_000_000},
    {"name": "Mint", "hex": "#b8ffe0", "price": 15_000_000},
]
BORDERS = [
    {"id": "none", "name": "None", "color": "transparent", "price": 0},
    {"id": "gold", "name": "Gold", "color": "#ffc857", "price": 30_000_000},
    {"id": "red", "name": "Red", "color": "#ff3b4a", "price": 25_000_000},
    {"id": "cyan", "name": "Cyan", "color": "#2ee6d6", "price": 25_000_000},
    {"id": "rainbow", "name": "Rainbow", "color": "#ff00aa", "price": 75_000_000},
]
RB_RATES = {"hourly": 0.02, "daily": 0.05, "weekly": 0.08, "monthly": 0.12}
RB_SECONDS = {"hourly": 3600, "daily": 86400, "weekly": 604800, "monthly": 2592000}
RB_KEYS = {
    "hourly": "wagered_hour",
    "daily": "wagered_day",
    "weekly": "wagered_week",
    "monthly": "wagered_month",
}


def register_shop_routes(app, *, get_data, save_data, ensure_user, _require_user,
                         _refresh_session_balance, format_amount, user_level, HOUSE_EDGE):

    def _rb_amount(user, period):
        w = int(user.get(RB_KEYS[period]) or 0)
        return int(w * HOUSE_EDGE * RB_RATES[period])

    @app.route("/shop")
    def shop_page():
        return render_template(
            "shop.html",
            name_colors=[{**c, "price_fmt": format_amount(c["price"])} for c in NAME_COLORS],
            text_colors=[{**c, "price_fmt": format_amount(c["price"])} for c in TEXT_COLORS],
            borders=[{**b, "price_fmt": format_amount(b["price"])} for b in BORDERS],
        )

    @app.route("/shop/buy", methods=["POST"])
    def shop_buy():
        uid, user = _require_user()
        if not uid or not session.get("roblox"):
            flash("Verify first", "error")
            return redirect(url_for("shop_page"))
        item = request.form.get("item")
        value = (request.form.get("value") or "").strip()
        data = get_data()
        user = ensure_user(uid, data)
        price = 0
        if item == "name_change":
            price = 50_000_000
            if not value or len(value) > 20:
                flash("Invalid name", "error")
                return redirect(url_for("shop_page"))
        elif item == "name_color":
            match = next((c for c in NAME_COLORS if c["hex"] == value), None)
            if not match:
                flash("Unknown color", "error")
                return redirect(url_for("shop_page"))
            price = match["price"]
        elif item == "text_color":
            match = next((c for c in TEXT_COLORS if c["hex"] == value), None)
            if not match:
                flash("Unknown color", "error")
                return redirect(url_for("shop_page"))
            price = match["price"]
        elif item == "avatar_border":
            match = next((b for b in BORDERS if b["id"] == value), None)
            if not match:
                flash("Unknown border", "error")
                return redirect(url_for("shop_page"))
            price = match["price"]
        elif item == "custom_pfp":
            price = 100_000_000
            if not value.startswith("http"):
                flash("Need image URL", "error")
                return redirect(url_for("shop_page"))
        else:
            flash("Unknown item", "error")
            return redirect(url_for("shop_page"))
        if user["balance"] < price:
            flash("Insufficient balance", "error")
            return redirect(url_for("shop_page"))
        user["balance"] -= price
        if item == "name_change":
            user["display_name"] = value
        elif item == "name_color":
            user["name_color"] = value
        elif item == "text_color":
            user["text_color"] = value
        elif item == "avatar_border":
            user["avatar_border"] = value
        elif item == "custom_pfp":
            user["custom_pfp"] = value
        save_data(data)
        _refresh_session_balance(uid, data)
        flash("Purchased!", "success")
        return redirect(url_for("shop_page"))

    @app.route("/rakeback")
    def rakeback_page():
        uid = session.get("user_id")
        if not uid:
            return redirect(url_for("login_discord"))
        data = get_data()
        user = ensure_user(uid, data)
        now = int(time.time())
        starts = user.setdefault("rb_period_start", {})
        claimed = user.setdefault("rakeback_claimed", {})
        periods = []
        for pid, label in [("hourly", "Hourly"), ("daily", "Daily"), ("weekly", "Weekly"), ("monthly", "Monthly")]:
            st = int(starts.get(pid) or 0)
            if now - st >= RB_SECONDS[pid]:
                starts[pid] = now
                user[RB_KEYS[pid]] = 0
                claimed.pop(pid, None)
            amt = _rb_amount(user, pid)
            already = claimed.get(pid)
            periods.append({
                "id": pid,
                "label": label,
                "rate": int(RB_RATES[pid] * 100),
                "amount_fmt": format_amount(amt),
                "wagered_fmt": format_amount(user.get(RB_KEYS[pid], 0)),
                "claimable": amt > 0 and not already,
                "status": "Claimed" if already else ("Nothing yet" if amt <= 0 else "Ready"),
            })
        save_data(data)
        lv = user_level(user.get("wagered", 0))
        return render_template(
            "rakeback.html",
            periods=periods,
            level={
                "level": lv["level"],
                "wagered_fmt": format_amount(lv["wagered"]),
                "next_fmt": format_amount(lv["next_at"]),
            },
        )

    @app.route("/rakeback/claim", methods=["POST"])
    def rakeback_claim():
        uid, user = _require_user()
        if not uid:
            return redirect(url_for("login_discord"))
        period = request.form.get("period")
        if period not in RB_RATES:
            flash("Invalid period", "error")
            return redirect(url_for("rakeback_page"))
        data = get_data()
        user = ensure_user(uid, data)
        claimed = user.setdefault("rakeback_claimed", {})
        if claimed.get(period):
            flash("Already claimed this period", "error")
            return redirect(url_for("rakeback_page"))
        amt = _rb_amount(user, period)
        if amt <= 0:
            flash("Nothing to claim", "error")
            return redirect(url_for("rakeback_page"))
        user["balance"] = user.get("balance", 0) + amt
        claimed[period] = int(time.time())
        user[RB_KEYS[period]] = 0
        user.setdefault("rb_period_start", {})[period] = int(time.time())
        save_data(data)
        _refresh_session_balance(uid, data)
        flash(f"Claimed {format_amount(amt)} rakeback!", "success")
        return redirect(url_for("rakeback_page"))
