# Aqua Gems Website

Bloxflip-style dark casino UI for PS99 diamonds.

## Critical setup

```bash
export DISCORD_CLIENT_ID=1544130936294211734
export DISCORD_CLIENT_SECRET=YOUR_SECRET          # required for Discord login
export DISCORD_REDIRECT_URI=https://aqua-gems.com/verify2
export DISCORD_BOT_TOKEN=YOUR_BOT_TOKEN           # required for rain webhooks
export WEBSITE_SECRET_KEY=random-long-string
export ADMIN_API_KEY=change-me
export CASINO_DATA_FILE=/path/to/shared/casino_data.json
```

Discord app → OAuth2 Redirects must include `https://aqua-gems.com/verify2`.

## Run

```bash
cd aqua_casino/aqua_website
pip install -r requirements.txt
python main.py
```

Port default: **25632**.

## Admin

Login at `/admin` with seeded accounts (e.g. `bergo` / `bergo.92`).
Session uses `is_admin` — Accept/Deny on deposits & withdraws works after login.

## Deposits

Users are instructed to send diamonds to **bergo_92**.

## Rain Discord

Needs `DISCORD_BOT_TOKEN` with permission to manage webhooks in channel `1536382500115320862`.
