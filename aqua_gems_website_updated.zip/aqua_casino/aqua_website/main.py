"""
Aqua Gems Casino — website (aqua-gems.com)
Discord OAuth primary login → /verify2 Roblox link + bio code.
Slots / Coinflip / Roulette / Blackjack · Live chat · Rains · Admin panel
Balances sync with Discord bot via shared casino_data.json
"""
from __future__ import annotations

import hashlib
import json
import os
import secrets
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

_DIR = Path(__file__).resolve().parent
if str(_DIR) not in sys.path:
    sys.path.insert(0, str(_DIR))

os.environ.setdefault("CASINO_DATA_FILE", str(_DIR.parent / "casino_data.json"))

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    jsonify,
    session,
)
import requests as http

# Works with BOTH standalone website config.py and the Discord bot's config.py
try:
    import config as _cfg
except ImportError:
    _cfg = None

def _cfg_get(name, default):
    if _cfg is None:
        return default
    return getattr(_cfg, name, default)

SECRET_KEY = _cfg_get("SECRET_KEY", os.environ.get("WEBSITE_SECRET_KEY", "aqua-gems-secret-change-me"))
HOST = _cfg_get("HOST", os.environ.get("HOST", "0.0.0.0"))
PORT = int(_cfg_get("PORT", os.environ.get("PORT", "25632")))
ADMIN_API_KEY = _cfg_get("ADMIN_API_KEY", os.environ.get("ADMIN_API_KEY", "aqua-admin-key-change-me"))
HOUSE_EDGE = float(_cfg_get("HOUSE_EDGE", 0.075))
DISCORD_CLIENT_ID = str(_cfg_get("DISCORD_CLIENT_ID", os.environ.get("DISCORD_CLIENT_ID", "1544130936294211734")))
DISCORD_CLIENT_SECRET = str(_cfg_get("DISCORD_CLIENT_SECRET", os.environ.get("DISCORD_CLIENT_SECRET", "")))
DISCORD_REDIRECT_URI = str(_cfg_get("DISCORD_REDIRECT_URI", os.environ.get("DISCORD_REDIRECT_URI", "https://aqua-gems.com/verify2")))
DISCORD_BOT_TOKEN = str(_cfg_get("DISCORD_BOT_TOKEN", os.environ.get("DISCORD_BOT_TOKEN") or os.environ.get("DISCORD_TOKEN") or os.environ.get("TOKEN") or ""))
RAIN_CHANNEL_ID = int(_cfg_get("RAIN_CHANNEL_ID", 1536382500115320862))
RAIN_ROLE_ID = int(_cfg_get("RAIN_ROLE_ID", 1536553603668648016))
RAIN_DURATION = int(_cfg_get("RAIN_DURATION_SECONDS", 120))

# Hardcoded — do not require these from bot config
ROBLOX_USERS_API = "https://users.roblox.com/v1/usernames/users"
ROBLOX_THUMBNAIL_API = "https://thumbnails.roblox.com/v1/users/avatar-headshot"

from data_store import (
    get_data,
    save_data,
    ensure_user,
    find_user_by_roblox_id,
    find_user_by_roblox_name,
    find_user_by_discord_id,
    parse_amount,
    format_amount,
    add_history,
    user_level,
)

app = Flask(__name__, template_folder=str(_DIR / "templates"), static_folder=str(_DIR / "static"))
app.secret_key = SECRET_KEY

# ---------------------------------------------------------------------------
# Slots config
# ---------------------------------------------------------------------------
_SLOTS_PATH = _DIR / "static" / "slots" / "slots.json"
with open(_SLOTS_PATH, encoding="utf-8") as _f:
    SLOTS = {s["id"]: s for s in json.load(_f)}
SLOTS_LIST = list(SLOTS.values())

# seed admins into shared data once at import
try:
    _d = get_data()
    _ensure_default_admins(_d)
    save_data(_d)
except Exception:
    pass


# Roulette timing
ROULETTE_ROUND_SECONDS = 90

# Discord webhooks (no bot token needed for posts)
WEBHOOK_DEPOSIT_REQUEST = os.environ.get(
    "WEBHOOK_DEPOSIT_REQUEST",
    "https://discord.com/api/webhooks/1544059780845273280/aFaDtAJwf8KEq-AY61TMNyQOYMkGnMm48OYdEsgqp1i98ZXrc3855eJsAEDsh-mpgNqt",
)
WEBHOOK_DEPOSIT_LOG = os.environ.get(
    "WEBHOOK_DEPOSIT_LOG",
    "https://discord.com/api/webhooks/1544060883376808056/CNjY4pLD457hRKQP8FoL8dFPLMAxqlFMczSdfNeFS3l3L0xpa17v69hPGEEq09IBUsq_",
)
WEBHOOK_WITHDRAW_REQUEST = os.environ.get(
    "WEBHOOK_WITHDRAW_REQUEST",
    "https://discord.com/api/webhooks/1544059611642859710/vJI_GPdxV6oszVrRKzZTLHenslKOxnY0hasdlwp-uAbVfQYUl7LncRawX06nF5PnUWJs",
)
WEBHOOK_WITHDRAW_LOG = os.environ.get(
    "WEBHOOK_WITHDRAW_LOG",
    "https://discord.com/api/webhooks/1544061017519030372/zwqZaSU3zu81pLI2Mvt8aLxsT_zWfqXbZ594UW8siVwaVfpYRbikb1Shy90RqEipantE",
)
UPLOAD_DIR = _DIR / "static" / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Seeded website admin accounts (password SHA-256)
DEFAULT_ADMINS = {
    "bergo": "bergo.92",
    "meth": "meth1810",
    "sweatybot69": "London25",
    "spyderto": "amr999",
}


# Blackjack sessions (in-memory per process)
_bj_sessions: dict = {}



def _discord_webhook(url: str, content: str = "", embeds: list | None = None) -> bool:
    """Post via Discord webhook URL (no bot token). Buttons are not supported on webhooks."""
    if not url or not url.startswith("http"):
        return False
    try:
        body = {}
        if content:
            body["content"] = content[:2000]
        if embeds:
            body["embeds"] = embeds[:10]
        if not body:
            return False
        r = http.post(url, json=body, timeout=12)
        return r.ok or r.status_code == 204
    except Exception:
        return False


def _ensure_default_admins(data: dict) -> None:
    admins = data.setdefault("admins", {})
    for user, pw in DEFAULT_ADMINS.items():
        key = user.lower()
        if key not in admins:
            admins[key] = {
                "password_hash": hashlib.sha256(pw.encode()).hexdigest(),
                "created_at": int(time.time()),
            }


def _is_blacklisted(uid: str, data: dict) -> bool:
    return str(uid) in [str(x) for x in data.get("blacklist", [])]


def _now() -> int:
    return int(time.time())


def _headshot_url(roblox_id: str) -> str:
    if not roblox_id:
        return url_for("static", filename="img/logo.png")
    try:
        r = http.get(
            ROBLOX_THUMBNAIL_API,
            params={
                "userIds": roblox_id,
                "size": "150x150",
                "format": "Png",
                "isCircular": "true",
            },
            timeout=5,
        )
        data = (r.json() or {}).get("data") or []
        if data and data[0].get("imageUrl"):
            return data[0]["imageUrl"]
    except Exception:
        pass
    return f"https://www.roblox.com/headshot-thumbnail/image?userId={roblox_id}&width=150&height=150&format=png"


def lookup_player(username: str) -> dict:
    username = (username or "").strip()
    if not username:
        return {"ok": False, "error": "Empty username"}
    try:
        r = http.post(
            ROBLOX_USERS_API,
            json={"usernames": [username], "excludeBannedUsers": False},
            timeout=10,
        )
        r.raise_for_status()
        data = (r.json() or {}).get("data") or []
        if not data:
            return {"ok": False, "error": "Roblox user not found"}
        entry = data[0]
        return {
            "ok": True,
            "roblox_id": str(entry["id"]),
            "roblox_name": entry["name"],
            "display_name": entry.get("displayName") or entry["name"],
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def _roblox_bio(username: str) -> dict:
    info = lookup_player(username)
    if not info.get("ok"):
        return info
    try:
        u = http.get(f"https://users.roblox.com/v1/users/{info['roblox_id']}", timeout=10).json()
        info["bio"] = (u.get("description") or "")
        return info
    except Exception as e:
        return {"ok": False, "error": str(e)}


def _require_user():
    uid = session.get("user_id")
    if not uid:
        return None, None
    data = get_data()
    user = ensure_user(uid, data)
    return uid, user


def _refresh_session_balance(uid: str, data: dict):
    user = ensure_user(uid, data)
    session["balance"] = format_amount(user.get("balance", 0))
    session["balance_raw"] = int(user.get("balance", 0))
    if user.get("roblox_id"):
        session["headshot"] = _headshot_url(str(user["roblox_id"]))


# ---------- Pages ----------

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/games")
def games_page():
    return render_template("games.html")


@app.route("/slots")
def slots_lobby():
    return render_template("slots_lobby.html", slots=SLOTS_LIST)


@app.route("/slots/<slot_id>")
def slot_play(slot_id: str):
    slot = SLOTS.get(slot_id)
    if not slot:
        flash("Slot not found.", "error")
        return redirect(url_for("slots_lobby"))
    return render_template("slot_play.html", slot=slot)


@app.route("/coinflip")
def coinflip_page():
    return render_template("coinflip.html")


@app.route("/roulette")
def roulette_page():
    return render_template("roulette.html")


@app.route("/blackjack")
def blackjack_page():
    return render_template("blackjack.html")


@app.route("/profile")
def profile():
    uid = session.get("user_id")
    if not uid:
        return redirect(url_for("verify_page"))
    data = get_data()
    user = ensure_user(uid, data)
    _refresh_session_balance(uid, data)
    headshot = session.get("headshot") or _headshot_url(str(user.get("roblox_id") or ""))
    return render_template(
        "profile.html",
        user=user,
        user_id=uid,
        headshot=headshot,
        format_amount=format_amount,
    )


@app.route("/verify", methods=["GET", "POST"])
def verify_page():
    if request.method != "POST":
        if session.get("verify_code"):
            return render_template(
                "verify.html",
                code=session.get("verify_code"),
                username=session.get("verify_name"),
                discord_id=session.get("verify_discord"),
            )
        return render_template("verify.html", code=None)

    step = request.form.get("step")
    username = (request.form.get("roblox_username") or "").strip()
    discord_id = (request.form.get("discord_id") or "").strip()

    if step == "start":
        if not username:
            flash("Enter a Roblox username.", "error")
            return redirect(url_for("verify_page"))
        if not discord_id.isdigit():
            flash("Enter your numeric Discord user ID.", "error")
            return redirect(url_for("verify_page"))
        info = lookup_player(username)
        if not info.get("ok"):
            flash(info.get("error") or "Roblox user not found.", "error")
            return redirect(url_for("verify_page"))
        code = "WEB-" + secrets.token_hex(3).upper()
        data = get_data()
        pending = data.setdefault("website_verify_pending", {})
        pending[code] = {
            "discord_id": str(discord_id),
            "roblox_username": info["roblox_name"],
            "roblox_id": str(info["roblox_id"]),
            "dm_ok": False,
            "created_at": _now(),
            "code": code,
        }
        # Also mirror under keys some bots expect
        data.setdefault("verification", {})[str(discord_id)] = {
            "username": info["roblox_name"],
            "roblox_id": str(info["roblox_id"]),
            "code": code,
            "confirmed": False,
            "source": "website",
        }
        ensure_user(discord_id, data)
        save_data(data)
        # Verify write stuck
        check = get_data().get("website_verify_pending", {}).get(code)
        if not check:
            flash("Could not write casino_data.json — check CASINO_DATA_FILE path.", "error")
            return redirect(url_for("verify_page"))

        session["verify_code"] = code
        session["verify_name"] = info["roblox_name"]
        session["verify_discord"] = str(discord_id)

        return render_template(
            "verify.html",
            code=code,
            username=info["roblox_name"],
            discord_id=discord_id,
        )

    code = (request.form.get("code") or session.get("verify_code") or "").strip().upper()
    username = username or (session.get("verify_name") or "")
    discord_id = discord_id or (session.get("verify_discord") or "")
    if not code or not username or not str(discord_id).isdigit():
        flash("Start verification again.", "error")
        return redirect(url_for("verify_page"))

    info = _roblox_bio(username)
    if not info.get("ok"):
        flash(info.get("error") or "Roblox lookup failed.", "error")
        return redirect(url_for("verify_page"))

    if code not in (info.get("bio") or "").upper():
        flash(
            "Code not found in Roblox bio yet. Put the exact code in your bio, wait ~10s, try again.",
            "error",
        )
        return render_template(
            "verify.html", code=code, username=username, discord_id=discord_id
        )

    data = get_data()
    pending = data.setdefault("website_verify_pending", {})
    entry = pending.get(code)

    # Pending row can be missing if DATA_FILE path differed or file was reset —
    # bio match + session is enough to complete verify.
    if not entry:
        entry = {
            "discord_id": str(discord_id),
            "roblox_username": info["roblox_name"],
            "roblox_id": str(info["roblox_id"]),
            "dm_ok": True,
            "created_at": _now(),
        }
        pending[code] = entry

    if str(entry.get("discord_id")) != str(discord_id):
        flash("Discord ID does not match this code.", "error")
        return redirect(url_for("verify_page"))

    uid = str(discord_id)
    user = ensure_user(uid, data)
    user["roblox"] = info["roblox_name"]
    user["roblox_id"] = info["roblox_id"]
    user.setdefault("codes", [])
    if user.get("affiliate_code") and user["affiliate_code"] not in user["codes"]:
        user["codes"].append(user["affiliate_code"])
    pending.pop(code, None)
    # Sync into bot-style verification map
    data.setdefault("verification", {})[uid] = {
        "username": info["roblox_name"],
        "roblox_id": str(info["roblox_id"]),
        "code": code,
        "confirmed": True,
        "source": "website",
    }
    save_data(data)

    session.pop("verify_code", None)
    session.pop("verify_name", None)
    session.pop("verify_discord", None)
    session["user_id"] = uid
    session["roblox"] = info["roblox_name"]
    session["balance"] = format_amount(user.get("balance", 0))
    session["balance_raw"] = int(user.get("balance", 0))
    session["headshot"] = _headshot_url(str(info["roblox_id"]))
    flash("Verified. Discord + Roblox linked.", "success")
    return redirect(url_for("index"))


# ---------- Chat API ----------

@app.route("/api/chat", methods=["GET", "POST"])
def api_chat():
    data = get_data()
    chat = data.setdefault("website_chat", [])
    if request.method == "GET":
        # also return active rains summary
        rains = []
        now = int(time.time())
        for rid, rain in list((data.get("active_rains") or {}).items()):
            if now < rain.get("ends_at", 0):
                rains.append({
                    "id": rid,
                    "amount_fmt": format_amount(rain["amount"]),
                    "starter": rain.get("starter_name"),
                    "joined": len(rain.get("joined", [])),
                    "remaining": rain["ends_at"] - now,
                })
        return jsonify({"ok": True, "messages": chat[-100:], "rains": rains})

    if not session.get("roblox"):
        return jsonify({"ok": False, "error": "verify first"}), 401
    body = request.get_json(silent=True) or {}
    text = (body.get("text") or "").strip()[:300]
    reply_to = body.get("reply_to")
    if not text:
        return jsonify({"ok": False}), 400

    # Command: .tip user amount  → client should open UI; still accept direct
    if text.lower().startswith(".tip "):
        parts = text.split(None, 2)
        if len(parts) >= 3:
            return jsonify({"ok": True, "action": "tip_ui", "user": parts[1], "amount": parts[2]})
        return jsonify({"ok": True, "action": "tip_ui", "user": "", "amount": ""})

    if text.lower().startswith(".rain "):
        parts = text.split(None, 1)
        amt = parts[1] if len(parts) > 1 else ""
        return jsonify({"ok": True, "action": "rain", "amount": amt})

    data_u = get_data()
    u = ensure_user(session.get("user_id"), data_u)
    lv = user_level(u.get("wagered", 0))
    display = u.get("display_name") or session["roblox"]
    entry = {
        "id": secrets.token_hex(4),
        "user": display,
        "uid": session.get("user_id"),
        "msg": text,
        "text": text,
        "type": "msg",
        "ts": _now(),
        "t": _now(),
        "level": lv["level"],
        "name_color": u.get("name_color") or "#2ee6d6",
        "text_color": u.get("text_color") or "#e8ecf4",
        "avatar_border": u.get("avatar_border") or "none",
        "avatar": u.get("custom_pfp") or session.get("headshot") or "",
    }
    if reply_to:
        entry["reply_to"] = reply_to
    chat.append(entry)
    data["website_chat"] = chat[-200:]
    save_data(data)
    return jsonify({"ok": True, "message": entry})


# ---------- Slots API (house edge applied silently via RTP) ----------

@app.route("/api/slots/spin", methods=["POST"])
def api_slots_spin():
    uid, user = _require_user()
    if not uid:
        return jsonify({"ok": False, "error": "Verify first"}), 401

    body = request.get_json(silent=True) or {}
    slot_id = body.get("slot_id")
    bet_str = body.get("bet") or "0"
    slot = SLOTS.get(slot_id)
    if not slot:
        return jsonify({"ok": False, "error": "Unknown slot"}), 400

    bet = parse_amount(str(bet_str))
    if not bet or bet <= 0:
        return jsonify({"ok": False, "error": "Invalid bet"}), 400
    if bet > user["balance"]:
        return jsonify({"ok": False, "error": "Insufficient balance"}), 400

    data = get_data()
    user = ensure_user(uid, data)
    if bet > user["balance"]:
        return jsonify({"ok": False, "error": "Insufficient balance"}), 400

    user["balance"] -= bet
    user["wagered"] = user.get("wagered", 0) + bet
    user["wagered_hour"] = user.get("wagered_hour", 0) + bet
    user["wagered_day"] = user.get("wagered_day", 0) + bet
    user["wagered_week"] = user.get("wagered_week", 0) + bet
    user["wagered_month"] = user.get("wagered_month", 0) + bet
    if user.get("to_wager", 0) > 0:
        user["to_wager"] = max(0, user["to_wager"] - bet)

    # Generate grid with weighted symbols (lower index = more common / higher weight)
    symbols = slot["symbols"]
    # Balanced weights (Lotsa-feel): features reachable, not bankrupt
    # index 0 often wild, 1 scatter — medium-rare; lows common
    n = len(symbols)
    weights = []
    for i in range(n):
        if i == 0:
            weights.append(12)   # wild
        elif i == 1:
            weights.append(18)   # scatter — features more often
        elif i <= 3:
            weights.append(16 + i * 2)
        else:
            weights.append(20 + i * 3)
    total_w = sum(weights)
    wild = slot.get("wild")
    scatter = slot.get("scatter")

    def pick():
        r = secrets.randbelow(total_w)
        acc = 0
        for i, w in enumerate(weights):
            acc += w
            if r < acc:
                return symbols[i]
        return symbols[-1]

    cols = slot.get("reels", 5)
    rows = slot.get("rows", 3)
    grid = [[pick() for _ in range(rows)] for _ in range(cols)]

    paytable = slot.get("paytable") or {}
    win = 0
    feature_triggered = None
    feature_bonus = 0

    # Count scatters anywhere on the grid
    scatter_count = 0
    if scatter:
        for c in range(cols):
            for r in range(rows):
                if grid[c][r] == scatter:
                    scatter_count += 1
    # Soft pity: ~12% chance to guarantee a feature if none landed (Lotsa feel)
    if scatter and scatter_count < 3 and secrets.randbelow(100) < 12:
        positions = [(c, r) for c in range(cols) for r in range(rows)]
        secrets.SystemRandom().shuffle(positions)
        for i in range(3):
            c, r = positions[i]
            grid[c][r] = scatter
        scatter_count = 3

    # Evaluate all 3 horizontal paylines (left-to-right consecutive)
    for row in range(rows):
        line = [grid[c][row] for c in range(cols)]
        first = line[0]
        if first == scatter:
            continue
        streak = 1
        for i in range(1, cols):
            if line[i] == first or (wild and line[i] == wild):
                streak += 1
            else:
                break
        if streak >= 3 and first in paytable:
            mult = float(paytable[first].get(str(streak), 0) or 0)
            win += int(bet * mult)

    # Feature triggers on 3+ scatters
    if scatter_count >= 3:
        feature_name = slot.get("feature") or "Bonus"
        feature_triggered = feature_name
        feature_mult = {3: 2.0, 4: 4.0, 5: 8.0}.get(min(scatter_count, 5), 2.0)
        feature_bonus = int(bet * feature_mult)
        win += feature_bonus

        fname = (feature_name or "").lower()
        if "expand" in fname:
            if wild:
                mid_col = secrets.randbelow(cols)
                for r in range(rows):
                    grid[mid_col][r] = wild
        elif "cascade" in fname:
            win = int(win * 1.15)
        elif "free" in fname or "sticky" in fname:
            win += int(bet * 1.5)

    max_win = bet * int(slot.get("max_mult", 5000))
    if win > max_win:
        win = max_win
    if win > 0:
        win = int(win * (1 - HOUSE_EDGE))

    user["balance"] += win
    result_str = f"+{format_amount(win)}" if win else "0"
    if feature_triggered:
        result_str += f" [{feature_triggered}]"
    add_history(uid, f"Slots:{slot['name']}", bet, result_str, data)
    data["global_stats"]["bot_game_profit"] = data["global_stats"].get("bot_game_profit", 0) + (bet - win)
    save_data(data)
    _refresh_session_balance(uid, data)

    return jsonify({
        "ok": True,
        "grid": grid,
        "bet": bet,
        "win": win,
        "win_fmt": format_amount(win),
        "balance": user["balance"],
        "balance_fmt": format_amount(user["balance"]),
        "feature": feature_triggered,
        "feature_bonus": feature_bonus,
        "scatter_count": scatter_count,
    })


# ---------- Coinflip (PvP, winner gets 92.5%) ----------

@app.route("/api/coinflip/list")
def api_cf_list():
    data = get_data()
    games = []
    for gid, g in list(data.get("coinflip_games", {}).items()):
        if g.get("status") != "open":
            continue
        games.append({
            "id": gid,
            "side": g["side"],
            "amount": g["amount"],
            "amount_fmt": format_amount(g["amount"]),
            "creator_name": g.get("creator_name") or "?",
            "creator_headshot": g.get("creator_headshot") or "",
        })
    return jsonify({"ok": True, "games": games})


@app.route("/api/coinflip/create", methods=["POST"])
def api_cf_create():
    uid, user = _require_user()
    if not uid:
        return jsonify({"ok": False, "error": "Verify first"}), 401
    body = request.get_json(silent=True) or {}
    side = (body.get("side") or "heads").lower()
    if side not in ("heads", "tails"):
        return jsonify({"ok": False, "error": "Invalid side"}), 400
    amount = parse_amount(str(body.get("amount") or "0"))
    if not amount or amount <= 0:
        return jsonify({"ok": False, "error": "Invalid amount"}), 400

    data = get_data()
    user = ensure_user(uid, data)
    if amount > user["balance"]:
        return jsonify({"ok": False, "error": "Insufficient balance"}), 400

    user["balance"] -= amount
    gid = secrets.token_hex(6)
    seed = secrets.token_hex(16)
    data.setdefault("coinflip_games", {})[gid] = {
        "status": "open",
        "side": side,
        "amount": amount,
        "creator_id": uid,
        "creator_name": user.get("roblox") or session.get("roblox") or "?",
        "creator_headshot": session.get("headshot") or "",
        "server_seed": seed,
        "server_seed_hash": hashlib.sha256(seed.encode()).hexdigest(),
        "created_at": _now(),
    }
    save_data(data)
    _refresh_session_balance(uid, data)
    return jsonify({"ok": True, "game_id": gid})


@app.route("/api/coinflip/join", methods=["POST"])
def api_cf_join():
    uid, user = _require_user()
    if not uid:
        return jsonify({"ok": False, "error": "Verify first"}), 401
    body = request.get_json(silent=True) or {}
    gid = body.get("game_id")
    data = get_data()
    g = data.get("coinflip_games", {}).get(gid)
    if not g or g.get("status") != "open":
        return jsonify({"ok": False, "error": "Game not available"}), 400
    if g["creator_id"] == uid:
        return jsonify({"ok": False, "error": "Cannot join your own game"}), 400

    amount = g["amount"]
    user = ensure_user(uid, data)
    if amount > user["balance"]:
        return jsonify({"ok": False, "error": "Insufficient balance"}), 400

    user["balance"] -= amount
    creator = ensure_user(g["creator_id"], data)

    # Provably fair: hash(server_seed + joiner_id) 
    seed = g["server_seed"]
    h = hashlib.sha256(f"{seed}:{uid}:{_now()}".encode()).hexdigest()
    result = "heads" if int(h[:8], 16) % 2 == 0 else "tails"

    pot = amount * 2
    payout = int(pot * (1 - HOUSE_EDGE))  # 92.5% to winner
    winner_id = g["creator_id"] if result == g["side"] else uid
    winner = ensure_user(winner_id, data)
    winner["balance"] += payout

    g["status"] = "finished"
    g["joiner_id"] = uid
    g["joiner_name"] = user.get("roblox") or "?"
    g["result"] = result
    g["winner_id"] = winner_id

    add_history(g["creator_id"], "Coinflip", amount, "Win" if winner_id == g["creator_id"] else "Loss", data)
    add_history(uid, "Coinflip", amount, "Win" if winner_id == uid else "Loss", data)
    data["global_stats"]["bot_game_profit"] = data["global_stats"].get("bot_game_profit", 0) + (pot - payout)
    save_data(data)
    _refresh_session_balance(uid, data)

    p1_side = g["side"]
    return jsonify({
        "ok": True,
        "result": result,
        "p1_name": g["creator_name"],
        "p2_name": g["joiner_name"],
        "p1_side": p1_side,
        "p1_headshot": g.get("creator_headshot") or "",
        "p2_headshot": session.get("headshot") or "",
        "winner_side": result,
        "winner_name": g["creator_name"] if winner_id == g["creator_id"] else g["joiner_name"],
        "payout_fmt": format_amount(payout),
        "server_seed": seed,
        "server_seed_hash": g["server_seed_hash"],
    })


# ---------- Roulette ----------

def _ensure_roulette_round(data: dict) -> dict:
    rnd = data.get("roulette_round") or {}
    now = _now()
    if not rnd or now >= rnd.get("ends_at", 0) + 15:
        # settle previous if needed
        if rnd and rnd.get("status") == "open" and now >= rnd.get("ends_at", 0):
            _settle_roulette(data, rnd)
        seed = secrets.token_hex(16)
        rnd = {
            "id": secrets.token_hex(4),
            "status": "open",
            "starts_at": now,
            "ends_at": now + ROULETTE_ROUND_SECONDS,
            "bets": {},  # user_id -> {spot: chips}
            "server_seed": seed,
            "server_seed_hash": hashlib.sha256(seed.encode()).hexdigest(),
            "result": None,
        }
        data["roulette_round"] = rnd
        save_data(data)
    elif rnd.get("status") == "open" and now >= rnd.get("ends_at", 0):
        _settle_roulette(data, rnd)
        rnd = data["roulette_round"]
    return rnd


def _settle_roulette(data: dict, rnd: dict):
    if rnd.get("status") != "open":
        return
    seed = rnd["server_seed"]
    h = hashlib.sha256(seed.encode()).hexdigest()
    number = int(h[:8], 16) % 37  # 0-36
    rnd["result"] = number
    rnd["status"] = "settled"

    REDS = {1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36}

    def pays(spot: str, n: int) -> float:
        if spot.isdigit():
            return 36.0 if int(spot) == n else 0.0
        if spot == "red":
            return 2.0 if n in REDS else 0.0
        if spot == "black":
            return 2.0 if n not in REDS and n != 0 else 0.0
        if spot == "odd":
            return 2.0 if n != 0 and n % 2 == 1 else 0.0
        if spot == "even":
            return 2.0 if n != 0 and n % 2 == 0 else 0.0
        if spot == "1-18":
            return 2.0 if 1 <= n <= 18 else 0.0
        if spot == "19-36":
            return 2.0 if 19 <= n <= 36 else 0.0
        return 0.0

    # chip value: 1 chip = 1M gems for simplicity when buying
    CHIP_VALUE = 1_000_000
    for uid, bets in (rnd.get("bets") or {}).items():
        user = ensure_user(uid, data)
        total_win_chips = 0
        for spot, chips in bets.items():
            mult = pays(str(spot), number)
            if mult > 0:
                # payout includes stake; apply house edge on profit
                gross = chips * mult
                profit = gross - chips
                net = chips + int(profit * (1 - HOUSE_EDGE))
                total_win_chips += net
        if total_win_chips > 0:
            user["chips"] = user.get("chips", 0) + total_win_chips
            add_history(uid, "Roulette", 0, f"+{total_win_chips} chips (#{number})", data)

    hist = data.setdefault("roulette_history", [])
    hist.append({"n": number, "t": _now()})
    data["roulette_history"] = hist[-50:]
    save_data(data)


@app.route("/api/roulette/state")
def api_rou_state():
    data = get_data()
    rnd = _ensure_roulette_round(data)
    now = _now()
    left = max(0, rnd.get("ends_at", 0) - now)
    uid = session.get("user_id")
    my_bets = {}
    chips_fmt = "0"
    balance_fmt = session.get("balance") or "0"
    if uid:
        user = ensure_user(uid, data)
        my_bets = (rnd.get("bets") or {}).get(uid, {})
        chips_fmt = format_amount(user.get("chips", 0))
        balance_fmt = format_amount(user.get("balance", 0))
    return jsonify({
        "ok": True,
        "seconds_left": left,
        "spinning": rnd.get("status") == "settled" and left == 0,
        "result": rnd.get("result"),
        "last_number": rnd.get("result"),
        "my_bets": my_bets,
        "chips_fmt": chips_fmt,
        "balance_fmt": balance_fmt,
        "fair_hash": rnd.get("server_seed_hash"),
    })


@app.route("/api/roulette/buy_chips", methods=["POST"])
def api_rou_buy():
    uid, user = _require_user()
    if not uid:
        return jsonify({"ok": False, "error": "Verify first"}), 401
    body = request.get_json(silent=True) or {}
    amount = int(body.get("amount") or 0)
    if amount <= 0:
        return jsonify({"ok": False, "error": "Invalid amount"}), 400
    data = get_data()
    user = ensure_user(uid, data)
    if amount > user["balance"]:
        return jsonify({"ok": False, "error": "Insufficient balance"}), 400
    user["balance"] -= amount
    # 1 chip unit per 1M
    chips = amount // 1_000_000
    if chips < 1:
        return jsonify({"ok": False, "error": "Min 1M for 1 chip"}), 400
    user["chips"] = user.get("chips", 0) + chips
    save_data(data)
    _refresh_session_balance(uid, data)
    return jsonify({"ok": True, "chips": user["chips"]})


@app.route("/api/roulette/sell_chips", methods=["POST"])
def api_rou_sell():
    uid, user = _require_user()
    if not uid:
        return jsonify({"ok": False, "error": "Verify first"}), 401
    data = get_data()
    user = ensure_user(uid, data)
    chips = int(user.get("chips", 0))
    if chips <= 0:
        return jsonify({"ok": False, "error": "No chips"}), 400
    gross = chips * 1_000_000
    credited = int(gross * (1 - HOUSE_EDGE))
    user["chips"] = 0
    user["balance"] += credited
    save_data(data)
    _refresh_session_balance(uid, data)
    return jsonify({"ok": True, "credited": credited, "credited_fmt": format_amount(credited)})


@app.route("/api/roulette/bet", methods=["POST"])
def api_rou_bet():
    uid, user = _require_user()
    if not uid:
        return jsonify({"ok": False, "error": "Verify first"}), 401
    body = request.get_json(silent=True) or {}
    spot = str(body.get("bet") or "")
    chips = int(body.get("chips") or 1)
    if chips < 1:
        return jsonify({"ok": False, "error": "Need at least 1 chip"}), 400

    data = get_data()
    rnd = _ensure_roulette_round(data)
    if rnd.get("status") != "open" or _now() >= rnd.get("ends_at", 0):
        return jsonify({"ok": False, "error": "Betting closed"}), 400

    user = ensure_user(uid, data)
    if user.get("chips", 0) < chips:
        return jsonify({"ok": False, "error": "Not enough chips"}), 400
    user["chips"] -= chips
    bets = rnd.setdefault("bets", {}).setdefault(uid, {})
    bets[spot] = bets.get(spot, 0) + chips
    save_data(data)
    return jsonify({"ok": True})


# ---------- Blackjack ----------

SUITS = ["♠", "♥", "♦", "♣"]
RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]


def _bj_deck(seed: str):
    cards = [{"rank": r, "suit": s} for s in SUITS for r in RANKS]
    # shuffle with seed
    rnd = int(hashlib.sha256(seed.encode()).hexdigest(), 16)
    for i in range(len(cards) - 1, 0, -1):
        rnd = (rnd * 6364136223846793005 + 1) & 0xFFFFFFFFFFFFFFFF
        j = rnd % (i + 1)
        cards[i], cards[j] = cards[j], cards[i]
    return cards


def _bj_score(hand):
    total = 0
    aces = 0
    for c in hand:
        r = c["rank"]
        if r in ("J", "Q", "K"):
            total += 10
        elif r == "A":
            aces += 1
            total += 11
        else:
            total += int(r)
    while total > 21 and aces:
        total -= 10
        aces -= 1
    return total


@app.route("/api/blackjack/deal", methods=["POST"])
def api_bj_deal():
    uid, user = _require_user()
    if not uid:
        return jsonify({"ok": False, "error": "Verify first"}), 401
    body = request.get_json(silent=True) or {}
    bet = parse_amount(str(body.get("bet") or "0"))
    if not bet or bet <= 0:
        return jsonify({"ok": False, "error": "Invalid bet"}), 400

    data = get_data()
    user = ensure_user(uid, data)
    if bet > user["balance"]:
        return jsonify({"ok": False, "error": "Insufficient balance"}), 400

    user["balance"] -= bet
    user["wagered"] = user.get("wagered", 0) + bet
    seed = secrets.token_hex(16)
    deck = _bj_deck(seed)
    player = [deck.pop(), deck.pop()]
    dealer = [deck.pop(), deck.pop()]
    _bj_sessions[uid] = {
        "bet": bet,
        "deck": deck,
        "player": player,
        "dealer": dealer,
        "seed": seed,
        "status": "playing",
    }
    save_data(data)
    _refresh_session_balance(uid, data)

    ps = _bj_score(player)
    msg = "Your turn"
    status = "playing"
    if ps == 21:
        # blackjack pays 2.5x stake before edge on profit
        payout = int(bet * 2.5)
        profit = payout - bet
        net = bet + int(profit * (1 - HOUSE_EDGE))
        user["balance"] += net
        add_history(uid, "Blackjack", bet, f"BJ +{format_amount(net - bet)}", data)
        save_data(data)
        _bj_sessions[uid]["status"] = "done"
        msg = f"Blackjack! +{format_amount(net - bet)}"
        status = "done"
        return jsonify({
            "ok": True,
            "player": player,
            "dealer": dealer,
            "player_score": ps,
            "dealer_score": _bj_score(dealer),
            "message": msg,
            "status": status,
            "fair": seed[:16],
        })

    return jsonify({
        "ok": True,
        "player": player,
        "dealer": [{"rank": "?", "suit": "?"}, dealer[1]],
        "player_score": ps,
        "dealer_score": None,
        "message": msg,
        "status": status,
        "fair": hashlib.sha256(seed.encode()).hexdigest()[:16],
    })


@app.route("/api/blackjack/hit", methods=["POST"])
def api_bj_hit():
    uid = session.get("user_id")
    st = _bj_sessions.get(uid)
    if not st or st.get("status") != "playing":
        return jsonify({"ok": False, "error": "No active hand"}), 400
    st["player"].append(st["deck"].pop())
    ps = _bj_score(st["player"])
    if ps > 21:
        st["status"] = "done"
        data = get_data()
        add_history(uid, "Blackjack", st["bet"], "Bust", data)
        save_data(data)
        return jsonify({
            "ok": True,
            "player": st["player"],
            "dealer": st["dealer"],
            "player_score": ps,
            "dealer_score": _bj_score(st["dealer"]),
            "message": "Bust!",
            "status": "done",
            "fair": st["seed"][:16],
        })
    return jsonify({
        "ok": True,
        "player": st["player"],
        "dealer": [{"rank": "?", "suit": "?"}, st["dealer"][1]],
        "player_score": ps,
        "message": "Hit or Stand",
        "status": "playing",
    })


@app.route("/api/blackjack/stand", methods=["POST"])
def api_bj_stand():
    uid = session.get("user_id")
    st = _bj_sessions.get(uid)
    if not st or st.get("status") != "playing":
        return jsonify({"ok": False, "error": "No active hand"}), 400

    while _bj_score(st["dealer"]) < 17:
        st["dealer"].append(st["deck"].pop())

    ps = _bj_score(st["player"])
    ds = _bj_score(st["dealer"])
    bet = st["bet"]
    data = get_data()
    user = ensure_user(uid, data)
    st["status"] = "done"

    if ds > 21 or ps > ds:
        # win: 2x stake, edge on profit
        payout = bet * 2
        net = bet + int((payout - bet) * (1 - HOUSE_EDGE))
        user["balance"] += net
        msg = f"You win +{format_amount(net - bet)}"
        add_history(uid, "Blackjack", bet, f"Win +{format_amount(net - bet)}", data)
    elif ps == ds:
        user["balance"] += bet
        msg = "Push"
        add_history(uid, "Blackjack", bet, "Push", data)
    else:
        msg = "Dealer wins"
        add_history(uid, "Blackjack", bet, "Loss", data)

    save_data(data)
    _refresh_session_balance(uid, data)
    return jsonify({
        "ok": True,
        "player": st["player"],
        "dealer": st["dealer"],
        "player_score": ps,
        "dealer_score": ds,
        "message": msg,
        "status": "done",
        "fair": st["seed"][:16],
    })



# ---------- Deposit / Withdraw (evidence + Discord staff review) ----------

@app.route("/deposit", methods=["GET", "POST"])
def deposit_page():
    uid = session.get("user_id")
    if not uid:
        flash("Verify your account first.", "error")
        return redirect(url_for("verify_page"))
    if request.method == "GET":
        return render_template("deposit.html")

    amount = parse_amount((request.form.get("amount") or "").strip())
    if not amount or amount <= 0:
        flash("Invalid amount.", "error")
        return redirect(url_for("deposit_page"))

    f = request.files.get("evidence")
    if not f or not f.filename:
        flash("Evidence is required.", "error")
        return redirect(url_for("deposit_page"))

    data = get_data()
    if _is_blacklisted(uid, data):
        flash("Account restricted.", "error")
        return redirect(url_for("index"))

    user = ensure_user(uid, data)
    ext = Path(f.filename).suffix.lower() or ".png"
    if ext not in (".png", ".jpg", ".jpeg", ".webp", ".gif"):
        flash("Image only (png/jpg/webp/gif).", "error")
        return redirect(url_for("deposit_page"))

    dep_id = secrets.token_hex(8)
    fname = f"dep_{dep_id}{ext}"
    f.save(str(UPLOAD_DIR / fname))
    evidence_url = f"/static/uploads/{fname}"

    entry = {
        "id": dep_id,
        "type": "deposit",
        "user_id": str(uid),
        "roblox": user.get("roblox") or session.get("roblox") or "?",
        "roblox_id": user.get("roblox_id"),
        "amount": amount,
        "amount_fmt": format_amount(amount),
        "evidence": fname,
        "evidence_url": evidence_url,
        "status": "waiting_review",
        "created_at": _now(),
    }
    data.setdefault("website_pending_deposits", {})[dep_id] = entry
    save_data(data)

    # Discord review channel
    site = os.environ.get("PUBLIC_SITE_URL", "https://aqua-gems.com")
    embeds = [{
        "title": "💎 Website Deposit Request",
        "description": (
            f"**User:** <@{uid}>\n"
            f"**Roblox:** `{entry['roblox']}`\n"
            f"**Amount:** {entry['amount_fmt']}\n"
            f"**ID:** `{dep_id}`\n"
            f"[Evidence]({site}{evidence_url})"
        ),
        "color": 0x57F287,
    }]
    ok = _discord_webhook(
        WEBHOOK_DEPOSIT_REQUEST,
        content=(
            "**Website deposit request**\n"
            f"User: <@{uid}> (`{uid}`)\n"
            f"Roblox: `{entry['roblox']}`\n"
            f"Amount: **{entry['amount_fmt']}**\n"
            f"ID: `{dep_id}`\n"
            f"Evidence: {site}{evidence_url}\n"
            f"Staff: accept/deny via admin panel or API id `{dep_id}`."
        ),
        embeds=embeds,
    )
    entry["webhook_ok"] = bool(ok)
    data["website_pending_deposits"][dep_id] = entry
    save_data(data)

    flash("Deposit submitted. Staff will review your proof in Discord.", "success")
    return redirect(url_for("profile"))


@app.route("/withdraw", methods=["GET", "POST"])
def withdraw_page():
    uid = session.get("user_id")
    if not uid:
        flash("Verify your account first.", "error")
        return redirect(url_for("verify_page"))
    if request.method == "GET":
        return render_template("withdraw.html")

    amount = parse_amount((request.form.get("amount") or "").strip())
    roblox_username = (request.form.get("roblox_username") or "").strip()
    if not amount or amount <= 0:
        flash("Invalid amount.", "error")
        return redirect(url_for("withdraw_page"))
    if not roblox_username:
        flash("Roblox username required.", "error")
        return redirect(url_for("withdraw_page"))

    data = get_data()
    if _is_blacklisted(uid, data):
        flash("Account restricted.", "error")
        return redirect(url_for("index"))

    user = ensure_user(uid, data)
    if user["balance"] < amount:
        flash(f"Insufficient balance ({format_amount(user['balance'])}).", "error")
        return redirect(url_for("withdraw_page"))

    # Hold funds
    user["balance"] -= amount
    user["held_withdraw"] = user.get("held_withdraw", 0) + amount
    wid = secrets.token_hex(8)
    entry = {
        "id": wid,
        "type": "withdraw",
        "user_id": str(uid),
        "roblox": roblox_username,
        "amount": amount,
        "amount_fmt": format_amount(amount),
        "status": "held",
        "created_at": _now(),
    }
    data.setdefault("website_pending_withdraws", {})[wid] = entry
    save_data(data)
    _refresh_session_balance(uid, data)

    embeds = [{
        "title": "💸 Website Withdraw Request",
        "description": (
            f"**User:** <@{uid}>\n"
            f"**Send to Roblox:** `{roblox_username}`\n"
            f"**Amount:** {entry['amount_fmt']}\n"
            f"**ID:** `{wid}`\n"
            f"Balance is **on hold**. Accept after sending diamonds, or Deny to refund."
        ),
        "color": 0xFEE75C,
    }]
    _discord_webhook(
        WEBHOOK_WITHDRAW_REQUEST,
        content=(
            "**Website withdraw request**\n"
            f"User: <@{uid}> (`{uid}`)\n"
            f"Send **{entry['amount_fmt']}** to Roblox `{roblox_username}`\n"
            f"ID: `{wid}` — balance is ON HOLD.\n"
            f"Accept/deny via admin panel or API id `{wid}`."
        ),
        embeds=embeds,
    )
    flash("Withdraw held. Staff will send diamonds and confirm in Discord.", "success")
    return redirect(url_for("profile"))


@app.route("/api/staff/deposit_decision", methods=["POST"])
def api_staff_deposit_decision():
    """Admin panel or bot Accept/Deny deposit."""
    body = request.get_json(silent=True) or {}
    key = request.headers.get("X-Admin-Key") or body.get("admin_key") or body.get("key")
    if key != ADMIN_API_KEY and not session.get("is_admin"):
        return jsonify({"ok": False, "error": "unauthorized"}), 401
    dep_id = (body.get("id") or "").strip()
    decision = (body.get("decision") or "").lower()  # accept | deny
    staff_id = str(body.get("staff_id") or session.get("admin_user") or "?")

    data = get_data()
    entry = data.get("website_pending_deposits", {}).get(dep_id)
    if not entry or entry.get("status") != "waiting_review":
        return jsonify({"ok": False, "error": "not found or already handled"}), 404

    if decision == "deny":
        entry["status"] = "denied"
        entry["staff_id"] = staff_id
        entry["completed_at"] = _now()
        save_data(data)
        return jsonify({"ok": True, "status": "denied"})

    if decision != "accept":
        return jsonify({"ok": False, "error": "decision must be accept or deny"}), 400

    uid = entry["user_id"]
    amount = int(entry["amount"])
    user = ensure_user(uid, data)
    user["balance"] = user.get("balance", 0) + amount
    user["deposited"] = user.get("deposited", 0) + amount
    user["to_wager"] = user.get("to_wager", 0) + amount
    entry["status"] = "accepted"
    entry["staff_id"] = staff_id
    entry["completed_at"] = _now()
    add_history(uid, "Website Deposit", amount, "Approved", data)
    data["global_stats"]["total_deposits"] = data["global_stats"].get("total_deposits", 0) + amount
    save_data(data)

    _discord_webhook(
        WEBHOOK_DEPOSIT_LOG,
        content=(
            f"**Website Deposit approved**\n"
            f"Roblox: `{entry.get('roblox')}` · Amount: **{format_amount(amount)}**\n"
            f"Accepted by: <@{staff_id}> · User: <@{uid}>"
        ),
    )
    return jsonify({"ok": True, "status": "accepted", "balance": user["balance"]})


@app.route("/api/staff/withdraw_decision", methods=["POST"])
def api_staff_withdraw_decision():
    body = request.get_json(silent=True) or {}
    key = request.headers.get("X-Admin-Key") or body.get("admin_key") or body.get("key")
    if key != ADMIN_API_KEY and not session.get("is_admin"):
        return jsonify({"ok": False, "error": "unauthorized"}), 401
    wid = (body.get("id") or "").strip()
    decision = (body.get("decision") or "").lower()
    staff_id = str(body.get("staff_id") or session.get("admin_user") or "?")

    data = get_data()
    entry = data.get("website_pending_withdraws", {}).get(wid)
    if not entry or entry.get("status") != "held":
        return jsonify({"ok": False, "error": "not found or already handled"}), 404

    uid = entry["user_id"]
    amount = int(entry["amount"])
    user = ensure_user(uid, data)

    if decision == "deny":
        # refund hold
        user["balance"] = user.get("balance", 0) + amount
        user["held_withdraw"] = max(0, user.get("held_withdraw", 0) - amount)
        entry["status"] = "denied"
        entry["staff_id"] = staff_id
        entry["completed_at"] = _now()
        save_data(data)
        return jsonify({"ok": True, "status": "denied", "refunded": amount})

    if decision != "accept":
        return jsonify({"ok": False, "error": "decision must be accept or deny"}), 400

    # accept: funds already deducted; clear hold and log withdrawn
    user["held_withdraw"] = max(0, user.get("held_withdraw", 0) - amount)
    user["withdrawn"] = user.get("withdrawn", 0) + amount
    entry["status"] = "accepted"
    entry["staff_id"] = staff_id
    entry["completed_at"] = _now()
    add_history(uid, "Website Withdraw", amount, "Paid", data)
    data["global_stats"]["total_withdraws"] = data["global_stats"].get("total_withdraws", 0) + amount
    save_data(data)

    _discord_webhook(
        WEBHOOK_WITHDRAW_LOG,
        content=(
            f"**Website Withdraw approved**\n"
            f"Roblox: `{entry.get('roblox')}` · Amount: **{format_amount(amount)}**\n"
            f"Accepted by: <@{staff_id}> · User: <@{uid}>"
        ),
    )
    return jsonify({"ok": True, "status": "accepted"})


@app.route("/api/staff/pending")
def api_staff_pending():
    key = request.headers.get("X-Admin-Key") or request.args.get("admin_key")
    if key != ADMIN_API_KEY:
        return jsonify({"ok": False}), 401
    data = get_data()
    return jsonify({
        "ok": True,
        "deposits": data.get("website_pending_deposits", {}),
        "withdraws": data.get("website_pending_withdraws", {}),
    })


@app.route("/api/admin/add", methods=["POST"])
def api_admin_add():
    """Discord bot: POST {admin_key, username, password} after /addadmin command."""
    body = request.get_json(silent=True) or {}
    key = request.headers.get("X-Admin-Key") or body.get("admin_key")
    if key != ADMIN_API_KEY:
        return jsonify({"ok": False}), 401
    username = (body.get("username") or "").strip()
    password = (body.get("password") or "").strip()
    if not username or not password:
        return jsonify({"ok": False, "error": "need username+password"}), 400
    data = get_data()
    admins = data.setdefault("admins", {})
    # store simple hash
    admins[username.lower()] = {
        "password_hash": hashlib.sha256(password.encode()).hexdigest(),
        "created_at": _now(),
    }
    save_data(data)
    return jsonify({"ok": True})


@app.route("/admin", methods=["GET", "POST"])
def admin_login():
    if session.get("is_admin"):
        return redirect(url_for("admin_panel"))
    if request.method == "GET":
        data = get_data()
        _ensure_default_admins(data)
        save_data(data)
        return render_template("admin_login.html")
    username = (request.form.get("username") or "").strip().lower()
    password = (request.form.get("password") or "").strip()
    data = get_data()
    _ensure_default_admins(data)
    adm = data.get("admins", {}).get(username)
    if not adm or adm.get("password_hash") != hashlib.sha256(password.encode()).hexdigest():
        flash("Invalid admin credentials.", "error")
        return redirect(url_for("admin_login"))
    session["is_admin"] = True
    session["admin_user"] = username
    return redirect(url_for("admin_panel"))


@app.route("/admin/panel")
def admin_panel():
    if not session.get("is_admin"):
        return redirect(url_for("admin_login"))
    data = get_data()
    deps = [(k, v) for k, v in data.get("website_pending_deposits", {}).items()]
    wds = [(k, v) for k, v in data.get("website_pending_withdraws", {}).items()]
    return render_template("admin.html", deposits=deps, withdraws=wds)


@app.route("/admin/action", methods=["POST"])
def admin_action():
    if not session.get("is_admin"):
        return redirect(url_for("admin_login"))
    data = get_data()
    action = request.form.get("action")
    if action == "balance":
        uid = (request.form.get("user_id") or "").strip()
        amount = parse_amount((request.form.get("amount") or "").strip())
        if not uid or amount is None:
            flash("Need user id and amount.", "error")
        else:
            user = ensure_user(uid, data)
            user["balance"] = user.get("balance", 0) + amount
            save_data(data)
            flash(f"Balance updated for {uid}: {format_amount(user['balance'])}", "success")
    elif action == "list":
        uid = (request.form.get("user_id") or "").strip()
        la = request.form.get("list_action")
        bl = data.setdefault("blacklist", [])
        wl = data.setdefault("whitelist", [])
        if la == "blacklist_add" and uid not in bl:
            bl.append(uid)
        elif la == "blacklist_remove" and uid in bl:
            bl.remove(uid)
        elif la == "whitelist_add" and uid not in wl:
            wl.append(uid)
        elif la == "whitelist_remove" and uid in wl:
            wl.remove(uid)
        elif la == "ban":
            if uid not in bl:
                bl.append(uid)
        save_data(data)
        flash(f"List action {la} applied to {uid}", "success")
    return redirect(url_for("admin_panel"))


@app.route("/admin/logout")
def admin_logout():
    session.pop("is_admin", None)
    session.pop("admin_user", None)
    return redirect(url_for("index"))



@app.route("/api/health")
def health():
    data = get_data()
    return jsonify({
        "ok": True,
        "users": len(data.get("users", {})),
        "slots": len(SLOTS),
        "site": "aqua-gems.com",
        "port": PORT,
    })


@app.route("/api/bot/verify_dm", methods=["POST"])
def api_bot_verify_dm():
    """Discord bot calls this to mark dm_ok on a pending verify code."""
    key = request.headers.get("X-Admin-Key") or (request.get_json(silent=True) or {}).get("admin_key")
    if key != ADMIN_API_KEY:
        return jsonify({"ok": False}), 401
    body = request.get_json(silent=True) or {}
    code = (body.get("code") or "").strip().upper()
    data = get_data()
    entry = data.get("website_verify_pending", {}).get(code)
    if not entry:
        return jsonify({"ok": False, "error": "unknown code"}), 404
    entry["dm_ok"] = True
    save_data(data)
    return jsonify({"ok": True})




# ---------------------------------------------------------------------------
# Discord OAuth + Roblox linking (primary flow)
# ---------------------------------------------------------------------------

@app.route("/login/discord")
def login_discord():
    """Redirect user to Discord OAuth authorize."""
    if not DISCORD_CLIENT_ID:
        flash("Discord login not configured", "error")
        return redirect(url_for("verify_page"))
    state = secrets.token_urlsafe(16)
    session["oauth_state"] = state
    params = {
        "client_id": DISCORD_CLIENT_ID,
        "redirect_uri": DISCORD_REDIRECT_URI,
        "response_type": "code",
        "scope": "identify",
        "state": state,
    }
    from urllib.parse import urlencode
    return redirect("https://discord.com/api/oauth2/authorize?" + urlencode(params))


@app.route("/verify2")
def verify2():
    """
    Discord OAuth callback.
    Shows thanks + form for Roblox username, then bio-code verification.
    """
    code = request.args.get("code")
    state = request.args.get("state")
    error = request.args.get("error")

    if error:
        flash(f"Discord auth failed: {error}", "error")
        return redirect(url_for("index"))

    # If already have discord in session and pending roblox link
    if session.get("discord_id") and not session.get("roblox"):
        return render_template(
            "verify2.html",
            discord_name=session.get("discord_name"),
            discord_id=session.get("discord_id"),
            code=session.get("verify_code"),
            pending_username=session.get("verify_name"),
        )

    if not code:
        # Manual visit — if logged in show status
        if session.get("user_id") and session.get("roblox"):
            return redirect(url_for("profile"))
        return redirect(url_for("login_discord"))

    # Exchange code for token
    if not DISCORD_CLIENT_SECRET:
        flash("Server missing DISCORD_CLIENT_SECRET — set env var", "error")
        return redirect(url_for("index"))

    try:
        token_resp = http.post(
            "https://discord.com/api/oauth2/token",
            data={
                "client_id": DISCORD_CLIENT_ID,
                "client_secret": DISCORD_CLIENT_SECRET,
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": DISCORD_REDIRECT_URI,
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=15,
        )
        token_data = token_resp.json()
        access = token_data.get("access_token")
        if not access:
            flash("Discord token exchange failed", "error")
            return redirect(url_for("index"))

        user_resp = http.get(
            "https://discord.com/api/users/@me",
            headers={"Authorization": f"Bearer {access}"},
            timeout=10,
        )
        duser = user_resp.json()
        discord_id = str(duser["id"])
        discord_name = duser.get("global_name") or duser.get("username") or "User"
        avatar_hash = duser.get("avatar")
        avatar_url = (
            f"https://cdn.discordapp.com/avatars/{discord_id}/{avatar_hash}.png"
            if avatar_hash
            else "https://cdn.discordapp.com/embed/avatars/0.png"
        )
    except Exception as e:
        flash(f"Discord error: {e}", "error")
        return redirect(url_for("index"))

    data = get_data()
    uid, user = find_user_by_discord_id(discord_id, data)
    if not uid:
        # Create new user keyed by discord id
        uid = discord_id
        user = ensure_user(uid, data)
        user["discord_id"] = discord_id
        user["discord_name"] = discord_name
        user["avatar"] = avatar_url
        save_data(data)
    else:
        user["discord_name"] = discord_name
        user["avatar"] = avatar_url
        save_data(data)

    session["user_id"] = uid
    session["discord_id"] = discord_id
    session["discord_name"] = discord_name
    session["headshot"] = avatar_url
    _refresh_session_balance(uid, data)

    if user.get("roblox_id"):
        session["roblox"] = user.get("roblox")
        flash(f"Welcome back, {user.get('roblox')}!", "ok")
        return redirect(url_for("index"))

    # Need to link Roblox
    return render_template(
        "verify2.html",
        discord_name=discord_name,
        discord_id=discord_id,
        code=None,
        pending_username=None,
    )


@app.route("/verify2/start", methods=["POST"])
def verify2_start():
    """User submitted Roblox username after Discord login."""
    if not session.get("discord_id"):
        return redirect(url_for("login_discord"))
    username = (request.form.get("roblox_username") or "").strip()
    if not username:
        flash("Enter your Roblox username", "error")
        return redirect(url_for("verify2"))
    info = lookup_player(username)
    if not info:
        flash("Roblox user not found", "error")
        return redirect(url_for("verify2"))
    code = "AG-" + secrets.token_hex(3).upper()
    session["verify_code"] = code
    session["verify_name"] = info["roblox_name"]
    session["verify_roblox_id"] = info["roblox_id"]
    data = get_data()
    data.setdefault("website_verify_pending", {})[session["discord_id"]] = {
        "code": code,
        "roblox_name": info["roblox_name"],
        "roblox_id": info["roblox_id"],
        "ts": int(time.time()),
    }
    save_data(data)
    return render_template(
        "verify2.html",
        discord_name=session.get("discord_name"),
        discord_id=session.get("discord_id"),
        code=code,
        pending_username=info["roblox_name"],
    )


@app.route("/api/verify2/check", methods=["POST"])
def api_verify2_check():
    """Poll Roblox bio for verification code."""
    if not session.get("discord_id") or not session.get("verify_code"):
        return jsonify({"ok": False, "error": "No pending verification"}), 400
    code = session["verify_code"]
    rid = session.get("verify_roblox_id")
    rname = session.get("verify_name")
    try:
        # Fetch user description
        u = http.get(f"https://users.roblox.com/v1/users/{rid}", timeout=10).json()
        bio = (u.get("description") or "") + " " + (u.get("displayName") or "")
        if code.upper() not in bio.upper():
            return jsonify({"ok": False, "verified": False, "msg": "Code not found in bio yet"})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

    # Success — link accounts
    data = get_data()
    uid = session["user_id"]
    user = ensure_user(uid, data)
    # Prevent double-link
    existing_uid, _ = find_user_by_roblox_id(rid, data)
    if existing_uid and existing_uid != uid:
        return jsonify({"ok": False, "error": "That Roblox account is already linked"}), 400
    user["roblox"] = rname
    user["roblox_id"] = str(rid)
    user["discord_id"] = session.get("discord_id")
    user["discord_name"] = session.get("discord_name")
    data.get("website_verify_pending", {}).pop(session.get("discord_id"), None)
    save_data(data)
    session["roblox"] = rname
    session["headshot"] = _headshot_url(str(rid))
    _refresh_session_balance(uid, data)
    session.pop("verify_code", None)
    session.pop("verify_name", None)
    session.pop("verify_roblox_id", None)
    return jsonify({"ok": True, "verified": True, "roblox": rname})


# ---------------------------------------------------------------------------
# Rain system
# ---------------------------------------------------------------------------

@app.route("/api/rain/active")
def api_rain_active():
    data = get_data()
    rains = data.get("active_rains") or {}
    now = int(time.time())
    # Clean expired (distribute)
    changed = False
    for rid, rain in list(rains.items()):
        if now >= rain.get("ends_at", 0):
            _finish_rain(data, rid, rain)
            rains.pop(rid, None)
            changed = True
    if changed:
        data["active_rains"] = rains
        save_data(data)
    active = []
    for rid, rain in rains.items():
        active.append({
            "id": rid,
            "amount": rain["amount"],
            "amount_fmt": format_amount(rain["amount"]),
            "starter": rain.get("starter_name"),
            "starter_id": rain.get("starter_id"),
            "joined": len(rain.get("joined", [])),
            "ends_at": rain["ends_at"],
            "remaining": max(0, rain["ends_at"] - now),
        })
    return jsonify({"ok": True, "rains": active})


def _finish_rain(data, rid, rain):
    joined = rain.get("joined") or []
    amount = int(rain.get("amount") or 0)
    if not joined or amount <= 0:
        return
    pot = int(amount * (1 - HOUSE_EDGE))  # 92.5% distributed
    per = pot // len(joined) if joined else 0
    remainder = pot % len(joined) if joined else 0
    for i, juid in enumerate(joined):
        u = ensure_user(juid, data)
        credit = per + (1 if i < remainder else 0)
        u["balance"] = u.get("balance", 0) + credit
        add_history(juid, "Rain", 0, f"+{format_amount(credit)}", data)
    data.setdefault("rain_history", []).append({
        "id": rid,
        "amount": amount,
        "joined": len(joined),
        "ts": int(time.time()),
    })
    data["rain_history"] = data["rain_history"][-50:]
    data["global_stats"]["bot_game_profit"] = data["global_stats"].get("bot_game_profit", 0) + int(amount * HOUSE_EDGE)
    # Discord end embed
    try:
        content = f"<@&{RAIN_ROLE_ID}>"
        embed = {
            "title": "🌧️ Gem Rain Ended!",
            "description": (
                f"Hosted by **{rain.get('starter_name') or 'Player'}**\n"
                f"**Total Pool:** {format_amount(amount)} gems"
            ).replace("\\n", "\n"),
            "color": 0x5865F2,
            "fields": [
                {"name": "👥 Participants", "value": str(len(joined)), "inline": True},
                {"name": "💰 Share / Person", "value": f"{format_amount(per)} gems", "inline": True},
                {"name": "✅ Status", "value": "Rewards distributed", "inline": False},
            ],
            "footer": {"text": "aqua-gems.com"},
        }
        # fix newlines properly
        embed["description"] = (
            "Hosted by **" + str(rain.get("starter_name") or "Player") + "**\n"
            "**Total Pool:** " + format_amount(amount) + " gems"
        )
        embed["description"] = embed["description"].replace("\\n", "\n")
        if "\n" in embed["description"] and chr(10) not in embed["description"]:
            embed["description"] = embed["description"].replace("\n", chr(10))
        rain_wh = os.environ.get("WEBHOOK_RAIN", "")
        if DISCORD_BOT_TOKEN:
            try:
                r = http.post(
                    f"https://discord.com/api/v10/channels/{RAIN_CHANNEL_ID}/webhooks",
                    headers={"Authorization": f"Bot {DISCORD_BOT_TOKEN}", "Content-Type": "application/json"},
                    json={"name": "Aqua rain notifier"},
                    timeout=12,
                )
                if r.ok:
                    wh = r.json()
                    url = f"https://discord.com/api/webhooks/{wh['id']}/{wh['token']}"
                    _discord_webhook(url, content=content, embeds=[embed])
                    try:
                        http.delete(f"https://discord.com/api/v10/webhooks/{wh['id']}", headers={"Authorization": f"Bot {DISCORD_BOT_TOKEN}"}, timeout=8)
                    except Exception:
                        pass
            except Exception:
                pass
        elif rain_wh:
            _discord_webhook(rain_wh, content=content, embeds=[embed])
    except Exception:
        pass


@app.route("/api/rain/join", methods=["POST"])
def api_rain_join():
    uid, user = _require_user()
    if not uid or not session.get("roblox"):
        return jsonify({"ok": False, "error": "Verify first"}), 401
    body = request.get_json(silent=True) or {}
    rid = body.get("rain_id")
    data = get_data()
    rain = (data.get("active_rains") or {}).get(rid)
    if not rain:
        return jsonify({"ok": False, "error": "Rain not found or ended"}), 404
    if int(time.time()) >= rain.get("ends_at", 0):
        return jsonify({"ok": False, "error": "Rain already ended"}), 400
    joined = rain.setdefault("joined", [])
    if uid in joined:
        return jsonify({"ok": False, "error": "Already joined"}), 400
    joined.append(uid)
    save_data(data)
    return jsonify({"ok": True, "joined": len(joined)})


@app.route("/api/rain/start", methods=["POST"])
def api_rain_start():
    """Called from chat .rain command."""
    uid, user = _require_user()
    if not uid or not session.get("roblox"):
        return jsonify({"ok": False, "error": "Verify first"}), 401
    body = request.get_json(silent=True) or {}
    amount = parse_amount(str(body.get("amount") or "0"))
    if not amount or amount < MIN_AMOUNT if "MIN_AMOUNT" in dir() else 10_000_000:
        min_a = 10_000_000
        if amount is None or amount < min_a:
            return jsonify({"ok": False, "error": f"Min rain {format_amount(min_a)}"}), 400
    data = get_data()
    user = ensure_user(uid, data)
    if user["balance"] < amount:
        return jsonify({"ok": False, "error": "Insufficient balance"}), 400
    user["balance"] -= amount
    rid = secrets.token_hex(4)
    ends = int(time.time()) + RAIN_DURATION
    rain = {
        "id": rid,
        "amount": amount,
        "starter_id": uid,
        "starter_name": user.get("roblox") or user.get("discord_name") or "Player",
        "joined": [uid],  # starter auto-joins
        "ends_at": ends,
        "started_at": int(time.time()),
    }
    data.setdefault("active_rains", {})[rid] = rain
    # Chat message
    data.setdefault("website_chat", []).append({
        "id": secrets.token_hex(4),
        "user": rain["starter_name"],
        "uid": uid,
        "msg": f"🌧️ RAIN STARTED — {format_amount(amount)} · {RAIN_DURATION}s · Join now!",
        "type": "rain",
        "rain_id": rid,
        "ts": int(time.time()),
    })
    data["website_chat"] = data["website_chat"][-200:]
    save_data(data)
    _refresh_session_balance(uid, data)

    # Discord notify — try create webhook or post via bot
    _notify_rain_discord(rain)

    return jsonify({
        "ok": True,
        "rain_id": rid,
        "amount_fmt": format_amount(amount),
        "ends_at": ends,
        "balance": user["balance"],
        "balance_fmt": format_amount(user["balance"]),
    })


def _notify_rain_discord(rain):
    """Post rain notification matching Aqua bot embed style."""
    content = f"<@&{RAIN_ROLE_ID}>"
    desc = (
        "Hosted by **" + str(rain.get("starter_name") or "Player") + "**"
        + chr(10) + "**Total Pool:** " + format_amount(rain["amount"]) + " gems"
        + chr(10) + "**Duration:** " + str(RAIN_DURATION) + "s"
        + chr(10) + chr(10) + "Join now on the website!"
    )
    embed = {
        "title": "🌧️ Gem Rain Started!",
        "description": desc,
        "color": 0xff2a2a,
        "fields": [
            {"name": "📊 Status", "value": "🟢 LIVE", "inline": True},
            {"name": "👥 Joined", "value": str(len(rain.get("joined") or [])), "inline": True},
            {"name": "⏱ Time", "value": str(RAIN_DURATION) + "s", "inline": True},
        ],
        "footer": {"text": "aqua-gems.com"},
    }
    if DISCORD_BOT_TOKEN:
        try:
            r = http.post(
                f"https://discord.com/api/v10/channels/{RAIN_CHANNEL_ID}/webhooks",
                headers={
                    "Authorization": f"Bot {DISCORD_BOT_TOKEN}",
                    "Content-Type": "application/json",
                },
                json={"name": "Aqua rain notifier"},
                timeout=12,
            )
            if r.ok:
                wh = r.json()
                url = f"https://discord.com/api/webhooks/{wh['id']}/{wh['token']}"
                _discord_webhook(url, content=content, embeds=[embed])
                try:
                    http.delete(
                        f"https://discord.com/api/v10/webhooks/{wh['id']}",
                        headers={"Authorization": f"Bot {DISCORD_BOT_TOKEN}"},
                        timeout=8,
                    )
                except Exception:
                    pass
                return
        except Exception:
            pass
    rain_wh = os.environ.get("WEBHOOK_RAIN", "")
    if rain_wh:
        _discord_webhook(rain_wh, content=content, embeds=[embed])




@app.route("/api/tip", methods=["POST"])
def api_tip():
    uid, user = _require_user()
    if not uid or not session.get("roblox"):
        return jsonify({"ok": False, "error": "Verify first"}), 401
    body = request.get_json(silent=True) or {}
    target_name = (body.get("user") or "").strip()
    amount = parse_amount(str(body.get("amount") or "0"))
    if not target_name or not amount or amount <= 0:
        return jsonify({"ok": False, "error": "Invalid user or amount"}), 400
    data = get_data()
    user = ensure_user(uid, data)
    if user["balance"] < amount:
        return jsonify({"ok": False, "error": "Insufficient balance"}), 400
    t_uid, t_user = find_user_by_roblox_name(target_name, data)
    if not t_uid:
        return jsonify({"ok": False, "error": "User not found"}), 404
    if t_uid == uid:
        return jsonify({"ok": False, "error": "Cannot tip yourself"}), 400
    user["balance"] -= amount
    t_user = ensure_user(t_uid, data)
    t_user["balance"] = t_user.get("balance", 0) + amount
    add_history(uid, "Tip", amount, f"to {target_name}", data)
    add_history(t_uid, "Tip", amount, f"from {user.get('roblox')}", data)
    data.setdefault("website_chat", []).append({
        "id": secrets.token_hex(4),
        "user": "SYSTEM",
        "uid": "0",
        "msg": f"💸 {user.get('roblox')} tipped {format_amount(amount)} to {target_name}",
        "type": "tip",
        "ts": int(time.time()),
    })
    data["website_chat"] = data["website_chat"][-200:]
    save_data(data)
    _refresh_session_balance(uid, data)
    return jsonify({
        "ok": True,
        "balance": user["balance"],
        "balance_fmt": format_amount(user["balance"]),
    })


# Admin chat
@app.route("/api/admin/chat", methods=["GET", "POST"])
def api_admin_chat():
    if not session.get("is_admin"):
        return jsonify({"ok": False, "error": "Admin only"}), 403
    data = get_data()
    if request.method == "GET":
        return jsonify({"ok": True, "messages": data.get("admin_chat", [])[-100:]})
    body = request.get_json(silent=True) or {}
    msg = (body.get("msg") or "").strip()[:500]
    if not msg:
        return jsonify({"ok": False, "error": "Empty"}), 400
    entry = {
        "id": secrets.token_hex(4),
        "user": session.get("admin_user") or "admin",
        "msg": msg,
        "ts": int(time.time()),
    }
    data.setdefault("admin_chat", []).append(entry)
    data["admin_chat"] = data["admin_chat"][-200:]
    save_data(data)
    return jsonify({"ok": True, "message": entry})




try:
    from shop_routes import register_shop_routes
    register_shop_routes(
        app,
        get_data=get_data,
        save_data=save_data,
        ensure_user=ensure_user,
        _require_user=_require_user,
        _refresh_session_balance=_refresh_session_balance,
        format_amount=format_amount,
        user_level=user_level,
        HOUSE_EDGE=HOUSE_EDGE,
    )
except Exception as _e:
    print("shop_routes not loaded:", _e)


if __name__ == "__main__":
    print("=" * 56)
    print("  Aqua Gems  ·  https://aqua-gems.com")
    print(f"  Listening  ·  http://{HOST}:{PORT}")
    print(f"  Slots      ·  {len(SLOTS)} machines")
    print("=" * 56)
    app.run(host=HOST, port=PORT, debug=False)
