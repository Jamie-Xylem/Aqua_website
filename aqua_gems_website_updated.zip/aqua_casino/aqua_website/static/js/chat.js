(function () {
  const panel = document.getElementById("chatPanel");
  const overlay = document.getElementById("chatOverlay");
  const toggle = document.getElementById("chatToggle");
  const closeBtn = document.getElementById("chatClose");
  const messages = document.getElementById("chatMessages");
  const input = document.getElementById("chatInput");
  const send = document.getElementById("chatSend");
  let replyTo = null;

  function openChat() {
    panel.classList.add("open");
    overlay.classList.add("open");
    loadChat();
  }
  function closeChat() {
    panel.classList.remove("open");
    overlay.classList.remove("open");
  }
  if (toggle) toggle.addEventListener("click", openChat);
  if (closeBtn) closeBtn.addEventListener("click", closeChat);
  if (overlay) overlay.addEventListener("click", closeChat);

  function escapeHtml(s) {
    return String(s || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  async function loadChat() {
    try {
      const r = await fetch("/api/chat");
      const j = await r.json();
      if (!j.ok) return;
      messages.innerHTML = "";
      (j.messages || []).forEach((m) => {
        const d = document.createElement("div");
        const txt = m.msg || m.text || "";
        if (m.type === "rain" || (txt && txt.indexOf("RAIN STARTED") !== -1)) {
          d.className = "chat-msg rain-msg";
          d.innerHTML =
            '<img src="/static/img/banner_rain.jpg" alt="Rain" />' +
            '<div class="rain-body"><div><div class="who">' + escapeHtml(m.user) + '</div>' +
            '<div class="txt">' + escapeHtml(txt) + '</div></div>' +
            (m.rain_id ? '<button class="btn btn-red btn-sm join-rain" data-id="' + escapeHtml(m.rain_id) + '">Join</button>' : '') +
            '</div>';
          const btn = d.querySelector(".join-rain");
          if (btn) {
            btn.addEventListener("click", async (e) => {
              e.stopPropagation();
              const rr = await fetch("/api/rain/join", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ rain_id: btn.dataset.id }),
              });
              const jj = await rr.json();
              alert(jj.ok ? "Joined!" : jj.error || "Failed");
            });
          }
        } else {
          d.className = "chat-msg" + (m.reply_to ? " reply" : "");
          d.dataset.id = m.id || "";
          let extra = m.reply_to ? '<div class="reply-ref">↩ reply</div>' : "";
          const nc = m.name_color || "#2ee6d6";
          const tc = m.text_color || "#e8ecf4";
          const border = m.avatar_border || "none";
          const borderColor = {gold:"#ffc857",red:"#ff3b4a",cyan:"#2ee6d6",rainbow:"#ff00aa"}[border] || "transparent";
          const av = m.avatar
            ? '<div class="avatar-wrap" style="border-color:' + borderColor + '"><img src="' + escapeHtml(m.avatar) + '" style="width:100%;height:100%;object-fit:cover" /></div>'
            : "";
          const lvl = m.level ? '<span class="lvl">Lv ' + m.level + '</span>' : "";
          d.innerHTML = extra + '<div class="row">' + av + '<div style="flex:1;min-width:0">' +
            '<div class="who" style="color:' + nc + '">' + escapeHtml(m.user) + lvl + '</div>' +
            '<div class="txt" style="color:' + tc + '">' + escapeHtml(txt) + '</div></div></div>';
          d.addEventListener("click", () => {
            replyTo = m.id || m.user;
            if (input) {
              input.placeholder = "Reply to " + m.user + "…";
              input.focus();
            }
          });
        }
        messages.appendChild(d);
      });
      messages.scrollTop = messages.scrollHeight;
    } catch (e) {}
  }

  function showTipModal(preUser, preAmt) {
    const backdrop = document.createElement("div");
    backdrop.className = "modal-backdrop";
    backdrop.innerHTML =
      '<div class="modal-card"><h3>Send Tip</h3>' +
      '<input class="cool-input" id="tipUser" placeholder="Roblox username" value="' + escapeHtml(preUser || "") + '" />' +
      '<input class="cool-input" id="tipAmt" placeholder="Amount (e.g. 10m)" value="' + escapeHtml(preAmt || "") + '" />' +
      '<div class="modal-actions">' +
      '<button class="btn btn-ghost" id="tipCancel">Cancel</button>' +
      '<button class="btn btn-red" id="tipConfirm">Confirm</button></div></div>';
    document.body.appendChild(backdrop);
    backdrop.querySelector("#tipCancel").onclick = () => backdrop.remove();
    backdrop.querySelector("#tipConfirm").onclick = async () => {
      const user = backdrop.querySelector("#tipUser").value.trim();
      const amount = backdrop.querySelector("#tipAmt").value.trim();
      const r = await fetch("/api/tip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user, amount }),
      });
      const j = await r.json();
      if (j.ok) {
        if (window.AQUA) window.AQUA.balance = j.balance;
        const bal = document.getElementById("topBalance");
        if (bal) bal.textContent = "💎 " + j.balance_fmt;
        backdrop.remove();
        loadChat();
      } else alert(j.error || "Tip failed");
    };
  }

  async function sendMsg() {
    if (!window.AQUA || !window.AQUA.verified) return;
    const text = (input.value || "").trim();
    if (!text) return;
    input.value = "";
    try {
      const r = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, reply_to: replyTo }),
      });
      const j = await r.json();
      replyTo = null;
      if (input) input.placeholder = "Message or .tip / .rain…";
      if (j.action === "tip_ui") {
        showTipModal(j.user, j.amount);
        return;
      }
      if (j.action === "rain") {
        const rr = await fetch("/api/rain/start", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ amount: j.amount }),
        });
        const jj = await rr.json();
        if (!jj.ok) alert(jj.error || "Rain failed");
        else {
          if (window.AQUA) window.AQUA.balance = jj.balance;
          const bal = document.getElementById("topBalance");
          if (bal) bal.textContent = "💎 " + jj.balance_fmt;
        }
        loadChat();
        return;
      }
      loadChat();
    } catch (e) {}
  }

  if (send) send.addEventListener("click", sendMsg);
  if (input) {
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") sendMsg();
    });
  }
  setInterval(() => {
    if (panel && panel.classList.contains("open")) loadChat();
  }, 3500);
})();
