"""Website on/off + DM verify + verify logs for Aqua Gems."""
from __future__ import annotations

import json
import re
from pathlib import Path

import discord
from discord import app_commands

from bot_instance import bot, tree
from data import DATA, save_data

# website_admin.py lives in aqua_casino/
# casino_data.json is in the container root (one level up)
_HERE = Path(__file__).resolve().parent  # .../aqua_casino/
_CANDIDATES = [
    _HERE.parent / "casino_data.json",  # /home/container/casino_data.json
    _HERE / "casino_data.json",         # /home/container/aqua_casino/casino_data.json
]
DATA_FILE = next(
    (p for p in _CANDIDATES if p.is_file()),
    _HERE / "casino_data.json",
)
print("website_admin DATA_FILE =", DATA_FILE)

OWNER_IDS = {1500198665933820004, 1484127642151288913}
FLAG = _HERE / "Aqua_Website" / "OFFLINE.flag"
VERIFY_LOG_CHANNEL_ID = 1538582193041973248

CODE_RE = re.compile(r"\b(WEB-[A-F0-9]{6})\b", re.I)


def _can_toggle(interaction: discord.Interaction) -> bool:
    if interaction.user.id in OWNER_IDS:
        return True
    if isinstance(interaction.user, discord.Member):
        return interaction.user.guild_permissions.administrator
    return False


async def _log_verify(embed: discord.Embed) -> None:
    ch = bot.get_channel(VERIFY_LOG_CHANNEL_ID)
    if ch is None:
        try:
            ch = await bot.fetch_channel(VERIFY_LOG_CHANNEL_ID)
        except Exception as e:
            print("verify log channel error:", e)
            return
    try:
        await ch.send(embed=embed)
    except Exception as e:
        print("verify log send error:", e)


@tree.command(name="website", description="Turn the Aqua website on or off")
@app_commands.describe(state="on or off")
@app_commands.choices(
    state=[
        app_commands.Choice(name="on", value="on"),
        app_commands.Choice(name="off", value="off"),
    ]
)
async def website_cmd(interaction: discord.Interaction, state: app_commands.Choice[str]):
    if not _can_toggle(interaction):
        await interaction.response.send_message("❌ Owner/admin only.", ephemeral=True)
        return

    FLAG.parent.mkdir(parents=True, exist_ok=True)

    if state.value == "off":
        FLAG.write_text("1", encoding="utf-8")
        msg = "🛠️ Website **OFFLINE**"
    else:
        if FLAG.exists():
            FLAG.unlink()
        msg = "✅ Website **ONLINE**"

    await interaction.response.send_message(msg, ephemeral=False)


def _load_pending() -> dict:
    """Always read website_verify_pending from disk (website writes it)."""
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("website_verify_pending") or {}
    except Exception as e:
        print("reload pending error:", e)
        return {}


def _save_pending(pending: dict) -> None:
    """Write pending back to disk and keep in-memory DATA in sync."""
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = {}
    data["website_verify_pending"] = pending
    try:
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print("save pending error:", e)
        return
    try:
        DATA["website_verify_pending"] = pending
        save_data()
    except Exception:
        pass


@bot.listen("on_message")
async def website_verify_dm(message: discord.Message):
    if message.author.bot:
        return
    if message.guild is not None:
        return  # DMs only

    m = CODE_RE.search(message.content or "")
    if not m:
        return

    code = m.group(1).upper()
    pending = _load_pending()
    entry = pending.get(code)
    author = message.author

    if not entry:
        await message.channel.send("❌ That website code is invalid or expired.")
        await _log_verify(
            discord.Embed(
                title="Website verify — invalid code",
                description=(
                    f"**User:** {author.mention} (`{author.id}`)\n"
                    f"**Code:** `{code}`\n"
                    f"**Result:** invalid or expired\n"
                    f"**Data file:** `{DATA_FILE}`"
                ),
                color=0xED4245,
            )
        )
        return

    if str(author.id) != str(entry.get("discord_id")):
        await message.channel.send("❌ This code belongs to a different Discord account.")
        await _log_verify(
            discord.Embed(
                title="Website verify — wrong Discord",
                description=(
                    f"**User:** {author.mention} (`{author.id}`)\n"
                    f"**Expected Discord:** `{entry.get('discord_id')}`\n"
                    f"**Code:** `{code}`\n"
                    f"**Roblox:** `{entry.get('roblox_username')}`"
                ),
                color=0xFEE75C,
            )
        )
        return

    entry["dm_ok"] = True
    pending[code] = entry
    _save_pending(pending)

    await message.channel.send(
        f"✅ Website verify confirmed for `{code}`.\n"
        "Go back to the site and tap **I DID BOTH — CONFIRM**."
    )
    await _log_verify(
        discord.Embed(
            title="Website verify — DM confirmed",
            description=(
                f"**User:** {author.mention} (`{author.id}`)\n"
                f"**Code:** `{code}`\n"
                f"**Roblox:** `{entry.get('roblox_username')}`\n"
                f"**Roblox ID:** `{entry.get('roblox_id')}`\n"
                f"**Result:** dm_ok = true (waiting for site confirm)"
            ),
            color=0x57F287,
        )
    )
