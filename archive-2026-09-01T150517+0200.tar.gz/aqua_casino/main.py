"""
Aqua Gems Casino — main entry point.

This file only wires everything together. Game logic lives in:
  mines.py, towers.py, colordice.py, blackjack.py, coinflip.py,
  slots.py, deposit.py, verification.py, economy.py, tip.py,
  affiliates.py, admin.py, invite_event.py, plus shared
  config/data/utils/bot_instance.
"""
import asyncio
import io
import random
import string

import aiohttp
import discord
from discord import app_commands
from discord.ext import tasks, commands

from bot_instance import bot, tree
from config import TOKEN, config
from data import DATA, save_data, ensure_user
from utils import normal_embed, get_live_profit_embed

# Register all slash commands by importing feature modules
import admin          # noqa: F401
import verification   # noqa: F401
import tip            # noqa: F401
import economy        # noqa: F401
import mines          # noqa: F401
import towers         # noqa: F401
import colordice      # noqa: F401
import affiliates     # noqa: F401
import slots          # noqa: F401
import deposit        # noqa: F401
import blackjack      # noqa: F401
import coinflip       # noqa: F401
import invite_event   # noqa: F401
import website_admin  # noqa: F401

from verification import VerificationPanelView
from deposit import DepositTicketView, WithdrawTicketView


# ============================================================
# STARTUP CHANNEL CLEANER + DISABLE GEOGUESSR
# ============================================================

GEOGUESSR_ENABLED = False  # disables geoguessr on restart



# ============================================================
# LIVE PROFIT TRACKER
# ============================================================

@tasks.loop(seconds=5)
async def update_profit_trackers():
    """Edits the live profit tracker message in every guild every 5 seconds."""
    profit_embed = get_live_profit_embed()
    ids_map = DATA["global_stats"].setdefault("profit_tracker_message_ids", {})
    changed = False

    for guild in bot.guilds:
        stats_channel = guild.get_channel(
            __import__("config", fromlist=["PROFIT_TRACKER_CHANNEL_ID"]).PROFIT_TRACKER_CHANNEL_ID
        )
        if not stats_channel:
            continue

        guild_key = str(guild.id)
        msg_id = ids_map.get(guild_key)

        try:
            if msg_id:
                try:
                    msg = await stats_channel.fetch_message(msg_id)
                    await msg.edit(embed=profit_embed)
                    continue
                except discord.NotFound:
                    pass

            new_msg = await stats_channel.send(embed=profit_embed)
            ids_map[guild_key] = new_msg.id
            changed = True
        except Exception as e:
            print(f"Profit tracker update error in guild {guild.id}: {e}")

    if changed:
        save_data()


import economy as _economy
_economy.update_profit_trackers = update_profit_trackers


# ============================================================
# TRIVIA / CHALLENGES
# ============================================================

OWNER_ID = 1500198665933820004, 1484127642151288913

TRIVIA_REWARD_NORMAL = 15_000_000
TRIVIA_REWARD_BOOSTED = 2_500_000
TRIVIA_REWARD_GEO = 40_000_000
TRIVIA_ROLE_PING = "<@&1541412570043519076>"
TRIVIA_TIMEOUT = 60.0

trivia_boosted = False
trivia_boosted_by = None


def _current_reward() -> int:
    return TRIVIA_REWARD_BOOSTED if trivia_boosted else TRIVIA_REWARD_NORMAL


def _format_reward(amount: int) -> str:
    if amount >= 1_000_000:
        return f"{amount // 1_000_000}m"
    return str(amount)


def _reward_text() -> str:
    return f"**{_format_reward(_current_reward())} gems**"


def _boost_footer():
    if trivia_boosted and trivia_boosted_by:
        return (
            f"⚡ Trivia boosted by {trivia_boosted_by} — "
            f"rounds every 1 min • prize {_format_reward(TRIVIA_REWARD_BOOSTED)} gems"
        )
    return None


TRIVIA_QUESTIONS = [
    ("What is the capital of France?", "paris"),
    ("What is the capital of Japan?", "tokyo"),
    ("What is the capital of Italy?", "rome"),
    ("What is the capital of Spain?", "madrid"),
    ("What is the capital of Germany?", "berlin"),
    ("What is the capital of Canada?", "ottawa"),
    ("Hi - From Methanol", "Hi"),
    ("How many continents are there?", "7"),
    ("How many planets are in our solar system?", "8"),
    ("What is H2O commonly known as?", "water"),
    ("What gas do plants absorb from the air?", "carbon dioxide"),
    ("What is the largest ocean on Earth?", "pacific"),
    ("What is the tallest mountain in the world?", "everest"),
    ("How many sides does a hexagon have?", "6"),
    ("How many sides does an octagon have?", "8"),
    ("What is 12 × 12?", "144"),
    ("What colour do you get mixing red and blue?", "purple"),
    ("What is the freezing point of water in Celsius?", "0"),
    ("What is the boiling point of water in Celsius?", "100"),
    ("Who painted the Mona Lisa?", "leonardo da vinci"),
    ("What year did World War 2 end?", "1945"),
    ("What is the chemical symbol for gold?", "au"),
    ("What is the chemical symbol for silver?", "ag"),
    ("How many hours are in a day?", "24"),
    ("How many minutes are in an hour?", "60"),
    ("What is the square root of 81?", "9"),
    ("What is the square root of 144?", "12"),
    ("Which planet is known as the Red Planet?", "mars"),
    ("Which planet is closest to the Sun?", "mercury"),
    ("What is the largest mammal?", "blue whale"),
    ("How many legs does a spider have?", "8"),
    ("How many legs does an insect have?", "6"),
    ("What do bees make?", "honey"),
    ("What is the main language spoken in Brazil?", "portuguese"),
    ("What currency is used in Japan?", "yen"),
    ("What currency is used in the UK?", "pound"),
    ("What is the opposite of hot?", "cold"),
    ("What is the opposite of up?", "down"),
    ("How many days are in a leap year?", "366"),
    ("How many days are in a normal year?", "365"),
    ("What casino game uses a round wheel and a ball?", "roulette"),
    ("In blackjack, what is the best possible hand?", "21"),
    ("What do you call two identical cards in poker?", "pair"),
    ("What colour is the highest value chip often associated with?", "black"),
    ("What is 2 to the power of 10?", "1024"),
]

TYPING_PHRASES = [
    "aqua gems casino",
    "stack those gems",
    "jackpot winner",
    "lucky streak",
    "high roller",
    "all in",
    "double or nothing",
    "spin to win",
    "diamond hands",
    "big win energy",
    "casino royal",
    "fortune favors the bold",
    "type this fast",
    "quick fingers win",
    "gems on gems",
    "aqua is life",
    "never fold early",
    "hit or stand",
    "roll the dice",
    "flip the coin",
]

UNSCRAMBLE_WORDS = [
    "casino", "jackpot", "diamond", "fortune", "winner", "streak",
    "roulette", "blackjack", "slots", "poker", "gems", "aqua",
    "lucky", "riches", "bonus", "payout", "dealer", "chip",
    "spin", "bet", "vault", "treasure", "reward", "prize",
]

REVERSE_WORDS = [
    "aqua", "gems", "casino", "lucky", "winner", "jackpot",
    "diamond", "fortune", "bonus", "streak", "chips", "spin",
]

EMOJI_SEQUENCES = [
    ("💎🔥💎", "💎🔥💎"),
    ("🌊💎🌊", "🌊💎🌊"),
    ("🎰7️⃣🎰", "🎰7️⃣🎰"),
    ("🍀💰🍀", "🍀💰🍀"),
    ("🎲🎲🎲", "🎲🎲🎲"),
    ("👑💎👑", "👑💎👑"),
    ("⚡💎⚡", "⚡💎⚡"),
]


# ============================================================
# GEOGUESSR — every country, random map view each time
# Uses OpenStreetMap (Google Street View needs a paid API key).
# Each country has a bbox; we pick a random lat/lon + zoom = unique image.
# ============================================================

# name, answers, bbox = (min_lat, max_lat, min_lon, max_lon)
GEO_COUNTRIES = [
    {"name": "afghanistan", "answers": ["afghanistan"], "bbox": (29.4, 38.5, 60.5, 74.9)},
    {"name": "albania", "answers": ["albania"], "bbox": (39.6, 42.7, 19.3, 21.1)},
    {"name": "algeria", "answers": ["algeria"], "bbox": (19.1, 37.1, -8.7, 12.0)},
    {"name": "andorra", "answers": ["andorra"], "bbox": (42.43, 42.66, 1.41, 1.79)},
    {"name": "angola", "answers": ["angola"], "bbox": (-18.0, -4.4, 11.7, 24.1)},
    {"name": "antigua and barbuda", "answers": ["antigua and barbuda", "antigua"], "bbox": (16.9, 17.7, -62.0, -61.7)},
    {"name": "argentina", "answers": ["argentina"], "bbox": (-54.8, -21.8, -73.6, -53.6)},
    {"name": "armenia", "answers": ["armenia"], "bbox": (38.8, 41.3, 43.4, 46.6)},
    {"name": "australia", "answers": ["australia"], "bbox": (-43.6, -10.7, 113.3, 153.6)},
    {"name": "austria", "answers": ["austria"], "bbox": (46.4, 49.0, 9.5, 17.2)},
    {"name": "azerbaijan", "answers": ["azerbaijan"], "bbox": (38.4, 41.9, 44.8, 50.4)},
    {"name": "bahamas", "answers": ["bahamas"], "bbox": (20.9, 26.9, -79.0, -72.7)},
    {"name": "bahrain", "answers": ["bahrain"], "bbox": (25.8, 26.3, 50.4, 50.8)},
    {"name": "bangladesh", "answers": ["bangladesh"], "bbox": (20.7, 26.6, 88.0, 92.7)},
    {"name": "barbados", "answers": ["barbados"], "bbox": (13.0, 13.3, -59.7, -59.4)},
    {"name": "belarus", "answers": ["belarus"], "bbox": (51.3, 56.2, 23.2, 32.8)},
    {"name": "belgium", "answers": ["belgium"], "bbox": (49.5, 51.5, 2.5, 6.4)},
    {"name": "belize", "answers": ["belize"], "bbox": (15.9, 18.5, -89.2, -87.5)},
    {"name": "benin", "answers": ["benin"], "bbox": (6.2, 12.4, 0.8, 3.8)},
    {"name": "bhutan", "answers": ["bhutan"], "bbox": (26.7, 28.3, 88.7, 92.1)},
    {"name": "bolivia", "answers": ["bolivia"], "bbox": (-22.9, -9.7, -69.6, -57.5)},
    {"name": "bosnia and herzegovina", "answers": ["bosnia and herzegovina", "bosnia"], "bbox": (42.6, 45.3, 15.7, 19.6)},
    {"name": "botswana", "answers": ["botswana"], "bbox": (-26.9, -17.8, 20.0, 29.4)},
    {"name": "brazil", "answers": ["brazil", "brasil"], "bbox": (-33.7, 5.3, -73.9, -34.8)},
    {"name": "brunei", "answers": ["brunei"], "bbox": (4.0, 5.0, 114.1, 115.4)},
    {"name": "bulgaria", "answers": ["bulgaria"], "bbox": (41.2, 44.2, 22.4, 28.6)},
    {"name": "burkina faso", "answers": ["burkina faso"], "bbox": (9.4, 15.1, -5.5, 2.4)},
    {"name": "burundi", "answers": ["burundi"], "bbox": (-4.5, -2.3, 29.0, 30.8)},
    {"name": "cabo verde", "answers": ["cabo verde", "cape verde"], "bbox": (14.8, 17.2, -25.4, -22.7)},
    {"name": "cambodia", "answers": ["cambodia"], "bbox": (10.4, 14.7, 102.3, 107.6)},
    {"name": "cameroon", "answers": ["cameroon"], "bbox": (1.7, 13.1, 8.5, 16.2)},
    {"name": "canada", "answers": ["canada"], "bbox": (42.0, 69.6, -141.0, -52.6)},
    {"name": "central african republic", "answers": ["central african republic", "car"], "bbox": (2.2, 11.0, 14.4, 27.5)},
    {"name": "chad", "answers": ["chad"], "bbox": (7.4, 23.5, 13.5, 24.0)},
    {"name": "chile", "answers": ["chile"], "bbox": (-55.9, -17.5, -75.6, -66.4)},
    {"name": "china", "answers": ["china"], "bbox": (18.2, 53.6, 73.5, 134.8)},
    {"name": "colombia", "answers": ["colombia"], "bbox": (-4.2, 12.5, -79.0, -66.9)},
    {"name": "comoros", "answers": ["comoros"], "bbox": (-12.4, -11.4, 43.2, 44.5)},
    {"name": "congo", "answers": ["congo", "republic of the congo"], "bbox": (-5.0, 3.7, 11.2, 18.6)},
    {"name": "costa rica", "answers": ["costa rica"], "bbox": (8.0, 11.2, -85.9, -82.6)},
    {"name": "croatia", "answers": ["croatia"], "bbox": (42.4, 46.5, 13.5, 19.4)},
    {"name": "cuba", "answers": ["cuba"], "bbox": (19.8, 23.3, -84.9, -74.1)},
    {"name": "cyprus", "answers": ["cyprus"], "bbox": (34.6, 35.7, 32.3, 34.6)},
    {"name": "czechia", "answers": ["czechia", "czech republic"], "bbox": (48.6, 51.1, 12.1, 18.9)},
    {"name": "democratic republic of the congo", "answers": ["democratic republic of the congo", "drc", "congo kinshasa"], "bbox": (-13.5, 5.4, 12.2, 31.3)},
    {"name": "denmark", "answers": ["denmark"], "bbox": (54.6, 57.8, 8.1, 12.7)},
    {"name": "djibouti", "answers": ["djibouti"], "bbox": (10.9, 12.7, 41.8, 43.4)},
    {"name": "dominica", "answers": ["dominica"], "bbox": (15.2, 15.6, -61.5, -61.2)},
    {"name": "dominican republic", "answers": ["dominican republic"], "bbox": (17.5, 19.9, -72.0, -68.3)},
    {"name": "ecuador", "answers": ["ecuador"], "bbox": (-5.0, 1.5, -81.0, -75.2)},
    {"name": "egypt", "answers": ["egypt"], "bbox": (22.0, 31.7, 24.7, 35.8)},
    {"name": "el salvador", "answers": ["el salvador"], "bbox": (13.2, 14.4, -90.1, -87.7)},
    {"name": "equatorial guinea", "answers": ["equatorial guinea"], "bbox": (0.9, 2.3, 9.3, 11.3)},
    {"name": "eritrea", "answers": ["eritrea"], "bbox": (12.4, 18.0, 36.4, 43.1)},
    {"name": "estonia", "answers": ["estonia"], "bbox": (57.5, 59.7, 21.8, 28.2)},
    {"name": "eswatini", "answers": ["eswatini", "swaziland"], "bbox": (-27.3, -25.7, 30.8, 32.1)},
    {"name": "ethiopia", "answers": ["ethiopia"], "bbox": (3.4, 14.9, 33.0, 48.0)},
    {"name": "fiji", "answers": ["fiji"], "bbox": (-19.1, -16.1, 177.0, 180.0)},
    {"name": "finland", "answers": ["finland"], "bbox": (59.8, 70.1, 20.6, 31.6)},
    {"name": "france", "answers": ["france"], "bbox": (42.3, 51.1, -5.1, 8.2)},
    {"name": "gabon", "answers": ["gabon"], "bbox": (-3.9, 2.3, 8.7, 14.5)},
    {"name": "gambia", "answers": ["gambia", "the gambia"], "bbox": (13.1, 13.8, -16.8, -13.8)},
    {"name": "georgia", "answers": ["georgia"], "bbox": (41.1, 43.6, 40.0, 46.7)},
    {"name": "germany", "answers": ["germany", "deutschland"], "bbox": (47.3, 55.1, 5.9, 15.0)},
    {"name": "ghana", "answers": ["ghana"], "bbox": (4.7, 11.2, -3.3, 1.2)},
    {"name": "greece", "answers": ["greece"], "bbox": (34.8, 41.7, 19.4, 28.2)},
    {"name": "grenada", "answers": ["grenada"], "bbox": (12.0, 12.5, -61.8, -61.6)},
    {"name": "guatemala", "answers": ["guatemala"], "bbox": (13.7, 17.8, -92.2, -88.2)},
    {"name": "guinea", "answers": ["guinea"], "bbox": (7.2, 12.7, -15.1, -7.6)},
    {"name": "guinea-bissau", "answers": ["guinea-bissau", "guinea bissau"], "bbox": (10.9, 12.7, -16.7, -13.6)},
    {"name": "guyana", "answers": ["guyana"], "bbox": (1.2, 8.6, -61.4, -56.5)},
    {"name": "haiti", "answers": ["haiti"], "bbox": (18.0, 20.1, -74.5, -71.6)},
    {"name": "honduras", "answers": ["honduras"], "bbox": (12.9, 16.5, -89.4, -83.2)},
    {"name": "hungary", "answers": ["hungary"], "bbox": (45.7, 48.6, 16.1, 22.9)},
    {"name": "iceland", "answers": ["iceland"], "bbox": (63.3, 66.5, -24.5, -13.5)},
    {"name": "india", "answers": ["india"], "bbox": (8.1, 35.5, 68.2, 97.4)},
    {"name": "indonesia", "answers": ["indonesia"], "bbox": (-10.9, 5.9, 95.0, 141.0)},
    {"name": "iran", "answers": ["iran"], "bbox": (25.1, 39.8, 44.0, 63.3)},
    {"name": "iraq", "answers": ["iraq"], "bbox": (29.1, 37.4, 38.8, 48.6)},
    {"name": "ireland", "answers": ["ireland"], "bbox": (51.4, 55.4, -10.5, -6.0)},
    {"name": "israel", "answers": ["israel"], "bbox": (29.5, 33.3, 34.3, 35.9)},
    {"name": "italy", "answers": ["italy", "italia"], "bbox": (36.6, 47.1, 6.6, 18.5)},
    {"name": "ivory coast", "answers": ["ivory coast", "cote divoire", "côte d'ivoire"], "bbox": (4.4, 10.7, -8.6, -2.5)},
    {"name": "jamaica", "answers": ["jamaica"], "bbox": (17.7, 18.5, -78.4, -76.2)},
    {"name": "japan", "answers": ["japan"], "bbox": (30.5, 45.5, 129.5, 145.8)},
    {"name": "jordan", "answers": ["jordan"], "bbox": (29.2, 33.4, 34.9, 39.3)},
    {"name": "kazakhstan", "answers": ["kazakhstan"], "bbox": (40.6, 55.4, 46.5, 87.3)},
    {"name": "kenya", "answers": ["kenya"], "bbox": (-4.7, 5.0, 33.9, 41.9)},
    {"name": "kiribati", "answers": ["kiribati"], "bbox": (1.7, 3.3, 172.6, 173.4)},
    {"name": "kuwait", "answers": ["kuwait"], "bbox": (28.5, 30.1, 46.6, 48.4)},
    {"name": "kyrgyzstan", "answers": ["kyrgyzstan"], "bbox": (39.2, 43.2, 69.3, 80.3)},
    {"name": "laos", "answers": ["laos"], "bbox": (13.9, 22.5, 100.1, 107.6)},
    {"name": "latvia", "answers": ["latvia"], "bbox": (55.7, 58.1, 21.0, 28.2)},
    {"name": "lebanon", "answers": ["lebanon"], "bbox": (33.1, 34.7, 35.1, 36.6)},
    {"name": "lesotho", "answers": ["lesotho"], "bbox": (-30.7, -28.6, 27.0, 29.5)},
    {"name": "liberia", "answers": ["liberia"], "bbox": (4.3, 8.6, -11.5, -7.4)},
    {"name": "libya", "answers": ["libya"], "bbox": (19.5, 33.2, 9.4, 25.2)},
    {"name": "liechtenstein", "answers": ["liechtenstein"], "bbox": (47.05, 47.27, 9.47, 9.64)},
    {"name": "lithuania", "answers": ["lithuania"], "bbox": (53.9, 56.4, 21.0, 26.8)},
    {"name": "luxembourg", "answers": ["luxembourg"], "bbox": (49.4, 50.2, 5.7, 6.5)},
    {"name": "madagascar", "answers": ["madagascar"], "bbox": (-25.6, -11.9, 43.2, 50.5)},
    {"name": "malawi", "answers": ["malawi"], "bbox": (-17.1, -9.4, 32.7, 35.9)},
    {"name": "malaysia", "answers": ["malaysia"], "bbox": (1.3, 7.4, 99.6, 119.3)},
    {"name": "maldives", "answers": ["maldives"], "bbox": (-0.7, 7.1, 72.6, 73.7)},
    {"name": "mali", "answers": ["mali"], "bbox": (10.2, 25.0, -12.2, 4.3)},
    {"name": "malta", "answers": ["malta"], "bbox": (35.8, 36.1, 14.2, 14.6)},
    {"name": "marshall islands", "answers": ["marshall islands"], "bbox": (5.6, 11.7, 160.8, 172.0)},
    {"name": "mauritania", "answers": ["mauritania"], "bbox": (14.7, 27.3, -17.1, -4.8)},
    {"name": "mauritius", "answers": ["mauritius"], "bbox": (-20.5, -19.9, 57.3, 57.8)},
    {"name": "mexico", "answers": ["mexico"], "bbox": (14.5, 32.7, -117.1, -86.7)},
    {"name": "micronesia", "answers": ["micronesia", "federated states of micronesia"], "bbox": (5.3, 9.6, 138.1, 163.0)},
    {"name": "moldova", "answers": ["moldova"], "bbox": (45.5, 48.5, 26.6, 30.2)},
    {"name": "monaco", "answers": ["monaco"], "bbox": (43.72, 43.75, 7.41, 7.44)},
    {"name": "mongolia", "answers": ["mongolia"], "bbox": (41.6, 52.1, 87.8, 119.9)},
    {"name": "montenegro", "answers": ["montenegro"], "bbox": (41.9, 43.6, 18.4, 20.4)},
    {"name": "morocco", "answers": ["morocco"], "bbox": (27.7, 35.9, -13.2, -1.0)},
    {"name": "mozambique", "answers": ["mozambique"], "bbox": (-26.9, -10.5, 30.2, 40.8)},
    {"name": "myanmar", "answers": ["myanmar", "burma"], "bbox": (9.9, 28.5, 92.2, 101.2)},
    {"name": "namibia", "answers": ["namibia"], "bbox": (-28.9, -16.9, 11.7, 25.3)},
    {"name": "nauru", "answers": ["nauru"], "bbox": (-0.55, -0.50, 166.90, 166.96)},
    {"name": "nepal", "answers": ["nepal"], "bbox": (26.3, 30.4, 80.1, 88.2)},
    {"name": "netherlands", "answers": ["netherlands", "holland"], "bbox": (50.8, 53.5, 3.4, 7.2)},
    {"name": "new zealand", "answers": ["new zealand"], "bbox": (-47.3, -34.4, 166.4, 178.6)},
    {"name": "nicaragua", "answers": ["nicaragua"], "bbox": (10.7, 15.0, -87.7, -83.1)},
    {"name": "niger", "answers": ["niger"], "bbox": (11.7, 23.5, 0.2, 16.0)},
    {"name": "nigeria", "answers": ["nigeria"], "bbox": (4.3, 13.9, 2.7, 14.7)},
    {"name": "north korea", "answers": ["north korea", "dprk"], "bbox": (37.7, 43.0, 124.3, 130.7)},
    {"name": "north macedonia", "answers": ["north macedonia", "macedonia"], "bbox": (40.9, 42.4, 20.5, 23.0)},
    {"name": "norway", "answers": ["norway"], "bbox": (58.0, 71.2, 4.6, 31.1)},
    {"name": "oman", "answers": ["oman"], "bbox": (16.6, 26.4, 52.0, 59.8)},
    {"name": "pakistan", "answers": ["pakistan"], "bbox": (23.7, 37.1, 60.9, 77.8)},
    {"name": "palau", "answers": ["palau"], "bbox": (6.9, 8.1, 134.1, 134.7)},
    {"name": "panama", "answers": ["panama"], "bbox": (7.2, 9.6, -83.0, -77.2)},
    {"name": "papua new guinea", "answers": ["papua new guinea"], "bbox": (-11.7, -1.3, 140.8, 155.9)},
    {"name": "paraguay", "answers": ["paraguay"], "bbox": (-27.6, -19.3, -62.6, -54.3)},
    {"name": "peru", "answers": ["peru"], "bbox": (-18.3, -0.0, -81.3, -68.7)},
    {"name": "philippines", "answers": ["philippines"], "bbox": (5.0, 19.6, 117.2, 126.6)},
    {"name": "poland", "answers": ["poland"], "bbox": (49.0, 54.8, 14.1, 24.1)},
    {"name": "portugal", "answers": ["portugal"], "bbox": (36.9, 42.2, -9.5, -6.2)},
    {"name": "qatar", "answers": ["qatar"], "bbox": (24.5, 26.2, 50.7, 51.6)},
    {"name": "romania", "answers": ["romania"], "bbox": (43.6, 48.3, 20.3, 29.7)},
    {"name": "russia", "answers": ["russia"], "bbox": (41.2, 70.0, 27.3, 180.0)},
    {"name": "rwanda", "answers": ["rwanda"], "bbox": (-2.8, -1.0, 28.9, 30.9)},
    {"name": "saint kitts and nevis", "answers": ["saint kitts and nevis", "st kitts"], "bbox": (17.1, 17.4, -62.9, -62.5)},
    {"name": "saint lucia", "answers": ["saint lucia", "st lucia"], "bbox": (13.7, 14.1, -61.1, -60.9)},
    {"name": "saint vincent and the grenadines", "answers": ["saint vincent and the grenadines", "st vincent"], "bbox": (12.6, 13.4, -61.5, -61.1)},
    {"name": "samoa", "answers": ["samoa"], "bbox": (-14.1, -13.4, -172.8, -171.4)},
    {"name": "san marino", "answers": ["san marino"], "bbox": (43.89, 43.99, 12.41, 12.52)},
    {"name": "sao tome and principe", "answers": ["sao tome and principe", "são tomé and príncipe"], "bbox": (0.0, 1.7, 6.5, 7.5)},
    {"name": "saudi arabia", "answers": ["saudi arabia"], "bbox": (16.4, 32.2, 34.5, 55.7)},
    {"name": "senegal", "answers": ["senegal"], "bbox": (12.3, 16.7, -17.5, -11.4)},
    {"name": "serbia", "answers": ["serbia"], "bbox": (42.2, 46.2, 18.8, 23.0)},
    {"name": "seychelles", "answers": ["seychelles"], "bbox": (-4.8, -4.2, 55.2, 55.8)},
    {"name": "sierra leone", "answers": ["sierra leone"], "bbox": (6.9, 10.0, -13.3, -10.3)},
    {"name": "singapore", "answers": ["singapore"], "bbox": (1.2, 1.5, 103.6, 104.0)},
    {"name": "slovakia", "answers": ["slovakia"], "bbox": (47.7, 49.6, 16.8, 22.6)},
    {"name": "slovenia", "answers": ["slovenia"], "bbox": (45.4, 46.9, 13.4, 16.6)},
    {"name": "solomon islands", "answers": ["solomon islands"], "bbox": (-11.9, -6.6, 155.5, 162.4)},
    {"name": "somalia", "answers": ["somalia"], "bbox": (-1.7, 12.0, 41.0, 51.4)},
    {"name": "south africa", "answers": ["south africa"], "bbox": (-34.8, -22.1, 16.5, 32.9)},
    {"name": "south korea", "answers": ["south korea", "korea"], "bbox": (33.1, 38.6, 125.9, 129.6)},
    {"name": "south sudan", "answers": ["south sudan"], "bbox": (3.5, 12.2, 23.4, 35.9)},
    {"name": "spain", "answers": ["spain", "españa", "espana"], "bbox": (36.0, 43.8, -9.3, 3.3)},
    {"name": "sri lanka", "answers": ["sri lanka"], "bbox": (5.9, 9.8, 79.7, 81.9)},
    {"name": "sudan", "answers": ["sudan"], "bbox": (8.7, 22.0, 21.8, 38.6)},
    {"name": "suriname", "answers": ["suriname"], "bbox": (1.8, 6.0, -58.1, -54.0)},
    {"name": "sweden", "answers": ["sweden"], "bbox": (55.3, 69.1, 11.1, 24.2)},
    {"name": "switzerland", "answers": ["switzerland"], "bbox": (45.8, 47.8, 5.96, 10.5)},
    {"name": "syria", "answers": ["syria"], "bbox": (32.3, 37.3, 35.7, 42.4)},
    {"name": "tajikistan", "answers": ["tajikistan"], "bbox": (36.7, 41.0, 67.4, 75.1)},
    {"name": "tanzania", "answers": ["tanzania"], "bbox": (-11.7, -1.0, 29.3, 40.4)},
    {"name": "thailand", "answers": ["thailand"], "bbox": (5.6, 20.5, 97.3, 105.6)},
    {"name": "timor-leste", "answers": ["timor-leste", "east timor"], "bbox": (-9.5, -8.1, 124.0, 127.3)},
    {"name": "togo", "answers": ["togo"], "bbox": (6.1, 11.1, -0.1, 1.8)},
    {"name": "tonga", "answers": ["tonga"], "bbox": (-21.5, -15.6, -175.7, -173.7)},
    {"name": "trinidad and tobago", "answers": ["trinidad and tobago", "trinidad"], "bbox": (10.0, 11.3, -61.9, -60.5)},
    {"name": "tunisia", "answers": ["tunisia"], "bbox": (30.2, 37.5, 7.5, 11.6)},
    {"name": "turkey", "answers": ["turkey", "türkiye", "turkiye"], "bbox": (36.0, 42.1, 26.0, 44.8)},
    {"name": "turkmenistan", "answers": ["turkmenistan"], "bbox": (35.1, 42.8, 52.5, 66.7)},
    {"name": "tuvalu", "answers": ["tuvalu"], "bbox": (-8.6, -5.6, 176.1, 179.9)},
    {"name": "uganda", "answers": ["uganda"], "bbox": (-1.5, 4.2, 29.6, 35.0)},
    {"name": "ukraine", "answers": ["ukraine"], "bbox": (44.4, 52.4, 22.1, 40.2)},
    {"name": "united arab emirates", "answers": ["united arab emirates", "uae"], "bbox": (22.6, 26.1, 51.6, 56.4)},
    {"name": "united kingdom", "answers": ["uk", "united kingdom", "england", "britain", "great britain"], "bbox": (49.9, 58.7, -8.2, 1.8)},
    {"name": "united states", "answers": ["usa", "us", "united states", "united states of america", "america"], "bbox": (24.5, 49.4, -124.8, -66.9)},
    {"name": "uruguay", "answers": ["uruguay"], "bbox": (-34.9, -30.1, -58.4, -53.1)},
    {"name": "uzbekistan", "answers": ["uzbekistan"], "bbox": (37.2, 45.6, 56.0, 73.1)},
    {"name": "vanuatu", "answers": ["vanuatu"], "bbox": (-20.3, -13.1, 166.5, 170.2)},
    {"name": "vatican city", "answers": ["vatican", "vatican city"], "bbox": (41.900, 41.907, 12.445, 12.458)},
    {"name": "venezuela", "answers": ["venezuela"], "bbox": (0.6, 12.2, -73.4, -59.8)},
    {"name": "vietnam", "answers": ["vietnam"], "bbox": (8.4, 23.4, 102.1, 109.5)},
    {"name": "yemen", "answers": ["yemen"], "bbox": (12.1, 19.0, 42.6, 54.0)},
    {"name": "zambia", "answers": ["zambia"], "bbox": (-18.1, -8.2, 21.9, 33.7)},
    {"name": "zimbabwe", "answers": ["zimbabwe"], "bbox": (-22.4, -15.6, 25.2, 33.1)},
]


def _map_urls(lat: float, lon: float, zoom: int):
    """Free map backends. Prefer Yandex/ArcGIS — OSM.de often fails on bot-hosting."""
    # tighter span so the map isn't a solid blur of ocean
    span = max(0.08, 180 / (2 ** zoom))
    min_lon, max_lon = lon - span, lon + span
    min_lat, max_lat = lat - span * 0.65, lat + span * 0.65
    bbox = f"{min_lon:.5f},{min_lat:.5f},{max_lon:.5f},{max_lat:.5f}"
    z = max(6, min(int(zoom), 15))
    return [
        # Yandex first — usually returns a real map image
        (
            "https://static-maps.yandex.ru/1.x/"
            f"?ll={lon:.5f},{lat:.5f}&size=600,400&z={z}&l=map&lang=en_US"
        ),
        (
            "https://static-maps.yandex.ru/1.x/"
            f"?ll={lon:.5f},{lat:.5f}&size=600,400&z={z}&l=sat,skl&lang=en_US"
        ),
        (
            "https://server.arcgisonline.com/ArcGIS/rest/services/"
            "World_Street_Map/MapServer/export"
            f"?bbox={bbox}&bboxSR=4326&imageSR=4326&size=600,400"
            f"&dpi=96&transparent=false&f=image&format=png"
        ),
        (
            "https://server.arcgisonline.com/ArcGIS/rest/services/"
            "World_Imagery/MapServer/export"
            f"?bbox={bbox}&bboxSR=4326&imageSR=4326&size=600,400"
            f"&dpi=96&transparent=false&f=image&format=png"
        ),
    ]


def _osm_static_map(lat: float, lon: float, zoom: int) -> str:
    return _map_urls(lat, lon, zoom)[0]


async def _fetch_map_bytes_from_coords(lat: float, lon: float, zoom: int, retries: int = 3):
    """Try each map backend; retry with backoff. Reject tiny/blank images."""
    timeout = aiohttp.ClientTimeout(total=15)
    urls = _map_urls(lat, lon, zoom)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        for attempt in range(1, retries + 1):
            for u in urls:
                try:
                    async with session.get(u) as resp:
                        if resp.status == 200:
                            data = await resp.read()
                            # solid-color / error tiles are often very small
                            if data and len(data) > 8000:
                                print(f"MAP OK (try {attempt}, {len(data)}b):", u[:65])
                                return data
                            print(f"MAP too small {len(data) if data else 0}b try {attempt}", u[:50])
                        else:
                            print(f"MAP HTTP {resp.status} try {attempt}", u[:60])
                except Exception as e:
                    print(f"MAP TRY FAIL try {attempt}:", type(e).__name__, u[:50])
            if attempt < retries:
                wait = attempt * 1.5
                print(f"MAP retry in {wait}s…")
                await asyncio.sleep(wait)
    return None


async def _fetch_map_bytes(url: str, retries: int = 3):
    timeout = aiohttp.ClientTimeout(total=12)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        for attempt in range(1, retries + 1):
            try:
                async with session.get(url) as resp:
                    if resp.status == 200:
                        data = await resp.read()
                        if data and len(data) > 500:
                            return data
                    print("MAP HTTP STATUS:", resp.status, "try", attempt)
            except Exception as e:
                print("MAP DOWNLOAD ERROR try", attempt, e)
            if attempt < retries:
                await asyncio.sleep(attempt * 1.5)
    return None


async def _kartaview_street_image(lat: float, lon: float):
    """Real street-level photo via KartaView/OpenStreetCam (no API key)."""
    search = "https://api.openstreetcam.org/2.0/photo/"
    params_list = [
        {"lat": lat, "lng": lon, "radius": 500},
        {"lat": lat, "lng": lon, "radius": 2000},
        {"lat": lat, "lng": lon, "radius": 5000},
    ]
    timeout = aiohttp.ClientTimeout(total=14)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            for params in params_list:
                try:
                    async with session.get(search, params=params) as resp:
                        if resp.status != 200:
                            print("KartaView search HTTP", resp.status)
                            continue
                        data = await resp.json(content_type=None)
                except Exception as e:
                    print("KartaView search err:", type(e).__name__, e)
                    continue

                photos = []
                if isinstance(data, dict):
                    photos = (
                        data.get("currentPageItems")
                        or (data.get("osv") or {}).get("photos")
                        or (data.get("result") or {}).get("data")
                        or data.get("data")
                        or data.get("photos")
                        or []
                    )
                if isinstance(photos, dict):
                    photos = list(photos.values())
                if not photos:
                    continue

                photo = random.choice(photos) if isinstance(photos, list) else photos
                if not isinstance(photo, dict):
                    continue

                img_url = (
                    photo.get("fileurlL")
                    or photo.get("fileurlProc")
                    or photo.get("lth_name")
                    or photo.get("name")
                    or photo.get("url")
                    or photo.get("image")
                    or photo.get("imageUrl")
                )
                if not img_url or not isinstance(img_url, str):
                    print("KartaView: no image url keys", list(photo.keys())[:12])
                    continue
                if img_url.startswith("//"):
                    img_url = "https:" + img_url
                elif img_url.startswith("/"):
                    img_url = "https://api.openstreetcam.org" + img_url
                elif not img_url.startswith("http"):
                    img_url = "https://api.openstreetcam.org/" + img_url.lstrip("/")

                try:
                    async with session.get(img_url) as img_resp:
                        if img_resp.status == 200:
                            raw = await img_resp.read()
                            if raw and len(raw) > 5000:
                                print("KartaView STREET OK", len(raw), "b")
                                return raw
                except Exception as e:
                    print("KartaView img err:", type(e).__name__, e)
    except Exception as e:
        print("KartaView error:", type(e).__name__, e)
    return None


def _geoguess_challenge():
    try:
        country = random.choice(GEO_COUNTRIES)
        min_lat, max_lat, min_lon, max_lon = country["bbox"]
        # Bias toward the middle of the bbox (more land), then small random offset
        # so pure ocean / empty tiles are less common
        mid_lat = (min_lat + max_lat) / 2
        mid_lon = (min_lon + max_lon) / 2
        lat = mid_lat + random.uniform(-0.35, 0.35) * (max_lat - min_lat)
        lon = mid_lon + random.uniform(-0.35, 0.35) * (max_lon - min_lon)
        lat = max(min_lat, min(max_lat, lat))
        lon = max(min_lon, min(max_lon, lon))
        zoom = random.choice([8, 9, 10, 11])  # wider view = readable country context
        return {
            "title": "🌍 GeoGuessr!",
            "description": (
                "Random place on the map — **what country is this?**\n\n"
                f"First correct answer wins **{_format_reward(TRIVIA_REWARD_GEO)} gems**!"
            ),
            "answer": country["name"],
            "answers": [a.lower() for a in country["answers"]],
            "case_sensitive": False,
            "colour": discord.Colour.dark_green(),
            "image": _osm_static_map(lat, lon, zoom),
            "lat": lat,
            "lon": lon,
            "zoom": zoom,
            "reward": TRIVIA_REWARD_GEO,
        }
    except Exception as e:
        print("GEO BUILD ERROR:", e)
        return _trivia_challenge()



def _math_challenge():
    op = random.choice(["+", "-", "*", "add", "sub", "mul"])
    if op in ("+", "add"):
        a, b = random.randint(10, 300), random.randint(10, 300)
        ans = str(a + b)
        prompt = f"**{a} + {b}**"
    elif op in ("-", "sub"):
        a, b = random.randint(50, 400), random.randint(10, 200)
        if b > a:
            a, b = b, a
        ans = str(a - b)
        prompt = f"**{a} − {b}**"
    else:
        a, b = random.randint(4, 25), random.randint(3, 16)
        ans = str(a * b)
        prompt = f"**{a} × {b}**"
    return (
        "🧮 Math Challenge!",
        f"First to type the correct answer to {prompt} wins {_reward_text()}!",
        ans,
        False,
        discord.Colour.blue(),
    )


def _typing_challenge():
    phrase = random.choice(TYPING_PHRASES)
    return (
        "⌨️ Typing Race!",
        f"First person to type this **exactly** wins {_reward_text()}:\n\n`{phrase}`",
        phrase,
        True,
        discord.Colour.orange(),
    )


def _trivia_challenge():
    q, a = random.choice(TRIVIA_QUESTIONS)
    return (
        "🧠 Trivia Time!",
        f"**{q}**\n\nFirst correct answer wins {_reward_text()}!",
        a,
        False,
        discord.Colour.purple(),
    )


def _unscramble_challenge():
    word = random.choice(UNSCRAMBLE_WORDS)
    letters = list(word)
    random.shuffle(letters)
    scrambled = "".join(letters)
    if scrambled == word:
        letters = list(word)
        random.shuffle(letters)
        scrambled = "".join(letters)
    return (
        "🔀 Unscramble!",
        f"Unscramble this word: **`{scrambled}`**\n\nFirst correct answer wins {_reward_text()}!",
        word,
        False,
        discord.Colour.green(),
    )


def _reverse_challenge():
    word = random.choice(REVERSE_WORDS)
    return (
        "🔄 Reverse It!",
        f"Type this word **backwards**: **`{word}`**\n\nFirst correct answer wins {_reward_text()}!",
        word[::-1],
        False,
        discord.Colour.teal(),
    )


def _emoji_challenge():
    shown, ans = random.choice(EMOJI_SEQUENCES)
    return (
        "😎 Emoji Race!",
        f"First to type this exact emoji sequence wins {_reward_text()}:\n\n{shown}",
        ans,
        True,
        discord.Colour.gold(),
    )


def _count_letters_challenge():
    word = random.choice(UNSCRAMBLE_WORDS + TYPING_PHRASES)
    letter = random.choice(list(set(word.replace(" ", ""))))
    count = word.count(letter)
    return (
        "🔢 Count Them!",
        f"How many times does the letter **`{letter}`** appear in:\n**`{word}`**?\n\nFirst correct number wins {_reward_text()}!",
        str(count),
        False,
        discord.Colour.dark_blue(),
    )


def _sequence_challenge():
    start = random.randint(2, 12)
    step = random.randint(2, 7)
    seq = [start + i * step for i in range(4)]
    ans = str(seq[-1] + step)
    shown = ", ".join(str(x) for x in seq) + ", ?"
    return (
        "🔢 Next Number!",
        f"What comes next in the sequence?\n**{shown}**\n\nFirst correct answer wins {_reward_text()}!",
        ans,
        False,
        discord.Colour.dark_purple(),
    )


def _random_string_challenge():
    length = random.randint(5, 8)
    chars = string.ascii_lowercase + string.digits
    code = "".join(random.choice(chars) for _ in range(length))
    return (
        "⚡ Code Race!",
        f"First to type this code **exactly** wins {_reward_text()}:\n\n`{code}`",
        code,
        True,
        discord.Colour.red(),
    )


def _first_to_type_challenge():
    targets = [
        ("AQUA", "AQUA"),
        ("GEMS", "GEMS"),
        ("WIN", "WIN"),
        ("GG", "GG"),
        ("EZ", "EZ"),
        ("LFG", "LFG"),
        ("100", "100"),
        ("777", "777"),
    ]
    shown, ans = random.choice(targets)
    return (
        "🏁 First to Type!",
        f"First person to type **`{shown}`** wins {_reward_text()}!",
        ans,
        True,
        discord.Colour.magenta(),
    )


CHALLENGE_MAKERS = [
    _math_challenge,
    _typing_challenge,
    _trivia_challenge,
    _unscramble_challenge,
    _reverse_challenge,
    _emoji_challenge,
    _count_letters_challenge,
    _sequence_challenge,
    _random_string_challenge,
    _first_to_type_challenge,
    # Geo is NOT in this list — it only runs via geoguessr_loop every 2 hours
]


async def _run_one_trivia(channel, maker):
    """Shared runner for auto loop and /trivia."""
    raw = maker()

    geo_lat = geo_lon = geo_zoom = None
    if isinstance(raw, dict):
        print("TRIVIA PICKED: GEO →", raw.get("answer"))
        title = raw["title"]
        description = raw["description"]
        answer = raw["answer"]
        answers = [a.lower() for a in raw.get("answers", [answer])]
        case_sensitive = raw.get("case_sensitive", False)
        colour = raw.get("colour", discord.Colour.blurple())
        image = raw.get("image")
        geo_lat = raw.get("lat")
        geo_lon = raw.get("lon")
        geo_zoom = raw.get("zoom", 12)
        reward = int(raw.get("reward") or _current_reward())
    else:
        print("TRIVIA PICKED:", raw[0] if isinstance(raw, tuple) else raw)
        title, description, answer, case_sensitive, colour = raw
        answers = [answer.lower()] if not case_sensitive else [answer]
        image = None
        reward = _current_reward()

    if trivia_boosted and trivia_boosted_by and reward == _current_reward():
        description = (
            f"⚡ **Trivia boosted by {trivia_boosted_by}**\n"
            f"*Faster rounds • prize {_format_reward(TRIVIA_REWARD_BOOSTED)} gems*\n\n"
            + description
        )

    embed = normal_embed(title, description, colour)
    footer = _boost_footer()
    if footer:
        embed.set_footer(text=footer)

    await channel.send(content=TRIVIA_ROLE_PING, embed=embed)

    # Street photo (KartaView) first, then satellite/map fallbacks
    if image or (geo_lat is not None and geo_lon is not None):
        img_bytes = None
        if geo_lat is not None and geo_lon is not None:
            img_bytes = await _kartaview_street_image(geo_lat, geo_lon)
            if not img_bytes:
                img_bytes = await _fetch_map_bytes_from_coords(
                    geo_lat, geo_lon, int(geo_zoom or 10)
                )
        elif image:
            img_bytes = await _fetch_map_bytes(image)
        if img_bytes:
            await channel.send(
                content="🗺️ **Map:**",
                file=discord.File(io.BytesIO(img_bytes), filename="geo.png"),
            )
        else:
            print("MAP FAILED for all backends")
            await channel.send("⚠️ Map failed to load — still guess the country.")


    def check(message):
        if getattr(message.channel, "id", None) != getattr(channel, "id", None):
            return False
        if message.author.bot:
            return False
        content = message.content.strip()
        if case_sensitive:
            return content in answers or content == answer
        return content.lower() in answers

    try:
        message = await bot.wait_for("message", check=check, timeout=TRIVIA_TIMEOUT)
        winner = ensure_user(message.author.id)
        winner["balance"] += reward
        save_data()
        await channel.send(
            f"🎉 {message.author.mention} got it (**{answer}**) and won "
            f"**{_format_reward(reward)} gems**!"
        )
    except asyncio.TimeoutError:
        await channel.send(
            f"⏳ Time's up! The answer was **`{answer}`**. Nobody won this round."
        )
    except Exception as e:
        print(f"Trivia run error: {e}")


@tasks.loop(minutes=15)
async def trivia_loop():
    channel_id = config.get("channels", {}).get("general")
    if not channel_id:
        return
    channel = bot.get_channel(int(channel_id))
    if not channel:
        return
    await _run_one_trivia(channel, random.choice(CHALLENGE_MAKERS))


@trivia_loop.before_loop
async def before_trivia_loop():
    await bot.wait_until_ready()


@tasks.loop(hours=2)
async def geoguessr_loop():
    """Dedicated GeoGuessr challenge every 2 hours — only place geo appears automatically."""
    channel_id = config.get("channels", {}).get("general")
    if not channel_id:
        return
    channel = bot.get_channel(int(channel_id))
    if not channel:
        return
    await _run_one_trivia(channel, _geoguess_challenge)


@geoguessr_loop.before_loop
async def before_geoguessr_loop():
    await bot.wait_until_ready()


def _can_boost(interaction: discord.Interaction) -> bool:
    if interaction.user.id == OWNER_ID:
        return True
    if isinstance(interaction.user, discord.Member):
        return interaction.user.guild_permissions.administrator
    return False


def _maker_from_choice(value: str):
    mapping = {
        "geo": _geoguess_challenge,
        "geoguessr": _geoguess_challenge,
        "math": _math_challenge,
        "typing": _typing_challenge,
        "trivia": _trivia_challenge,
        "unscramble": _unscramble_challenge,
        "reverse": _reverse_challenge,
        "emoji": _emoji_challenge,
        "count": _count_letters_challenge,
        "sequence": _sequence_challenge,
        "code": _random_string_challenge,
        "first": _first_to_type_challenge,
        "random": None,
    }
    key = (value or "random").strip().lower()
    if key in ("random", ""):
        return random.choice(CHALLENGE_MAKERS)
    # Explicit geo still allowed via !trivia geo (admin only); unknown → random non-geo
    return mapping.get(key) or random.choice(CHALLENGE_MAKERS)


def _can_run_trivia(user: discord.abc.User, member: discord.Member | None) -> bool:
    if user.id == OWNER_ID:
        return True
    if member is not None and member.guild_permissions.administrator:
        return True
    return False


@tree.command(
    name="toggle_trivia",
    description="Turn trivia on or off",
)
@app_commands.describe(
    enable="True = turn trivia on, False = turn trivia off",
)
async def trivia_toggle_cmd(
    interaction: discord.Interaction,
    enable: bool = True,
):
    required_role_id = 1536378758955540531
    role = interaction.guild.get_role(required_role_id)

    # Permission check
    if role not in interaction.user.roles:
        await interaction.response.send_message(
            "❌ You don't have permission to use this command.",
            ephemeral=True,
        )
        return

    # Toggle trivia loop
    if enable:
        if not trivia_loop.is_running():
            trivia_loop.start()
        await interaction.response.send_message(
            "✅ Trivia has been **enabled**.",
            ephemeral=False,
        )
    else:
        if trivia_loop.is_running():
            trivia_loop.cancel()
        await interaction.response.send_message(
            "⛔ Trivia has been **disabled**.",
            ephemeral=False,
        )


@tree.command(
    name="trivia_boost",
    description="Boost trivia to every 1 minute with 2m gem prizes (Admins + owner)",
)
@app_commands.describe(
    enable="Turn boost on or off (default: on)",
)
async def trivia_boost_cmd(
    interaction: discord.Interaction,
    enable: bool = True,
):
    global trivia_boosted, trivia_boosted_by

    if not _can_boost(interaction):
        await interaction.response.send_message(
            "❌ You don't have permission to use this command.",
            ephemeral=True,
        )
        return

    if enable:
        trivia_boosted = True
        trivia_boosted_by = interaction.user.mention
        trivia_loop.change_interval(minutes=1)

        await interaction.response.send_message(
            f"⚡ **Trivia boosted by {interaction.user.mention}!**\n"
            f"Rounds now run **every 1 minute** with a **2m gem** prize.\n"
            f"Use `/trivia_boost enable:False` to turn it off.",
            ephemeral=False,
        )
    else:
        trivia_boosted = False
        trivia_boosted_by = None
        trivia_loop.change_interval(minutes=15)

        await interaction.response.send_message(
            "✅ Trivia boost disabled. Back to **every 15 minutes** with **15m gems**",
            ephermal=False,
        )

# ============================================================
# STARTUP
# ============================================================

STARTUP_COMPLETE = False


@bot.event
async def on_ready():
    global STARTUP_COMPLETE

    print(f"Logged in as {bot.user} (ID: {bot.user.id})")

    if STARTUP_COMPLETE:
        return

    STARTUP_COMPLETE = True

    bot.add_view(DepositTicketView())
    bot.add_view(WithdrawTicketView())
    bot.add_view(VerificationPanelView())

    if not update_profit_trackers.is_running():
        update_profit_trackers.start()
    if not trivia_loop.is_running():
        trivia_loop.start()

    # ============================================================
    # REMOVE GEOGUESSR ON STARTUP
    # ============================================================
    print("Geoguessr disabled on startup.")

    try:
        for guild in bot.guilds:
            bot.tree.clear_commands(guild=guild)
            await bot.tree.sync(guild=guild)

        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} global slash command(s).")
    except Exception as e:
        STARTUP_COMPLETE = False
        print(f"Failed to sync slash commands: {e}")


def _start_aqua_website():
    import os
    import sys
    from pathlib import Path

    try:
        root = Path(__file__).resolve().parent
        website_dir = root / "Aqua_Website"
        if not website_dir.is_dir():
            website_dir = root / "aqua_website"
        if not website_dir.is_dir():
            print("❌ Aqua_Website folder not found")
            return

        os.environ.setdefault("CASINO_DATA_FILE", str(root / "casino_data.json"))
        os.environ.setdefault("HOST", "0.0.0.0")
        os.environ.setdefault("PORT", "8080")

        sys.path.insert(0, str(website_dir))
        from main import app

        port = int(os.environ.get("PORT", "8080"))
        print(f"🌐 Aqua website starting on port {port}")
        app.run(host="0.0.0.0", port=port, debug=False, use_reloader=False)
    except Exception as e:
        print(f"❌ Website error: {e}")


if __name__ == "__main__":
    if not TOKEN:
        print("❌ ERROR: DISCORD_TOKEN environment variable is missing or empty!")
    else:
        import threading
        threading.Thread(target=_start_aqua_website, daemon=True).start()
        print("🚀 Starting Aqua Gems Casino (modular)...")
        bot.run(TOKEN)
