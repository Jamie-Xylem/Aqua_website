#!/usr/bin/env python3
"""
Create Discord webhooks for Aqua Gems staff channels.

Loads the bot token from the same project the modular bot uses
(config / main / .env) — you do not need to export DISCORD_BOT_TOKEN.

Channels:
  deposit_review   1544034315669741599
  deposit_log      1536573870067294301
  withdraw_request 1544034276121776258
  withdraw_log     1536664785599336498

Usage (from aqua_casino or next to config.py):
  python create_channel_webhooks.py
  python create_channel_webhooks.py --reuse

Writes webhooks.json next to this file.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

try:
    import requests
except ImportError:
    print("Install requests: pip install requests")
    sys.exit(1)

CHANNELS = {
    "deposit_review": "1544034315669741599",
    "deposit_log": "1536573870067294301",
    "withdraw_request": "1544034276121776258",
    "withdraw_log": "1536664785599336498",
}

WEBHOOK_NAME = "Aqua Gems Website"
HERE = Path(__file__).resolve().parent
OUT_FILE = HERE / "webhooks.json"


def load_bot_token() -> str:
    """Same sources the modular bot uses — no manual token export."""
    for key in ("DISCORD_BOT_TOKEN", "BOT_TOKEN", "TOKEN", "DISCORD_TOKEN"):
        val = os.environ.get(key, "").strip()
        if val:
            return val

    search_dirs = [HERE, HERE.parent, Path.cwd(), Path.cwd().parent]
    for d in search_dirs:
        if str(d) not in sys.path:
            sys.path.insert(0, str(d))

    for mod_name in ("config", "bot_config", "settings"):
        try:
            mod = __import__(mod_name)
        except ImportError:
            continue
        for attr in ("DISCORD_BOT_TOKEN", "BOT_TOKEN", "TOKEN", "DISCORD_TOKEN", "token"):
            val = getattr(mod, attr, None)
            if isinstance(val, str) and val.strip() and not val.startswith("your-"):
                return val.strip()

    candidates = []
    for d in search_dirs:
        for name in ("config.py", "main.py", ".env", "bot.py"):
            p = d / name
            if p.is_file():
                candidates.append(p)
    for p in candidates:
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for line in text.splitlines():
            line = line.strip()
            if line.startswith("#"):
                continue
            for prefix in ("DISCORD_BOT_TOKEN", "BOT_TOKEN", "TOKEN", "DISCORD_TOKEN"):
                if line.upper().startswith(prefix.upper()) and "=" in line:
                    raw = line.split("=", 1)[1].strip().strip("\"'")
                    if raw and not raw.startswith("your-") and "change-me" not in raw.lower():
                        return raw
    return ""


def create_webhook(token: str, channel_id: str, name: str) -> dict:
    url = f"https://discord.com/api/v10/channels/{channel_id}/webhooks"
    r = requests.post(
        url,
        headers={
            "Authorization": f"Bot {token}",
            "Content-Type": "application/json",
        },
        json={"name": name},
        timeout=20,
    )
    if r.status_code in (200, 201):
        data = r.json()
        wh_url = f"https://discord.com/api/webhooks/{data['id']}/{data['token']}"
        return {
            "ok": True,
            "id": data["id"],
            "token": data["token"],
            "url": wh_url,
            "channel_id": channel_id,
            "name": data.get("name") or name,
        }
    return {
        "ok": False,
        "channel_id": channel_id,
        "status": r.status_code,
        "error": r.text[:500],
    }


def list_existing(token: str, channel_id: str) -> list:
    url = f"https://discord.com/api/v10/channels/{channel_id}/webhooks"
    r = requests.get(
        url,
        headers={"Authorization": f"Bot {token}"},
        timeout=15,
    )
    if not r.ok:
        return []
    return r.json() or []


def main():
    token = load_bot_token()
    if not token:
        print("ERROR: Could not find bot token in config/main/.env.")
        print("Put this script next to your bot config (or run from aqua_casino).")
        sys.exit(1)

    print(f"Token loaded (ends …{token[-6:]})")
    reuse = "--reuse" in sys.argv
    results = {}

    print("Creating webhooks…\n")
    for key, channel_id in CHANNELS.items():
        print(f"  [{key}] channel {channel_id}")
        if reuse:
            for w in list_existing(token, channel_id):
                if (w.get("name") or "").startswith("Aqua Gems") and w.get("token"):
                    results[key] = {
                        "ok": True,
                        "id": w["id"],
                        "token": w["token"],
                        "url": f"https://discord.com/api/webhooks/{w['id']}/{w['token']}",
                        "channel_id": channel_id,
                        "name": w.get("name"),
                        "reused": True,
                    }
                    print("    → reused")
                    break
            if key in results:
                continue

        res = create_webhook(token, channel_id, f"{WEBHOOK_NAME} · {key}")
        results[key] = res
        if res.get("ok"):
            print("    → OK")
        else:
            print(f"    → FAIL HTTP {res.get('status')}: {res.get('error')}")

    payload = json.dumps(results, indent=2)
    OUT_FILE.write_text(payload)
    print(f"\nSaved → {OUT_FILE}")

    print("\n========== webhooks.json ==========")
    print(payload)
    print("===================================\n")

    print("--- webhook URLs ---")
    for key, res in results.items():
        if res.get("ok"):
            print(f"{key}: {res['url']}")
        else:
            print(f"{key}: FAILED")

    failed = [k for k, v in results.items() if not v.get("ok")]
    if failed:
        print("\nFailed:", ", ".join(failed))
        print("Bot needs Manage Webhooks on those channels.")
        sys.exit(2)
    print("\nDone.")


if __name__ == "__main__":
    main()
