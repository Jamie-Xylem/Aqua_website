"""
Shared data layer — same casino_data.json as Discord bot.
Every user gets a `codes` list for redeemable / referral codes.
"""
import json
import os
import random
import re
import time
import threading
from pathlib import Path

_lock = threading.RLock()

_ROOT = Path(__file__).resolve().parent.parent
DATA_FILE = Path(os.environ.get("CASINO_DATA_FILE", str(_ROOT / "casino_data.json")))

DEFAULT_DATA = {
    "users": {},
    "verification": {},
    "tickets": {},
    "affiliates": {},
    "global_stats": {
        "total_deposits": 0,
        "total_withdraws": 0,
        "bot_game_profit": 0,
    },
    "settings": {
        "paused": False,
        "active_deposit_bonus": None,
    },
    "website_codes": {},
    "website_verify_pending": {},
    "website_chat": [],
    "admins": {},
    "website_pending_deposits": {},
    "website_pending_withdraws": {},
    "blacklist": [],
    "whitelist": [],
    "coinflip_games": {},
    "roulette_round": {},
    "roulette_history": [],
}


def _load():
    if DATA_FILE.exists():
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                data = DEFAULT_DATA.copy()
        except Exception:
            data = DEFAULT_DATA.copy()
    else:
        data = DEFAULT_DATA.copy()
        DATA_FILE.parent.mkdir(parents=True, exist_ok=True)

    for k, v in DEFAULT_DATA.items():
        if k not in data:
            data[k] = v if not isinstance(v, dict) else (v.copy() if isinstance(v, dict) else v)
    data.setdefault("users", {})
    data.setdefault("website_chat", [])
    data.setdefault("coinflip_games", {})
    data.setdefault("roulette_round", {})
    data.setdefault("roulette_history", [])
    return data


def save_data(data):
    with _lock:
        tmp = str(DATA_FILE) + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, DATA_FILE)


def get_data():
    with _lock:
        return _load()


def ensure_user(user_id, data=None):
    if data is None:
        data = get_data()
    uid = str(user_id)
    if uid not in data["users"]:
        data["users"][uid] = {
            "balance": 0,
            "wagered": 0,
            "deposited": 0,
            "withdrawn": 0,
            "to_wager": 0,
            "history": [],
            "roblox": None,
            "roblox_id": None,
            "codes": [],  # all users have codes list
            "affiliate_code": f"REF-{random.randint(1000, 9999)}",
            "referred_by": None,
            "referred_users": [],
            "chips": 0,  # roulette poker chips
        }
    u = data["users"][uid]
    u.setdefault("deposited", 0)
    u.setdefault("withdrawn", 0)
    u.setdefault("to_wager", 0)
    u.setdefault("history", [])
    u.setdefault("codes", [])
    u.setdefault("chips", 0)
    u.setdefault("roblox", None)
    u.setdefault("roblox_id", None)
    return u


def find_user_by_roblox_id(roblox_id, data=None):
    if data is None:
        data = get_data()
    rid = str(roblox_id)
    for uid, u in data["users"].items():
        if str(u.get("roblox_id") or "") == rid:
            return uid, u
    return None, None


def find_user_by_roblox_name(name, data=None):
    if data is None:
        data = get_data()
    name_l = (name or "").lower().strip()
    for uid, u in data["users"].items():
        if (u.get("roblox") or "").lower() == name_l:
            return uid, u
    return None, None


def parse_amount(amount_str: str):
    if not isinstance(amount_str, str):
        return None
    amount_str = amount_str.lower().strip().replace(",", "").replace(" ", "")
    match = re.match(r"^(\d+(?:\.\d+)?)([kmbt])?$", amount_str)
    if not match:
        try:
            return int(float(amount_str))
        except ValueError:
            return None
    val, mult = match.groups()
    val = float(val)
    multipliers = {None: 1, "k": 1_000, "m": 1_000_000, "b": 1_000_000_000, "t": 1_000_000_000_000}
    val *= multipliers.get(mult, 1)
    return int(val)


def format_amount(amount) -> str:
    amount = int(amount or 0)
    sign = "-" if amount < 0 else ""
    amount = abs(amount)
    if amount >= 1_000_000_000_000:
        val = amount / 1_000_000_000_000
        return f"{sign}{val:.2f}".rstrip("0").rstrip(".") + "T"
    if amount >= 1_000_000_000:
        val = amount / 1_000_000_000
        return f"{sign}{val:.2f}".rstrip("0").rstrip(".") + "B"
    if amount >= 1_000_000:
        val = amount / 1_000_000
        return f"{sign}{val:.2f}".rstrip("0").rstrip(".") + "M"
    if amount >= 1_000:
        val = amount / 1_000
        return f"{sign}{val:.2f}".rstrip("0").rstrip(".") + "K"
    return f"{sign}{amount}"


def add_history(user_id, game, amount, result, data=None):
    if data is None:
        data = get_data()
    user = ensure_user(user_id, data)
    user["history"].append({
        "game": game,
        "amount": amount,
        "result": result,
        "time": int(time.time()),
    })
    user["history"] = user["history"][-100:]
