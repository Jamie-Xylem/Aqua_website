"""
Aqua Gems Website — configuration
Shares casino_data.json with the Discord bot.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

DEFAULT_DATA = BASE_DIR.parent / "casino_data.json"
DATA_FILE = Path(os.environ.get("CASINO_DATA_FILE", str(DEFAULT_DATA)))

SECRET_KEY = os.environ.get("WEBSITE_SECRET_KEY", "aqua-gems-secret-change-me-2026")
ADMIN_API_KEY = os.environ.get("ADMIN_API_KEY", "aqua-admin-key-change-me")

BOT_ROBLOX_USERNAME = os.environ.get("BOT_ROBLOX_USERNAME", "AquaGemsBot")
MIN_AMOUNT = 10_000_000

HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "25632"))

DISCORD_WEBHOOK_URL = os.environ.get("DISCORD_WEBHOOK_URL", "")

# House edge applied silently (never shown to users)
HOUSE_EDGE = 0.075  # 7.5%

BIG_GAMES_BASE = "https://ps99.biggamesapi.io"
ROBLOX_USERS_API = "https://users.roblox.com/v1/usernames/users"
ROBLOX_THUMBNAIL_API = "https://thumbnails.roblox.com/v1/users/avatar-headshot"
