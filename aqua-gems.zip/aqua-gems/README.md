# Aqua Gems Website

**https://aqua-gems.com** · Port **25632**

Red-themed PS99 casino site that shares `casino_data.json` with the Discord bot.

## Features

- Top bar: Chat · Games · Logo · Roblox headshot · Balance
- Live chat panel (¼ screen desktop / ½ mobile)
- **50 slot machines** with unique themes, max multipliers, loading screen, fullscreen, mute, custom bets, big-win banners
- **Coinflip** PvP — winner receives 92.5% of pot (provably fair)
- **Roulette** — buy/sell chips, place on board, 60s rounds, standard payouts with edge on wins (provably fair)
- **Blackjack** — hit/stand, custom bet, provably fair
- Profile: balance, deposited, withdrawn, codes, history
- Account verify (Roblox bio + Discord DM code)
- No website auto-deposit/withdraw — balances sync via Discord bot

## Setup

```bash
cd aqua-gems
pip install -r requirements.txt

# Point at the same data file as the Discord bot
export CASINO_DATA_FILE=/path/to/aqua_casino/casino_data.json
export WEBSITE_SECRET_KEY=your-secret
export ADMIN_API_KEY=your-admin-key
export BOT_ROBLOX_USERNAME=YourBotName

python main.py
```

Default listen: `0.0.0.0:25632`

## Discord bot integration

- Users get a `codes` array on every account (plus `affiliate_code`).
- Pending website verifies live under `website_verify_pending`.
- Bot can POST `/api/bot/verify_dm` with `X-Admin-Key` and `{"code":"WEB-..."}` to set `dm_ok`.
- Chat messages stored in `website_chat`.

## Structure

```
aqua-gems/
  main.py
  config.py
  data_store.py
  requirements.txt
  templates/
  static/
    css/style.css
    js/  (chat, slot, coinflip, roulette, blackjack)
    img/logo.png
    slots/slots.json   # 50 machine definitions
```
