(function () {
  const cfg = window.SLOT_CONFIG;
  const reelsEl = document.getElementById("reels");
  const loader = document.getElementById("slotLoader");
  const spinBtn = document.getElementById("spinBtn");
  const betInput = document.getElementById("betInput");
  const betLabel = document.getElementById("betLabel");
  const winBanner = document.getElementById("winBanner");
  const balEl = document.getElementById("slotBal");
  const btnMute = document.getElementById("btnMute");
  const btnFS = document.getElementById("btnFS");
  const shell = document.getElementById("gameShell");
  const jMini = document.getElementById("jMini");
  const jMajor = document.getElementById("jMajor");

  let muted = false;
  let spinning = false;
  let autoMode = false;
  const cols = cfg.reels || 5;
  const rows = cfg.rows || 3;
  const symbols = cfg.symbols || ["💎", "7️⃣", "🔔", "🍒", "🍋", "⭐", "👑", "BAR"];
  const presets = ["100k", "250k", "500k", "1m", "2.5m", "5m", "10m", "25m", "50m", "100m"];
  const symH = () => (window.innerWidth < 400 ? 54 : 64);

  const reelInners = [];
  function makeSym(el, text) {
    el.innerHTML = "";
    const tile = document.createElement("div");
    tile.className = "sym-tile";
    tile.textContent = text;
    el.appendChild(tile);
  }

  for (let c = 0; c < cols; c++) {
    const reel = document.createElement("div");
    reel.className = "reel";
    const inner = document.createElement("div");
    inner.className = "reel-inner";
    for (let i = 0; i < 40; i++) {
      const s = document.createElement("div");
      s.className = "sym";
      makeSym(s, symbols[Math.floor(Math.random() * symbols.length)]);
      inner.appendChild(s);
    }
    reel.appendChild(inner);
    reelsEl.appendChild(reel);
    reelInners.push(inner);
  }

  setTimeout(() => { if (loader) loader.classList.add("hide"); }, 1400);

  function parseBet(s) {
    s = String(s || "").toLowerCase().replace(/,/g, "").trim();
    const m = s.match(/^([\d.]+)\s*([kmbt])?$/);
    if (!m) return 0;
    let n = parseFloat(m[1]);
    const mult = { k: 1e3, m: 1e6, b: 1e9, t: 1e12 }[m[2]] || 1;
    return Math.floor(n * mult);
  }
  function fmt(n) {
    n = Number(n) || 0;
    if (n >= 1e9) return (n / 1e9).toFixed(2).replace(/\.?0+$/, "") + "B";
    if (n >= 1e6) return (n / 1e6).toFixed(2).replace(/\.?0+$/, "") + "M";
    if (n >= 1e3) return (n / 1e3).toFixed(2).replace(/\.?0+$/, "") + "K";
    return String(n);
  }
  function syncBetLabel() {
    const v = parseBet(betInput.value);
    if (betLabel) betLabel.textContent = fmt(v) || "—";
    if (jMini) jMini.textContent = fmt(v * 10);
    if (jMajor) jMajor.textContent = fmt(v * 50);
  }
  betInput.addEventListener("input", syncBetLabel);
  syncBetLabel();

  document.getElementById("betMinus")?.addEventListener("click", () => {
    const cur = parseBet(betInput.value);
    let idx = presets.findIndex((p) => parseBet(p) >= cur);
    if (idx < 0) idx = presets.length - 1;
    idx = Math.max(0, idx - 1);
    betInput.value = presets[idx];
    syncBetLabel();
  });
  document.getElementById("betPlus")?.addEventListener("click", () => {
    const cur = parseBet(betInput.value);
    let idx = presets.findIndex((p) => parseBet(p) > cur);
    if (idx < 0) idx = presets.length - 1;
    betInput.value = presets[idx];
    syncBetLabel();
  });

  // Control buttons
  document.getElementById("btnMenu")?.addEventListener("click", () => {
    window.location.href = "/slots";
  });
  document.getElementById("btnAuto")?.addEventListener("click", function () {
    autoMode = !autoMode;
    this.style.borderColor = autoMode ? "#3dff9a" : "";
    this.style.color = autoMode ? "#3dff9a" : "";
    if (autoMode && !spinning) spin();
  });
  document.getElementById("btnBet")?.addEventListener("click", () => {
    const cur = parseBet(betInput.value);
    let idx = presets.findIndex((p) => parseBet(p) > cur);
    if (idx < 0) idx = 0;
    betInput.value = presets[idx];
    syncBetLabel();
  });
  document.getElementById("btnInfo")?.addEventListener("click", () => {
    alert(
      (cfg.name || "Slot") +
        "\n\nFeature: " +
        (cfg.feature || "—") +
        "\nMax win: " +
        (cfg.max_mult || "?") +
        "x\n\nMatch 3+ on the center line from the left."
    );
  });

  if (btnMute) {
    btnMute.addEventListener("click", () => {
      muted = !muted;
      btnMute.textContent = muted ? "🔇" : "🔊";
    });
  }
  if (btnFS) {
    btnFS.addEventListener("click", () => {
      if (!document.fullscreenElement) {
        (shell.requestFullscreen || shell.webkitRequestFullscreen)?.call(shell);
      } else {
        document.exitFullscreen?.();
      }
    });
  }

  function showWin(text) {
    winBanner.textContent = text;
    winBanner.classList.add("show");
    setTimeout(() => winBanner.classList.remove("show"), 2400);
  }

  async function spin() {
    if (spinning) return;
    if (!window.AQUA.verified) {
      alert("Verify your account first.");
      autoMode = false;
      return;
    }
    const betStr = (betInput.value || "").trim();
    spinning = true;
    spinBtn.disabled = true;

    try {
      const r = await fetch("/api/slots/spin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slot_id: cfg.id, bet: betStr }),
      });
      const j = await r.json();
      if (!j.ok) {
        alert(j.error || "Spin failed");
        spinning = false;
        spinBtn.disabled = false;
        autoMode = false;
        return;
      }

      const grid = j.grid;
      const h = symH();
      const anims = [];
      for (let c = 0; c < cols; c++) {
        const inner = reelInners[c];
        const kids = inner.querySelectorAll(".sym");
        kids.forEach((k) => makeSym(k, symbols[Math.floor(Math.random() * symbols.length)]));
        const offset = 14 + c * 3;
        for (let r = 0; r < rows; r++) {
          if (kids[offset + r]) makeSym(kids[offset + r], grid[c][r]);
        }
        const targetY = -(offset * h);
        inner.style.transition = "none";
        inner.style.transform = "translateY(0)";
        void inner.offsetWidth;
        const dur = 1.4 + c * 0.3;
        inner.style.transition = `transform ${dur}s cubic-bezier(0.12, 0.75, 0.2, 1)`;
        inner.style.transform = `translateY(${targetY}px)`;
        anims.push(new Promise((res) => setTimeout(res, dur * 1000 + 40)));
      }
      await Promise.all(anims);

      if (balEl && j.balance_fmt) balEl.textContent = j.balance_fmt;
      if (window.AQUA) window.AQUA.balance = j.balance;

      if (j.win > 0) {
        if (j.win >= j.bet * 20) showWin("BIG WIN\n💎 " + j.win_fmt);
        else if (j.win >= j.bet * 5) showWin("NICE\n💎 " + j.win_fmt);
        else showWin("+💎 " + j.win_fmt);
      }
    } catch (e) {
      alert("Network error");
      autoMode = false;
    }
    spinning = false;
    spinBtn.disabled = false;
    if (autoMode) setTimeout(spin, 600);
  }

  spinBtn.addEventListener("click", spin);
})();
