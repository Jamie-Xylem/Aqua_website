(function () {
  const list = document.getElementById("cfList");
  const createBtn = document.getElementById("cfCreate");
  const active = document.getElementById("cfActive");

  async function refresh() {
    try {
      const r = await fetch("/api/coinflip/list");
      const j = await r.json();
      if (!j.ok) return;
      if (!j.games.length) {
        list.innerHTML = '<p style="color:var(--muted);">No open games. Create one.</p>';
        return;
      }
      list.innerHTML = "";
      j.games.forEach((g) => {
        const d = document.createElement("div");
        d.className = "cf-game";
        d.innerHTML = `
          <div class="cf-side">
            <img src="${g.creator_headshot || "/static/img/logo.png"}" alt="" />
            <div>${escape(g.creator_name)}</div>
            <div style="color:var(--muted);font-size:0.8rem;">${g.side}</div>
          </div>
          <div style="text-align:center;">
            <div style="font-weight:800;color:var(--gold);">${g.amount_fmt}</div>
            <button class="btn btn-red join-btn" data-id="${g.id}" style="margin-top:8px;">Join (opposite)</button>
          </div>
          <div class="cf-side" style="opacity:0.4;">
            <img src="/static/img/logo.png" alt="" />
            <div>Waiting…</div>
          </div>`;
        list.appendChild(d);
      });
      list.querySelectorAll(".join-btn").forEach((btn) => {
        btn.addEventListener("click", () => join(btn.dataset.id));
      });
    } catch (e) {}
  }

  function escape(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;");
  }

  async function create() {
    const side = document.getElementById("cfSide").value;
    const amount = document.getElementById("cfAmount").value;
    const r = await fetch("/api/coinflip/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ side, amount }),
    });
    const j = await r.json();
    if (!j.ok) return alert(j.error || "Failed");
    refresh();
  }

  async function join(id) {
    const r = await fetch("/api/coinflip/join", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ game_id: id }),
    });
    const j = await r.json();
    if (!j.ok) return alert(j.error || "Failed");
    showResult(j);
    refresh();
  }

  function showResult(j) {
    active.style.display = "block";
    document.getElementById("cfP1img").src = j.p1_headshot || "/static/img/logo.png";
    document.getElementById("cfP2img").src = j.p2_headshot || "/static/img/logo.png";
    document.getElementById("cfP1name").textContent = j.p1_name;
    document.getElementById("cfP2name").textContent = j.p2_name;
    document.getElementById("cfP1").classList.remove("winner");
    document.getElementById("cfP2").classList.remove("winner");
    const coin = document.getElementById("cfCoin");
    coin.textContent = "?";
    coin.classList.add("flipping");
    setTimeout(() => {
      coin.classList.remove("flipping");
      coin.textContent = j.result === "heads" ? "H" : "T";
      if (j.winner_side === j.p1_side) document.getElementById("cfP1").classList.add("winner");
      else document.getElementById("cfP2").classList.add("winner");
      document.getElementById("cfResult").textContent =
        `${j.winner_name} wins ${j.payout_fmt}!`;
      document.getElementById("cfFair").textContent =
        `Provably fair · server: ${j.server_seed_hash?.slice(0, 16)}… · result seed: ${j.server_seed?.slice(0, 12)}…`;
    }, 1300);
  }

  if (createBtn) createBtn.addEventListener("click", create);
  refresh();
  setInterval(refresh, 5000);
})();
