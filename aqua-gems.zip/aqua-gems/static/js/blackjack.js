(function () {
  const dealerHand = document.getElementById("dealerHand");
  const playerHand = document.getElementById("playerHand");
  const dealerScore = document.getElementById("dealerScore");
  const playerScore = document.getElementById("playerScore");
  const msg = document.getElementById("bjMsg");
  const fair = document.getElementById("bjFair");
  const betInput = document.getElementById("bjBet");
  const dealBtn = document.getElementById("bjDeal");
  const hitBtn = document.getElementById("bjHit");
  const standBtn = document.getElementById("bjStand");

  function renderCards(el, cards, hideFirst) {
    el.innerHTML = "";
    cards.forEach((c, i) => {
      const d = document.createElement("div");
      if (hideFirst && i === 0) {
        d.className = "card-face back";
        d.textContent = "🂠";
      } else {
        const red = c.suit === "♥" || c.suit === "♦";
        d.className = "card-face" + (red ? " red" : "");
        d.innerHTML = `<span>${c.rank}</span><span>${c.suit}</span>`;
      }
      el.appendChild(d);
    });
  }

  async function deal() {
    const bet = betInput.value.trim();
    const r = await fetch("/api/blackjack/deal", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bet }),
    });
    const j = await r.json();
    if (!j.ok) return alert(j.error || "Failed");
    update(j, true);
  }

  async function hit() {
    const r = await fetch("/api/blackjack/hit", { method: "POST" });
    const j = await r.json();
    if (!j.ok) return alert(j.error || "Failed");
    update(j, j.status === "playing");
  }

  async function stand() {
    const r = await fetch("/api/blackjack/stand", { method: "POST" });
    const j = await r.json();
    if (!j.ok) return alert(j.error || "Failed");
    update(j, false);
  }

  function update(j, playing) {
    renderCards(playerHand, j.player || [], false);
    renderCards(dealerHand, j.dealer || [], playing);
    playerScore.textContent = j.player_score ?? "?";
    dealerScore.textContent = playing ? "?" : (j.dealer_score ?? "?");
    msg.textContent = j.message || "";
    if (j.fair) fair.textContent = `Provably fair · ${j.fair}`;
    hitBtn.disabled = !playing;
    standBtn.disabled = !playing;
    dealBtn.disabled = playing;
  }

  dealBtn?.addEventListener("click", deal);
  hitBtn?.addEventListener("click", hit);
  standBtn?.addEventListener("click", stand);
})();
