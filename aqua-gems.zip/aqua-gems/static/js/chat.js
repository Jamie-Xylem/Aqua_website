(function () {
  const panel = document.getElementById("chatPanel");
  const overlay = document.getElementById("chatOverlay");
  const toggle = document.getElementById("chatToggle");
  const closeBtn = document.getElementById("chatClose");
  const messages = document.getElementById("chatMessages");
  const input = document.getElementById("chatInput");
  const send = document.getElementById("chatSend");

  function openChat() {
    panel.classList.add("open");
    overlay.classList.add("open");
    loadChat();
  }
  function closeChat() {
    panel.classList.remove("open");
    overlay.classList.remove("open");
  }

  if (toggle) toggle.addEventListener("click", openChat);
  if (closeBtn) closeBtn.addEventListener("click", closeChat);
  if (overlay) overlay.addEventListener("click", closeChat);

  async function loadChat() {
    try {
      const r = await fetch("/api/chat");
      const j = await r.json();
      if (!j.ok) return;
      messages.innerHTML = "";
      (j.messages || []).forEach((m) => {
        const d = document.createElement("div");
        d.className = "chat-msg";
        d.innerHTML = `<div class="who">${escapeHtml(m.user)}</div><div class="txt">${escapeHtml(m.text)}</div>`;
        messages.appendChild(d);
      });
      messages.scrollTop = messages.scrollHeight;
    } catch (e) {}
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  async function sendMsg() {
    if (!window.AQUA.verified) return;
    const text = (input.value || "").trim();
    if (!text) return;
    input.value = "";
    try {
      await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      });
      loadChat();
    } catch (e) {}
  }

  if (send) send.addEventListener("click", sendMsg);
  if (input) {
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") sendMsg();
    });
  }

  setInterval(() => {
    if (panel.classList.contains("open")) loadChat();
  }, 4000);
})();
