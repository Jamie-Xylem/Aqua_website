--[[
  Aqua Gems — DIAGNOSTIC BOT
  Big on-screen panel. If you see the green pulse, script IS running.

  1. Set CONFIG
  2. Execute in PS99 on bot account
  3. Read the panel — it tells you what failed
]]

local CONFIG = {
    API_BASE = "https://aqua-gems.com", -- no trailing slash
    BOT_KEY = "Meth6918",
    BOT_USERNAME = "beingbraindedisfun12",
}

-- =========================================================
-- UI (always visible proof)
-- =========================================================
local Players = game:GetService("Players")
local LP = Players.LocalPlayer
local HttpService = game:GetService("HttpService")
local RS = game:GetService("ReplicatedStorage")
local VIM = game:GetService("VirtualInputManager")
local RunService = game:GetService("RunService")

local function parentGui(gui)
    local ok = pcall(function() gui.Parent = game:GetService("CoreGui") end)
    if not ok or not gui.Parent then
        gui.Parent = LP:WaitForChild("PlayerGui")
    end
end

local gui = Instance.new("ScreenGui")
gui.Name = "AquaBotDiag"
gui.ResetOnSpawn = false
gui.DisplayOrder = 99999
gui.IgnoreGuiInset = true
parentGui(gui)

local frame = Instance.new("Frame")
frame.Size = UDim2.new(0, 340, 0, 260)
frame.Position = UDim2.new(0, 10, 0.35, 0)
frame.BackgroundColor3 = Color3.fromRGB(8, 12, 24)
frame.BackgroundTransparency = 0.05
frame.BorderSizePixel = 0
frame.Active = true
frame.Draggable = true
frame.Parent = gui
Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 14)
local stroke = Instance.new("UIStroke", frame)
stroke.Color = Color3.fromRGB(91, 140, 255)
stroke.Thickness = 2

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -50, 0, 28)
title.Position = UDim2.new(0, 12, 0, 8)
title.BackgroundTransparency = 1
title.Text = "AQUA BOT · LIVE"
title.Font = Enum.Font.GothamBold
title.TextSize = 18
title.TextColor3 = Color3.fromRGB(91, 140, 255)
title.TextXAlignment = Enum.TextXAlignment.Left
title.Parent = frame

local pulse = Instance.new("Frame")
pulse.Size = UDim2.new(0, 14, 0, 14)
pulse.Position = UDim2.new(1, -28, 0, 14)
pulse.BackgroundColor3 = Color3.fromRGB(60, 255, 140)
pulse.BorderSizePixel = 0
pulse.Parent = frame
Instance.new("UICorner", pulse).CornerRadius = UDim.new(1, 0)

local body = Instance.new("TextLabel")
body.Size = UDim2.new(1, -20, 1, -48)
body.Position = UDim2.new(0, 10, 0, 40)
body.BackgroundTransparency = 1
body.Text = "Booting…"
body.Font = Enum.Font.Code
body.TextSize = 13
body.TextColor3 = Color3.fromRGB(220, 230, 245)
body.TextXAlignment = Enum.TextXAlignment.Left
body.TextYAlignment = Enum.TextYAlignment.Top
body.TextWrapped = true
body.Parent = frame

local logLines = {}
local function ui(msg)
    table.insert(logLines, os.date("%H:%M:%S") .. " " .. tostring(msg))
    while #logLines > 12 do table.remove(logLines, 1) end
    body.Text = table.concat(logLines, "\n")
end

-- green pulse = script alive
task.spawn(function()
    local on = true
    while gui.Parent do
        pulse.BackgroundColor3 = on and Color3.fromRGB(60, 255, 140) or Color3.fromRGB(20, 40, 30)
        on = not on
        task.wait(0.5)
    end
end)

ui("Script loaded in " .. (game.PlaceId or "?"))
ui("Player: " .. LP.Name)

-- =========================================================
-- HTTP (many executor names)
-- =========================================================
local function rawRequest(opts)
    local fns = {
        function() return request(opts) end,
        function() return http_request(opts) end,
        function() return syn and syn.request and syn.request(opts) end,
        function() return fluxus and fluxus.request and fluxus.request(opts) end,
        function() return http and http.request and http.request(opts) end,
        function() return (getgenv and getgenv().request) and getgenv().request(opts) end,
    }
    for _, fn in ipairs(fns) do
        local ok, res = pcall(fn)
        if ok and res and (res.Body or res.body) then
            return {
                StatusCode = res.StatusCode or res.Status or res.status_code,
                Body = res.Body or res.body,
            }
        end
    end
    return nil
end

local function http(method, path, bodyTable)
    local url = CONFIG.API_BASE .. path
    local opts = {
        Url = url,
        Method = method,
        Headers = {
            ["X-Bot-Key"] = CONFIG.BOT_KEY,
            ["Content-Type"] = "application/json",
        },
    }
    if bodyTable then
        opts.Body = HttpService:JSONEncode(bodyTable)
    end
    local res = rawRequest(opts)
    if not res then
        ui("HTTP NO FUNCTION — executor blocked?")
        return nil
    end
    ui("HTTP " .. method .. " " .. tostring(res.StatusCode))
    local ok, data = pcall(function()
        return HttpService:JSONDecode(res.Body)
    end)
    if not ok then
        ui("Bad JSON: " .. string.sub(tostring(res.Body), 1, 60))
        return nil
    end
    return data
end

-- =========================================================
-- Startup API test
-- =========================================================
ui("Testing API…")
local wl = http("GET", "/api/bot/pet_whitelist")
local WHITELIST = {}
if wl and wl.ok and wl.names then
    for _, n in ipairs(wl.names) do WHITELIST[n:lower()] = true end
    ui("API OK · " .. #wl.names .. " pets")
else
    ui("API FAIL — check BOT_KEY / site URL")
    ui("Key starts: " .. string.sub(CONFIG.BOT_KEY, 1, 6) .. "…")
end

local function isAllowed(name)
    local n = (name or ""):lower()
    if not (n:find("huge") or n:find("titanic")) then return false end
    return WHITELIST[n] == true
end

-- =========================================================
-- Click helpers
-- =========================================================
local function clickBtn(btn)
    pcall(function()
        if getconnections then
            for _, c in ipairs(getconnections(btn.MouseButton1Click) or {}) do
                pcall(function() c:Fire() end)
            end
        end
    end)
    pcall(function() if firesignal then firesignal(btn.MouseButton1Click) end end)
    pcall(function()
        local p, s = btn.AbsolutePosition, btn.AbsoluteSize
        VIM:SendMouseButtonEvent(p.X + s.X/2, p.Y + s.Y/2, 0, true, game, 0)
        task.wait(0.05)
        VIM:SendMouseButtonEvent(p.X + s.X/2, p.Y + s.Y/2, 0, false, game, 0)
    end)
end

local function tryAccept()
    local found = false
    pcall(function()
        for _, d in ipairs(LP.PlayerGui:GetDescendants()) do
            if d:IsA("TextButton") or d:IsA("ImageButton") then
                local t = ((d.Text or "") .. d.Name):lower()
                if (t:find("accept") or t:find("confirm")) and d.AbsoluteSize.X > 8 then
                    ui("Click Accept UI")
                    clickBtn(d)
                    found = true
                end
            end
        end
    end)
    for _, r in ipairs(RS:GetDescendants()) do
        if r:IsA("RemoteEvent") then
            local n = r.Name:lower()
            if n:find("trade") and n:find("accept") then
                pcall(function() r:FireServer() r:FireServer(true) end)
                ui("Remote Accept: " .. r.Name)
                found = true
            end
        end
    end
    return found
end

local function tryDecline()
    pcall(function()
        for _, d in ipairs(LP.PlayerGui:GetDescendants()) do
            if d:IsA("TextButton") then
                local t = (d.Text or ""):lower()
                if t:find("decline") or t:find("cancel") then clickBtn(d) end
            end
        end
    end)
end

-- =========================================================
-- Trade scan loop
-- =========================================================
local lastHash, cool = "", 0

local function scanTrade()
    if tick() < cool then return end
    local pets, seen = {}, {}
    pcall(function()
        for _, d in ipairs(LP.PlayerGui:GetDescendants()) do
            if d:IsA("TextLabel") or d:IsA("TextButton") then
                local t = (d.Text or ""):match("^%s*(.-)%s*$") or ""
                local low = t:lower()
                if #t > 3 and (low:find("huge") or low:find("titanic"))
                    and not seen[low] and not low:find("accept") and not low:find("decline") then
                    seen[low] = true
                    table.insert(pets, t)
                end
            end
        end
    end)
    if #pets == 0 then return end

    local hash = table.concat(pets, "|")
    if hash == lastHash then return end
    ui("TRADE: " .. hash:sub(1, 50))

    for _, p in ipairs(pets) do
        if not isAllowed(p) then
            ui("Refuse: " .. p)
            tryDecline()
            lastHash = hash
            cool = tick() + 4
            return
        end
    end

    local other = "unknown"
    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= LP then other = plr.Name break end
    end
    ui("Trader: " .. other)

    local res = http("POST", "/api/bot/deposit", {
        roblox_user = other,
        pets = pets,
        bot = CONFIG.BOT_USERNAME,
    })

    if res and res.ok then
        ui("CREDITED " .. tostring(res.credit_fmt or res.credit))
        tryAccept()
        task.wait(0.4)
        tryAccept()
        ui("Accepted (or tap Accept)")
        lastHash = hash
        cool = tick() + 6
    else
        ui("NO CREDIT: " .. tostring(res and res.error or "fail"))
        tryDecline()
        lastHash = hash
        cool = tick() + 4
    end
end

-- heartbeat + scan
local ticks = 0
task.spawn(function()
    while gui.Parent do
        ticks += 1
        if ticks % 10 == 0 then
            ui("Alive · scanning… " .. ticks)
        end
        pcall(scanTrade)
        task.wait(1.2)
    end
end)

ui("Ready. Open a trade with a Huge.")
ui("Drag this panel if it covers UI.")
