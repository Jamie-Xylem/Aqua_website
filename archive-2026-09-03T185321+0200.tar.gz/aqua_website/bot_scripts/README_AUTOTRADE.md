# Aqua Gems — Auto Trade Bot

## Server env
```
export BOT_API_KEY=your-long-secret
```

## Lua script
`AquaAutoTrade.lua` — run on the bot account in PS99 via executor.

### Tab A8 optimisations
- Lowest render quality
- Particles/trails disabled
- Non-trade GUIs hidden
- Light polling loop

### Rules enforced
- Trade only (no mail)
- Only pets in `pets_db.json` (Huges + Titanics)
- Anything else → refuse
- Deposit credit = 75% RAP
- Win with pet wager → pet returned + 92.5% RAP gems

### API
- GET  /api/bot/pet_whitelist  (X-Bot-Key)
- GET  /api/bot/pets
- POST /api/bot/deposit        { roblox_user, pets: ["Titanic Cat", ...] }
- GET  /api/bot/pending_withdraws
- POST /api/bot/withdraw_claimed { id }

### Pet DB
`static/data/pets_db.json` — add every Huge/Titanic you accept with RAP + image path.
Bot never accepts a name not in this file.
