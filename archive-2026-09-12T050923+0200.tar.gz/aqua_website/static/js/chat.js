(function () {
  const panel = document.getElementById("chatPanel");
  const overlay = document.getElementById("chatOverlay");
  const toggle = document.getElementById("chatToggle");
  const closeBtn = document.getElementById("chatClose");
  const messages = document.getElementById("chatMessages");
  const input = document.getElementById("chatInput");
  const send = document.getElementById("chatSend");
  let replyTo = null;
  let lastCount = 0;
  let lastId = null;
  const isMod = !!(window.AQUA && (window.AQUA.is_admin || window.AQUA.is_staff));

  function openChat() {
    if (panel) panel.classList.add("open");
    if (overlay) overlay.classList.add("open");
    clearNotif();
    loadChat();
  }
  function closeChat() {
    if (panel) panel.classList.remove("open");
    if (overlay) overlay.classList.remove("open");
  }
  if (toggle) toggle.addEventListener("click", openChat);
  if (closeBtn) closeBtn.addEventListener("click", closeChat);
  if (overlay) overlay.addEventListener("click", closeChat);

  function escapeHtml(s) {
    return String(s || "")
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function badgeHtml(m) {
    if (!m.role_badge) return "";
    return '<img class="role-badge" src="/static/img/badges/' + escapeHtml(m.role_badge) + '.png" alt="" />';
  }
  function nameStyle(m) {
    if (m.role_gradient) {
      return 'background:' + m.role_gradient + ';-webkit-background-clip:text;background-clip:text;color:transparent;font-weight:800;';
    }
    return 'color:' + (m.name_color || "#2ee6d6") + ';';
  }
  function modBtns(m) {
    if (!isMod || !m.id) return "";
    return '<div class="mod-acts">' +
      '<button type="button" class="mod-del" data-id="' + escapeHtml(m.id) + '" title="Delete">🗑</button>' +
      (m.uid ? '<button type="button" class="mod-to" data-uid="' + escapeHtml(m.uid) + '" title="Timeout 5m">⏱</button>' : '') +
      '</div>';
  }
  function timeStr(ts) {
    if (!ts) return "";
    try {
      const d = new Date(ts);
      if (isNaN(d.getTime())) return "";
      return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    } catch (e) { return ""; }
  }
  function clearNotif() {
    if (toggle) {
      toggle.classList.remove("has-notif");
      const b = toggle.querySelector(".chat-badge");
      if (b) b.remove();
    }
  }
  function showNotif() {
    if (panel && panel.classList.contains("open")) return;
    if (!toggle) return;
    toggle.classList.add("has-notif");
    let b = toggle.querySelector(".chat-badge");
    if (!b) {
      b = document.createElement("span");
      b.className = "chat-badge";
      toggle.appendChild(b);
    }
    // soft beep
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.frequency.value = 880; g.gain.value = 0.04;
      o.start(); o.stop(ctx.currentTime + 0.08);
    } catch (e) {}
  }

  async function loadChat() {
    if (!messages) return;
    try {
      const r = await fetch("/api/chat");
      const j = await r.json();
      if (!j.ok) return;
      const list = j.messages || [];
      const newest = list.length ? (list[list.length - 1].id || list.length) : null;
      if (lastId && newest && newest !== lastId && list.length >= lastCount) {
        showNotif();
      }
      lastCount = list.length;
      lastId = newest;

      messages.innerHTML = "";
      if (!list.length) { messages.innerHTML = '<p class="muted" style="text-align:center;padding:20px">No messages yet</p>'; }
      list.forEach((m) => {
        const d = document.createElement("div");
        const txt = m.msg || m.text || "";
        const tm = timeStr(m.ts || m.time || m.created_at);
        if (m.type === "rain" || (txt && txt.indexOf("RAIN STARTED") !== -1)) {
          d.className = "chat-msg rain-msg";
          d.innerHTML =
            '<img src="/static/img/banner_rain.jpg" alt="Rain" />' +
            '<div class="rain-body"><div><div class="who">' + escapeHtml(m.user) +
            (tm ? ' <span class="chat-time">' + tm + '</span>' : '') +
            '</div><div class="txt">' + escapeHtml(txt) + '</div></div>' +
            (m.rain_id ? '<button class="btn btn-red btn-sm join-rain" data-id="' + escapeHtml(m.rain_id) + '">Join</button>' : '') +
            '</div>';
          const btn = d.querySelector(".join-rain");
          if (btn) {
            btn.addEventListener("click", async (e) => {
              e.stopPropagation();
              const rr = await fetch("/api/rain/join", {
                method: "POST", headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ rain_id: btn.dataset.id }),
              });
              const jj = await rr.json();
              alert(jj.ok ? "Joined!" : jj.error || "Failed");
            });
          }
        } else {
          d.className = "chat-msg" + (m.reply_to ? " reply" : "");
          d.dataset.id = m.id || "";
          let extra = m.reply_to ? '<div class="reply-ref">↩ reply</div>' : "";
          const tc = m.text_color || "#e8ecf4";
          const border = m.avatar_border || "none";
          const borderColor = {gold:"#ffc857",red:"#ff3b4a",cyan:"#2ee6d6",rainbow:"#ff00aa",diamond:"#b8f0ff",titanic:"#5b8def",galaxy:"#c44dff"}[border] || "transparent";
          const av = m.avatar
            ? '<div class="avatar-wrap" style="border-color:' + borderColor + '"><img src="' + escapeHtml(m.avatar) + '" style="width:100%;height:100%;object-fit:cover" /></div>'
            : "";
          const lvl = m.level ? '<span class="lvl">Lv ' + m.level + '</span>' : "";
          const title = m.profile_title ? '<span class="chat-title">' + escapeHtml(m.profile_title) + '</span>' : "";
          d.innerHTML = extra + '<div class="row">' + av + '<div style="flex:1;min-width:0">' +
            '<div class="who" style="' + nameStyle(m) + '">' + badgeHtml(m) + escapeHtml(m.user) + lvl + title +
            (tm ? ' <span class="chat-time">' + tm + '</span>' : '') +
            '</div>' +
            '<div class="txt" style="color:' + tc + '">' + escapeHtml(txt) + '</div></div>' +
            modBtns(m) + '</div>';
          d.addEventListener("click", (e) => {
            if (e.target.closest(".mod-acts")) return;
            replyTo = m.id || m.user;
            if (input) { input.placeholder = "Reply to " + m.user + "…"; input.focus(); }
          });
        }
        messages.appendChild(d);
      });
      messages.scrollTop = messages.scrollHeight;

      messages.querySelectorAll(".mod-del").forEach((btn) => {
        btn.onclick = async (e) => {
          e.stopPropagation();
          await fetch("/api/chat/delete", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id: btn.dataset.id }),
          });
          loadChat();
        };
      });
      messages.querySelectorAll(".mod-to").forEach((btn) => {
        btn.onclick = async (e) => {
          e.stopPropagation();
          await fetch("/api/chat/timeout", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ uid: btn.dataset.uid, minutes: 5 }),
          });
          alert("Timed out 5m");
        };
      });
    } catch (e) {}
  }

  async function sendMsg() {
    if (!input || !window.AQUA || !window.AQUA.verified) return;
    const msg = input.value.trim();
    if (!msg) return;
    input.value = "";
    await fetch("/api/chat", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ msg, reply_to: replyTo }),
    });
    replyTo = null;
    input.placeholder = "Type a message…";
    loadChat();
  }
  if (send) send.addEventListener("click", sendMsg);
  if (input) input.addEventListener("keydown", (e) => { if (e.key === "Enter") sendMsg(); });

  setInterval(loadChat, 3500);
  loadChat();
})();
