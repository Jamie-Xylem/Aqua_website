"""
Aqua Gems Website — configuration
Shares casino_data.json with the Discord bot.
"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

DEFAULT_DATA = BASE_DIR.parent / "casino_data.json"
DATA_FILE = Path(os.environ.get("CASINO_DATA_FILE", str(DEFAULT_DATA)))

SECRET_KEY = os.environ.get("WEBSITE_SECRET_KEY", "aqua-gems-secret-change-me-2026")
ADMIN_API_KEY = os.environ.get("ADMIN_API_KEY", "aqua-admin-key-change-me")

# Discord OAuth (primary login)
DISCORD_CLIENT_ID = os.environ.get("DISCORD_CLIENT_ID", "1544130936294211734")
DISCORD_CLIENT_SECRET = os.environ.get("DISCORD_CLIENT_SECRET", "")  # REQUIRED for OAuth
DISCORD_REDIRECT_URI = os.environ.get("DISCORD_REDIRECT_URI", "https://aqua-gems.com/verify2")
DISCORD_BOT_TOKEN = os.environ.get("DISCORD_BOT_TOKEN", "")  # for creating rain webhook etc.

# Prefer ENV so you can change the bot user across the whole site without editing code.
# Fallback is the live bot account.
BOT_ROBLOX_USERNAME = (
    os.environ.get("BOT_ROBLOX_USERNAME")
    or os.environ.get("BOT_USERNAME")
    or "beingbraindedisfun12"
)
BOT_API_KEY = os.environ.get("BOT_API_KEY") or os.environ.get("TRADEBOT_SECRET") or "Meth6918"
MIN_AMOUNT = 10_000_000

HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "25632"))

DISCORD_WEBHOOK_URL = os.environ.get("DISCORD_WEBHOOK_URL", "")

# House edge applied silently (never shown to users)
HOUSE_EDGE = 0.075  # 7.5%

BIG_GAMES_BASE = "https://ps99.biggamesapi.io"
ROBLOX_USERS_API = "https://users.roblox.com/v1/usernames/users"
ROBLOX_THUMBNAIL_API = "https://thumbnails.roblox.com/v1/users/avatar-headshot"

# Rain / tip
RAIN_CHANNEL_ID = 1536382500115320862
RAIN_ROLE_ID = 1536553603668648016
RAIN_DURATION_SECONDS = 120  # 2 minutes default


# ============================================================
# GAME ODDS / MULTIPLIERS (source of truth for UI + backend)
# ============================================================
# Upgrader: multiplier -> win chance percent (before house edge display)
# chance ≈ (1 / mult) * (1 - HOUSE_EDGE) * 100 for fair edge
UPGRADER_MULTS = {
    1.5:  {"chance": 61.67, "label": "1.5x"},
    1.6:  {"chance": 57.81, "label": "1.6x"},
    2.0:  {"chance": 46.25, "label": "2x"},
    3.0:  {"chance": 30.83, "label": "3x"},
    5.0:  {"chance": 18.50, "label": "5x"},
    10.0: {"chance": 9.25,  "label": "10x"},
    20.0: {"chance": 4.625, "label": "20x"},
    50.0: {"chance": 1.85,  "label": "50x"},
}

# Wheel segments (index order matches wheel visual)
WHEEL_SEGMENTS = [
    {"mult": 0,   "weight": 2},
    {"mult": 0.5, "weight": 2},
    {"mult": 1.2, "weight": 1},
    {"mult": 0,   "weight": 2},
    {"mult": 2,   "weight": 1},
    {"mult": 0.5, "weight": 2},
    {"mult": 1.5, "weight": 1},
    {"mult": 3,   "weight": 1},
]

# Color Dice (PvP) — 9 colors, 6 dice; house takes COLOR_DICE_HOUSE on pot
COLOR_DICE_HOUSE = 0.075
COLOR_DICE_COLORS = ["red", "orange", "yellow", "green", "blue", "purple", "brown", "black", "white"]

# Coinflip house cut on pot
COINFLIP_HOUSE = 0.05

# Blackjack
BLACKJACK_PAYS = 1.5  # 3:2
BLACKJACK_DEALER_HITS_SOFT_17 = True

# Roulette (if used)
ROULETTE_HOUSE = 0.027  # single-zero style edge approx

# Min bets
MIN_BET = MIN_AMOUNT
MAX_UPGRADER_BET = 500_000_000
