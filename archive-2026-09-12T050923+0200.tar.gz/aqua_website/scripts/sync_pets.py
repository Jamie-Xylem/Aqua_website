#!/usr/bin/env python3
"""Refresh static/data/pets_db.json from BigGames API (Huge + Titanic only)."""
import json, re, hashlib, time, urllib.request
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
OUT = BASE / "static" / "data" / "pets_db.json"

def get(url, timeout=90):
    req = urllib.request.Request(url, headers={"User-Agent": "AquaGems-PetSync/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())

def asset_id(thumb):
    if not thumb:
        return None
    m = re.search(r"(\d+)", str(thumb))
    return m.group(1) if m else None

def main():
    pets_list = (get("https://ps99.biggamesapi.io/api/collection/Pets").get("data") or [])
    rap_list = (get("https://ps99.biggamesapi.io/api/rap").get("data") or [])
    exists_list = (get("https://ps99.biggamesapi.io/api/exists").get("data") or [])

    rap_index = {}
    for e in rap_list:
        cd = e.get("configData") or {}
        name = (cd.get("id") or "").strip()
        if not name:
            continue
        rap_index.setdefault(name.lower(), []).append({
            "rap": e.get("value") or 0, "pt": cd.get("pt"), "sh": cd.get("sh"),
        })
    exists_index = {}
    for e in exists_list:
        cd = e.get("configData") or {}
        name = (cd.get("id") or "").strip()
        if not name:
            continue
        exists_index.setdefault(name.lower(), []).append({
            "exists": e.get("value") or 0, "pt": cd.get("pt"), "sh": cd.get("sh"),
        })

    def normal_rap(name):
        variants = rap_index.get(name.lower()) or []
        for v in variants:
            if not v.get("pt") and not v.get("sh"):
                return int(v["rap"] or 0)
        return int(variants[0]["rap"] or 0) if variants else 0

    def normal_exists(name):
        variants = exists_index.get(name.lower()) or []
        for v in variants:
            if not v.get("pt") and not v.get("sh"):
                return int(v["exists"] or 0)
        return int(variants[0]["exists"] or 0) if variants else 0

    pets = []
    for p in pets_list:
        cd = p.get("configData") or {}
        name = cd.get("name") or p.get("configName") or ""
        cat = (p.get("category") or "").lower()
        is_huge = cat == "huge" or cd.get("huge") is True or name.lower().startswith("huge ")
        is_titanic = cat == "titanic" or cd.get("titanic") is True or name.lower().startswith("titanic ")
        if not (is_huge or is_titanic):
            continue
        tid = asset_id(cd.get("thumbnail"))
        gid = asset_id(cd.get("goldenThumbnail"))
        rap = normal_rap(name)
        pets.append({
            "id": hashlib.md5(name.encode()).hexdigest()[:12],
            "name": name,
            "tier": "Titanic" if is_titanic else "Huge",
            "rap": rap,
            "credit_75": int(rap * 0.75),
            "exists": normal_exists(name),
            "image": f"https://ps99.biggamesapi.io/image/{tid}" if tid else None,
            "golden_image": f"https://ps99.biggamesapi.io/image/{gid}" if gid else None,
            "thumbnail_id": tid,
            "accepted": rap > 0,
            "desc": cd.get("indexDesc") or "",
        })

    pets.sort(key=lambda x: -x["rap"])
    out = {
        "updated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "source": "ps99.biggamesapi.io",
        "deposit_rate": 0.75,
        "win_pet_gem_rate": 0.925,
        "huge_count": sum(1 for p in pets if p["tier"] == "Huge"),
        "titanic_count": sum(1 for p in pets if p["tier"] == "Titanic"),
        "pets": pets,
        "huges": [p for p in pets if p["tier"] == "Huge"],
        "titanics": [p for p in pets if p["tier"] == "Titanic"],
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(out))
    print(f"Synced {len(pets)} pets -> {OUT}")

if __name__ == "__main__":
    main()
