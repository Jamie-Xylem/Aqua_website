print("RUNNING AQUA AUTO")
game:GetService("RunService"):Set3dRenderingEnabled(false)
pcall(function()
	loadstring(game:HttpGet("https://raw.githubusercontent.com/hassanxzayn-lua/Anti-afk/main/antiafkbyhassanxzyn"))()
end)
task.wait(5)
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local HttpService = game:GetService("HttpService")
local API_BASE = "https://aqua-gems.com"
local API_KEY  = "change-this-key-in-production"
local INTERVAL_SECONDS = 90
local WITHDRAWAL_DELAY = 2.5
local function parseAmount(amount)
	if typeof(amount) == "number" then return amount end
	if typeof(amount) ~= "string" then return nil end
	local s = amount:lower():gsub(",", ""):gsub("%s+", "")
	local asNum = tonumber(s)
	if asNum then return asNum end
	local numStr, suffix = s:match("^([%d%.]+)(%a+)$")
	if not numStr then return nil end
	local n = tonumber(numStr)
	local multipliers = { k = 1e3, m = 1e6, b = 1e9, t = 1e12 }
	local mult = multipliers[(suffix or ""):lower()]
	if not mult then return nil end
	return math.floor(n * mult + 0.5)
end
local function cleanUsername(s)
	return tostring(s or ""):gsub("^%s*", ""):gsub("%s*$", ""):gsub("^@", "")
end
local function userIdToUsername(userId)
	local ok, res = pcall(function() return Players:GetNameFromUserIdAsync(tonumber(userId)) end)
	if ok then return res end
end
local GetSave = function() return require(ReplicatedStorage.Library.Client.Save).Get() end
local function gemSend(username, amount)
	local amt = parseAmount(amount)
	if not amt or amt <= 0 then return false, "bad amt" end
	for i, v in pairs(GetSave().Inventory.Currency) do
		if v.id == "Diamonds" then
			local ok, res = pcall(function()
				return ReplicatedStorage:WaitForChild("Network"):WaitForChild("Mailbox: Send")
					:InvokeServer(tostring(username), "Aqua - Withdrawal Payout", "Currency", i, amt)
			end)
			return ok, res
		end
	end
	return false, "no diamonds"
end
local function do_request(req)
	if typeof(request) == "function" then return request(req) end
	if typeof(http_request) == "function" then return http_request(req) end
	local ok, res = pcall(function() return HttpService:RequestAsync(req) end)
	if not ok then return { Success = false, StatusCode = 0, Body = tostring(res) } end
	return res
end
local function apiRequest(method, path, bodyTable)
	local headers = { ["X-API-Key"] = API_KEY }
	local body = nil
	if bodyTable ~= nil then
		body = HttpService:JSONEncode(bodyTable)
		headers["Content-Type"] = "application/json"
	end
	local res = do_request({ Url = API_BASE .. path, Method = method, Headers = headers, Body = body })
	local success = res.Success
	if success == nil and res.status then success = (tonumber(res.status) >= 200 and tonumber(res.status) < 300) end
	local responseBody = res.Body or res.body or ""
	if not success then return nil, tostring(res.StatusCode or res.status) .. " " .. tostring(responseBody) end
	if responseBody == "" then return {}, nil end
	local ok, decoded = pcall(function() return HttpService:JSONDecode(responseBody) end)
	if not ok then return nil, "json" end
	return decoded, nil
end
local function processWithdrawals()
	local data, err = apiRequest("GET", "/withdrawals", nil)
	if not data then warn("[WD] " .. tostring(err)) return end
	local list = data.withdrawals or {}
	if #list == 0 then print("[WD] none") return end
	local processed = {}
	for _, w in ipairs(list) do
		local wid = w.id or w.withdrawal_id
		local amount = w.amount or w.qty or w.gems
		local username = cleanUsername(w.username or w.roblox_username or "")
		if username == "" and w.roblox_id then username = cleanUsername(userIdToUsername(w.roblox_id) or "") end
		if wid and amount and username ~= "" then
			local okSend, sendRes = gemSend(username, amount)
			if okSend then
				processed[tostring(wid)] = HttpService:GenerateGUID(false)
				print(("[WD] PAID %s -> @%s"):format(tostring(wid), username))
			else
				warn(("[WD] FAIL %s %s"):format(tostring(wid), tostring(sendRes)))
			end
			task.wait(WITHDRAWAL_DELAY)
		end
	end
	local n = 0
	for _ in pairs(processed) do n = n + 1 end
	if n > 0 then apiRequest("POST", "/withdrawals/processed", { withdrawals = processed }) end
end
print("Aqua auto loop")
local cycleStart = os.clock()
while true do
	pcall(processWithdrawals)
	cycleStart = cycleStart + INTERVAL_SECONDS
	while os.clock() < cycleStart do task.wait(0.5) end
end
