(function () {
  const cfg = window.SLOT_CONFIG;
  const reelsEl = document.getElementById("reels");
  const loader = document.getElementById("slotLoader");
  const spinBtn = document.getElementById("spinBtn");
  const betInput = document.getElementById("betInput");
  const betLabel = document.getElementById("betLabel");
  const winBanner = document.getElementById("winBanner");
  const balEl = document.getElementById("slotBal");
  const btnMute = document.getElementById("btnMute");
  const btnFS = document.getElementById("btnFS");
  const btnInfo = document.getElementById("btnInfo");
  const shell = document.getElementById("gameShell");
  const jMini = document.getElementById("jMini");
  const jMajor = document.getElementById("jMajor");

  let muted = false;
  let spinning = false;
  let autoMode = false;
  const cols = cfg.reels || 5;
  const rows = cfg.rows || 3;
  const symbols = cfg.symbols || ["💎", "7️⃣", "🔔", "🍒", "🍋", "⭐", "👑", "BAR"];
  const presets = ["100k", "250k", "500k", "1m", "2.5m", "5m", "10m", "25m", "50m", "100m"];
  const symH = () => (window.innerWidth < 400 ? 54 : 64);

  const symMap = {};
  symbols.forEach((s, i) => {
    symMap[s] = "/static/symbols/" + cfg.id + "/s" + i + ".svg";
  });

  const reelInners = [];

  function makeSym(el, text) {
    el.innerHTML = "";
    const tile = document.createElement("div");
    tile.className = "sym-tile";
    const url = symMap[text];
    if (url) {
      const img = document.createElement("img");
      img.src = url;
      img.alt = text;
      img.loading = "eager";
      img.onerror = function () { tile.textContent = text; };
      tile.appendChild(img);
    } else {
      tile.textContent = text;
    }
    el.appendChild(tile);
  }

  for (let c = 0; c < cols; c++) {
    const reel = document.createElement("div");
    reel.className = "reel";
    const inner = document.createElement("div");
    inner.className = "reel-inner";
    for (let i = 0; i < 40; i++) {
      const s = document.createElement("div");
      s.className = "sym";
      makeSym(s, symbols[Math.floor(Math.random() * symbols.length)]);
      inner.appendChild(s);
    }
    reel.appendChild(inner);
    reelsEl.appendChild(reel);
    reelInners.push(inner);
  }

  setTimeout(function () { if (loader) loader.classList.add("hide"); }, 1400);

  function parseBet(s) {
    s = String(s || "").toLowerCase().replace(/,/g, "").trim();
    const m = s.match(/^([\d.]+)\s*([kmbt])?$/);
    if (!m) return 0;
    let n = parseFloat(m[1]);
    const mult = { k: 1e3, m: 1e6, b: 1e9, t: 1e12 }[m[2]] || 1;
    return Math.floor(n * mult);
  }
  function fmt(n) {
    n = Number(n) || 0;
    if (n >= 1e9) return (n / 1e9).toFixed(2).replace(/\.?0+$/, "") + "B";
    if (n >= 1e6) return (n / 1e6).toFixed(2).replace(/\.?0+$/, "") + "M";
    if (n >= 1e3) return (n / 1e3).toFixed(2).replace(/\.?0+$/, "") + "K";
    return String(n);
  }
  function syncBetLabel() {
    const v = parseBet(betInput.value);
    if (betLabel) betLabel.textContent = v ? fmt(v) : "—";
  }
  if (betInput) {
    betInput.addEventListener("input", syncBetLabel);
    syncBetLabel();
  }

  var bm = document.getElementById("betMinus");
  if (bm) bm.addEventListener("click", function () {
    const cur = parseBet(betInput.value);
    let idx = presets.findIndex(function (p) { return parseBet(p) >= cur; });
    if (idx < 0) idx = presets.length - 1;
    idx = Math.max(0, idx - 1);
    betInput.value = presets[idx];
    syncBetLabel();
  });
  var bp = document.getElementById("betPlus");
  if (bp) bp.addEventListener("click", function () {
    const cur = parseBet(betInput.value);
    let idx = presets.findIndex(function (p) { return parseBet(p) > cur; });
    if (idx < 0) idx = presets.length - 1;
    betInput.value = presets[idx];
    syncBetLabel();
  });

  var ba = document.getElementById("btnAuto");
  if (ba) ba.addEventListener("click", function () {
    autoMode = !autoMode;
    ba.style.outline = autoMode ? "2px solid var(--gold)" : "";
    if (autoMode && !spinning) spin();
  });

  if (btnMute) {
    btnMute.addEventListener("click", function () {
      muted = !muted;
      btnMute.textContent = muted ? "🔇" : "🔊";
    });
  }
  if (btnFS) {
    btnFS.addEventListener("click", function () {
      if (!document.fullscreenElement) {
        (shell.requestFullscreen || shell.webkitRequestFullscreen).call(shell);
      } else {
        document.exitFullscreen && document.exitFullscreen();
      }
    });
  }

  function showInfo() {
    var modal = document.getElementById("slotInfoModal");
    if (modal) modal.remove();
    modal = document.createElement("div");
    modal.id = "slotInfoModal";
    modal.style.cssText = "position:fixed;inset:0;z-index:100;background:rgba(0,0,0,0.85);display:flex;align-items:center;justify-content:center;padding:16px;";
    modal.innerHTML = "<div style=\"background:#120a08;border:2px solid rgba(255,180,60,0.4);border-radius:14px;max-width:420px;width:100%;max-height:85vh;overflow:auto;padding:18px;color:#eee;\">" +
      "<div style=\"display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;\">" +
      "<strong style=\"color:#ffd56a;font-size:1.1rem;\">" + (cfg.emoji || "") + " " + cfg.name + "</strong>" +
      "<button id=\"infoClose\" style=\"background:none;border:none;color:#aaa;font-size:1.4rem;cursor:pointer;\">✕</button></div>" +
      "<div id=\"infoBody\"></div></div>";
    document.body.appendChild(modal);
    modal.addEventListener("click", function (e) { if (e.target === modal) modal.remove(); });
    document.getElementById("infoClose").addEventListener("click", function () { modal.remove(); });

    var body = document.getElementById("infoBody");
    var pt = cfg.paytable || {};
    var payRows = "";
    Object.keys(pt).forEach(function (sym) {
      var pays = pt[sym];
      var p3 = pays["3"] != null ? pays["3"] : "—";
      var p4 = pays["4"] != null ? pays["4"] : "—";
      var p5 = pays["5"] != null ? pays["5"] : "—";
      var img = symMap[sym]
        ? "<img src=\"" + symMap[sym] + "\" style=\"width:28px;height:28px;vertical-align:middle;\" />"
        : sym;
      payRows += "<tr><td style=\"padding:4px 0;\">" + img + "</td><td>×" + p3 + "</td><td>×" + p4 + "</td><td>×" + p5 + "</td></tr>";
    });
    body.innerHTML =
      "<p style=\"color:#9a8;font-size:0.85rem;margin:0 0 10px;\">Max win: <strong style=\"color:#ffd56a;\">" + cfg.max_mult + "x</strong> bet</p>" +
      "<h4 style=\"color:#ffd56a;margin:12px 0 6px;\">Feature — " + (cfg.feature || "—") + "</h4>" +
      "<p style=\"font-size:0.82rem;line-height:1.45;color:#ccc;margin:0 0 12px;\">" +
      (cfg.feature_desc || "Land 3 or more scatter symbols anywhere on the reels to trigger the feature.") + "</p>" +
      "<p style=\"font-size:0.8rem;color:#9a8;margin:0 0 8px;\">Wild: <strong>" + (cfg.wild || "—") + "</strong> · Scatter: <strong>" + (cfg.scatter || "—") + "</strong></p>" +
      "<h4 style=\"color:#ffd56a;margin:14px 0 6px;\">Paytable (left-to-right)</h4>" +
      "<table style=\"width:100%;font-size:0.8rem;border-collapse:collapse;text-align:center;\">" +
      "<tr style=\"color:#9a8;\"><th></th><th>3</th><th>4</th><th>5</th></tr>" + payRows + "</table>" +
      "<p style=\"font-size:0.75rem;color:#777;margin-top:14px;\">Pays on all 3 horizontal lines. Wild substitutes for any symbol except scatter. 3+ scatters trigger the feature bonus.</p>";
  }
  if (btnInfo) btnInfo.addEventListener("click", showInfo);

  function showWin(text) {
    winBanner.textContent = text;
    winBanner.classList.add("show");
    setTimeout(function () { winBanner.classList.remove("show"); }, 2800);
  }

  async function spin() {
    if (spinning) return;
    if (!window.AQUA || !window.AQUA.verified) {
      alert("Verify your account first.");
      autoMode = false;
      return;
    }
    const betStr = (betInput.value || "").trim();
    spinning = true;
    spinBtn.disabled = true;

    try {
      const r = await fetch("/api/slots/spin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slot_id: cfg.id, bet: betStr }),
      });
      const j = await r.json();
      if (!j.ok) {
        alert(j.error || "Spin failed");
        spinning = false;
        spinBtn.disabled = false;
        autoMode = false;
        return;
      }

      const grid = j.grid;
      const h = symH();
      const anims = [];
      for (let c = 0; c < cols; c++) {
        const inner = reelInners[c];
        const kids = inner.querySelectorAll(".sym");
        kids.forEach(function (k) {
          makeSym(k, symbols[Math.floor(Math.random() * symbols.length)]);
        });
        const offset = 14 + c * 3;
        for (let r = 0; r < rows; r++) {
          if (kids[offset + r]) makeSym(kids[offset + r], grid[c][r]);
        }
        const targetY = -(offset * h);
        inner.style.transition = "none";
        inner.style.transform = "translateY(0)";
        void inner.offsetWidth;
        const dur = 1.4 + c * 0.3;
        inner.style.transition = "transform " + dur + "s cubic-bezier(0.12, 0.75, 0.2, 1)";
        inner.style.transform = "translateY(" + targetY + "px)";
        anims.push(new Promise(function (res) { setTimeout(res, dur * 1000 + 40); }));
      }
      await Promise.all(anims);

      if (balEl && j.balance_fmt) balEl.textContent = j.balance_fmt;
      if (window.AQUA) window.AQUA.balance = j.balance;

      if (j.feature) {
        showWin("FEATURE!\n" + j.feature + "\n💎 " + j.win_fmt);
      } else if (j.win > 0) {
        if (j.win >= j.bet * 20) showWin("BIG WIN\n💎 " + j.win_fmt);
        else if (j.win >= j.bet * 5) showWin("NICE\n💎 " + j.win_fmt);
        else showWin("+💎 " + j.win_fmt);
      }
    } catch (e) {
      alert("Network error");
      autoMode = false;
    }
    spinning = false;
    spinBtn.disabled = false;
    if (autoMode) setTimeout(spin, 700);
  }

  spinBtn.addEventListener("click", spin);

  function tickJackpots() {
    if (jMini) jMini.textContent = fmt(500000 + Math.floor(Math.random() * 2000000));
    if (jMajor) jMajor.textContent = fmt(5000000 + Math.floor(Math.random() * 15000000));
  }
  tickJackpots();
  setInterval(tickJackpots, 4000);
})();
