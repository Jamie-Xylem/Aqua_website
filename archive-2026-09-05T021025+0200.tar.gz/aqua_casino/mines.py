"""Aqua Gems Casino — Mines game."""
import discord
from discord import app_commands
from discord.ext import commands, tasks
import aiohttp
import asyncio
import json
import math
import os
import random
import re
import time
from datetime import datetime, timezone

from bot_instance import bot, tree, game_cooldown
from config import *
from data import DATA, save_data, ensure_user, add_history, parse_amount, parse_signed_amount, format_amount
from utils import (
    is_staff, is_verified, verification_check, normal_embed,
    get_live_profit_embed, send_log, update_milestone_roles,
    game_paused, get_user_rank_mention,
)

MINES_MULTIPLIERS = {
    1:  [0.70, 0.75, 0.80, 0.86, 0.90, 0.96, 1.06, 1.10, 1.17, 1.27,
         1.34, 1.40, 1.47, 1.56, 1.67, 1.88, 2.01, 2.16, 2.35, 2.60,
         2.94, 3.45, 3.51, 4.00],

    2:  [0.80, 0.85, 0.90, 0.97, 1.05, 1.10, 1.17, 1.22, 1.26, 1.29,
         1.35, 1.42, 1.50, 1.78, 1.98, 2.37, 2.87, 3.00, 4.45, 6.82,
         9.03, 13.22, 24.20],

    3:  [1.10, 1.18, 1.25, 1.30, 1.39, 1.49, 1.67, 1.79, 1.93, 2.20,
         2.40, 2.67, 3.60, 4.10, 4.70, 5.40, 6.30, 7.50, 9.00, 11.50,
         15.00, 22.00],

    4:  [1.10, 1.21, 1.32, 1.44, 1.56, 1.70, 1.87, 2.05, 2.30, 2.67,
         4.00, 4.70, 5.50, 6.50, 7.80, 9.50, 11.50, 14.00, 17.50, 22.00,
         28.00],

    5:  [1.10, 1.24, 1.33, 1.45, 1.60, 1.81, 2.07, 2.40, 2.80, 3.50,
         4.40, 5.50, 6.80, 7.50, 8.50, 14.00, 17.00, 21.00, 26.00, 32.00],

    6:  [1.10, 1.28, 1.39, 1.46, 1.67, 1.74, 1.94, 2.12, 2.70, 3.70,
         5.00, 6.50, 7.50, 8.00, 9.00, 10.00, 11.00, 12.00, 13.00],

    7:  [1.10, 1.30, 1.43, 1.68, 1.94, 2.10, 3.90, 4.80, 6.00, 7.50,
         9.50, 12.00, 15.00, 19.00, 24.00, 30.00, 37.00, 45.00],

    8:  [1.10, 1.37, 1.73, 2.23, 2.90, 3.70, 4.70, 6.00, 7.70, 10.00,
         13.00, 17.00, 22.00, 28.00, 35.00, 43.00, 52.00],

    9:  [1.10, 1.40, 1.87, 2.49, 3.30, 4.40, 5.80, 7.60, 10.00, 13.50,
         18.00, 24.00, 31.00, 40.00, 50.00, 60.00],

    10: [1.10, 1.40, 1.87, 2.80, 3.90, 5.40, 7.40, 10.00, 13.50, 18.50,
         25.00, 34.00, 45.00, 58.00, 70.00],

    11: [1.10, 1.54, 2.20, 3.20, 4.70, 6.80, 9.80, 14.00, 20.00, 28.00,
         39.00, 52.00, 68.00, 85.00],

    12: [1.10, 1.61, 2.40, 3.70, 5.70, 8.60, 13.00, 19.50, 29.00, 42.00,
         58.00, 75.00, 95.00],

    13: [1.10, 1.68, 2.65, 4.30, 6.90, 11.00, 17.50, 27.00, 40.00, 58.00,
         78.00, 100.00],

    14: [1.10, 1.78, 2.95, 5.10, 8.60, 14.50, 24.00, 38.00, 58.00, 82.00,
         110.00],

    15: [1.10, 1.88, 3.30, 6.20, 11.00, 19.50, 34.00, 55.00, 85.00, 120.00],

    16: [1.10, 2.00, 3.80, 7.60, 14.50, 27.00, 48.00, 80.00, 120.00],

    17: [1.10, 2.15, 4.40, 9.50, 20.00, 40.00, 75.00, 130.00],

    18: [1.10, 2.30, 5.20, 12.50, 28.00, 60.00, 110.00],

    19: [1.10, 2.55, 6.50, 17.00, 42.00, 90.00],

    20: [1.10, 2.90, 6.50, 25.00, 70.00],

    21: [1.10, 2.40, 10.00, 20.00],

    22: [11.60, 24.00, 71.00],
    23: [18.00, 52.00],
    24: [24.75],
}

MINES_BOMB_CHANCE = {
    1:  [0.06, 0.07, 0.09, 0.10, 0.11, 0.12, 0.13, 0.14, 0.18, 0.20,
         0.25, 0.30, 0.35, 0.80, 0.90, 0.99, 0.99, 0.99, 0.99, 0.99,
         0.99, 0.99, 0.99, 1.00],

    2:  [0.07, 0.8, 0.10, 0.12, 0.13, 0.14, 0.18, 0.20, 0.25, 0.30,
         0.31, 0.32, 0.35, 0.45, 0.50, 0.70, 0.80, 0.90, 0.67, 0.80,
         0.90, 0.95, 1.00],

    3:  [0.13, 0.15, 0.19, 0.20, 0.25, 0.28, 0.35, 0.40, 0.45, 0.50,
         0.70, 0.99, 0.99, 0.67, 0.69, 0.80, 0.81, 0.90, 0.92, 0.98,
         0.99, 1.00],

    4:  [0.16, 0.18, 0.19, 0.22, 0.45, 0.55, 0.90, 0.80, 0.90, 0.42,
         0.60, 0.70, 0.80, 0.90, 0.94, 0.95, 0.96, 0.97, 0.98, 0.99,
         1.00],

    5:  [0.20, 0.22, 0.24, 0.27, 0.35, 0.50, 0.99, 0.70, 0.99, 0.67,
         0.70, 0.77, 0.80, 0.86, 0.91, 0.94, 0.96, 0.98, 0.99, 1.00],

    6:  [0.24, 0.26, 0.45, 0.55, 0.70, 0.99, 0.48, 0.55, 0.63, 0.71,
         0.78, 0.84, 0.89, 0.93, 0.95, 0.97, 0.98, 0.99, 1.00],

    7:  [0.27, 0.31, 0.40, 0.99, 0.44, 0.50, 0.57, 0.65, 0.73, 0.80,
         0.86, 0.90, 0.93, 0.95, 0.97, 0.98, 0.99, 1.00],

    8:  [0.32, 0.36, 0.99, 0.99, 0.51, 0.58, 0.66, 0.74, 0.81, 0.87,
         0.91, 0.94, 0.96, 0.97, 0.98, 0.99, 1.00],

    9:  [0.36, 0.40, 0.90, 0.99, 0.99, 0.66, 0.74, 0.81, 0.87, 0.91,
         0.94, 0.96, 0.97, 0.98, 0.99, 1.00],

    10: [0.10, 0.30, 0.99, 0.99, 0.66, 0.74, 0.81, 0.87, 0.91, 0.94,
         0.96, 0.97, 0.98, 0.99, 1.00],

    11: [0.10, 0.30, 0.99, 0.65, 0.73, 0.80, 0.86, 0.90, 0.93, 0.95,
         0.97, 0.98, 0.99, 1.00],

    12: [0.10, 0.30, 0.99, 0.71, 0.78, 0.84, 0.89, 0.93, 0.95, 0.97,
         0.98, 0.99, 1.00],

    13: [0.10, 0.60, 0.99, 0.76, 0.83, 0.88, 0.92, 0.95, 0.97, 0.98,
         0.99, 1.00],

    14: [0.10, 0.64, 0.99, 0.80, 0.86, 0.91, 0.94, 0.96, 0.97, 0.98,
         1.00],

    15: [0.60, 0.69, 0.99, 0.84, 0.89, 0.93, 0.95, 0.97, 0.98, 1.00],

    16: [0.64, 0.99, 0.81, 0.87, 0.91, 0.94, 0.96, 0.98, 1.00],

    17: [0.68, 0.99, 0.84, 0.89, 0.93, 0.95, 0.97, 1.00],

    18: [0.72, 1.00, 0.87, 0.91, 0.94, 0.96, 1.00],

    19: [0.76, 1.00, 0.89, 0.93, 0.95, 1.00],

    20: [1.00, 0.87, 0.91, 0.94, 1.00],

    21: [1.00, 0.90, 0.94, 1.00],

    22: [1.00, 0.93, 1.00],

    23: [1.00, 1.00],

    24: [0.99],
}

class MinesTileButton(discord.ui.Button):
    def __init__(self, index):
        super().__init__(
            style=discord.ButtonStyle.secondary,
            label="\u200b",
            row=index // 5,
            custom_id=f"mines_tile_{index}"
        )
        self.index = index

    async def callback(self, interaction: discord.Interaction):
        await self.view.process_click(interaction, self.index)

class MinesGameView(discord.ui.View):
    def __init__(self, owner_id, amount, num_mines):
        super().__init__(timeout=300)
        self.owner_id = owner_id
        self.amount = amount
        self.num_mines = num_mines
        self.revealed = set()
        self.game_over = False
        self.hit_bomb_index = None

        self.tile_buttons = {}
        for i in range(25):
            btn = MinesTileButton(i)
            self.tile_buttons[i] = btn
            self.add_item(btn)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("❌ This game is not yours!", ephemeral=True)
            return False
        if await game_paused(interaction):
            return False
        return True

    def get_current_multiplier(self):
        return calculate_mines_multiplier(self.num_mines, len(self.revealed))

    def get_next_multiplier(self):
        return calculate_mines_multiplier(self.num_mines, len(self.revealed) + 1)

    def get_bomb_chance(self) -> float:
        chance_list = MINES_BOMB_CHANCE.get(self.num_mines, [])
        idx = len(self.revealed)
        if idx >= len(chance_list):
            return 1.0
        return chance_list[idx]

    def build_embed(self, status="in_progress"):
        current_mult = self.get_current_multiplier()
        current_winnings = int(self.amount * current_mult)
        next_mult = self.get_next_multiplier()
        next_winnings = int(self.amount * next_mult)
        bomb_chance = self.get_bomb_chance() * 100

        if status == "cashed_out":
            title = f"{self.num_mines} Mines Cashed Out"
            colour = discord.Colour.green()
            winnings_str = f"💎 **Winnings:** {format_amount(current_winnings)}"
        elif status == "hit_bomb":
            title = f"{self.num_mines} Mines Hit a Bomb"
            colour = discord.Colour.red()
            winnings_str = "💎 **Current winnings:** 0"
        else:
            title = f"{self.num_mines} Mines"
            colour = discord.Colour.purple()
            winnings_str = f"💎 **Current winnings:** {format_amount(current_winnings)}"

        if len(self.revealed) > 0 and not self.game_over:
            cashout_instruction = "\n🟢 **Click any of your revealed diamonds to cash out!**"
        else:
            cashout_instruction = ""

        description = (
            f"**Game Stats**\n"
            f"💎 **Bet:** {format_amount(self.amount)}\n"
            f"✨ **Multiplier:** {current_mult:.2f}x\n"
            f"{winnings_str}\n"
            f"⌛ **Next click:** {format_amount(next_winnings)}\n"
            f"{cashout_instruction}\n\n"
            f"Click hidden tiles to reveal diamonds!"
        )

        embed = discord.Embed(
            title=title,
            description=description,
            colour=colour
        )
        embed.set_author(name="Aqua Gems Casino")
        embed.set_footer(text="Aqua Gems Casino")
        return embed

    async def process_click(self, interaction: discord.Interaction, index: int):
        if self.game_over:
            return

        if index in self.revealed:
            await self.cash_out(interaction)
            return

        chance = self.get_bomb_chance()
        if random.random() < chance:
            self.hit_bomb_index = index
            await self.hit_bomb(interaction, hit_index=index)
            return

        self.revealed.add(index)
        btn = self.tile_buttons[index]
        btn.style = discord.ButtonStyle.success
        btn.emoji = "💎"
        btn.label = None

        max_safe = 25 - self.num_mines
        if len(self.revealed) >= max_safe:
            await self.cash_out(interaction)
            return

        await interaction.response.edit_message(
            embed=self.build_embed(status="in_progress"),
            view=self
        )

    async def cash_out(self, interaction: discord.Interaction):
        if len(self.revealed) == 0:
            await interaction.response.send_message("❌ You must reveal at least one tile before cashing out!", ephemeral=True)
            return

        self.game_over = True
        mult = self.get_current_multiplier()
        payout = int(self.amount * mult)
        net_profit = payout - self.amount

        user = ensure_user(self.owner_id)
        user["balance"] += payout
        user["wagered"] += self.amount

        if user["to_wager"] > 0:
            user["to_wager"] = max(0, user["to_wager"] - self.amount)

        add_history(self.owner_id, f"Mines ({self.num_mines})", self.amount, "Win")

        DATA["global_stats"]["bot_game_profit"] -= net_profit
        save_data()

        await update_milestone_roles(interaction.user)

        unrevealed = [i for i in range(25) if i not in self.revealed]
        mines_left = self.num_mines
        bomb_positions = set(random.sample(unrevealed, min(mines_left, len(unrevealed)))) if unrevealed else set()

        for idx, btn in self.tile_buttons.items():
            btn.disabled = True
            if idx in self.revealed:
                btn.style = discord.ButtonStyle.success
                btn.emoji = "💎"
                btn.label = None
            elif idx in bomb_positions:
                btn.style = discord.ButtonStyle.danger
                btn.emoji = "💣"
                btn.label = None
            else:
                btn.style = discord.ButtonStyle.success
                btn.emoji = "💎"
                btn.label = None

        embed = self.build_embed(status="cashed_out")
        await interaction.response.edit_message(embed=embed, view=self)

        await send_log(
            interaction.guild,
            "💣 Mines Cashed Out",
            f"Player: {interaction.user.mention}\nAmount: **{format_amount(self.amount)}**\nMines: **{self.num_mines}**\nPayout: **{format_amount(payout)}** ({mult:.2f}x)",
            discord.Colour.green()
        )
        self.stop()

    async def hit_bomb(self, interaction: discord.Interaction, hit_index: int):
        self.game_over = True

        user = ensure_user(self.owner_id)
        user["wagered"] += self.amount

        if user["to_wager"] > 0:
            user["to_wager"] = max(0, user["to_wager"] - self.amount)

        add_history(self.owner_id, f"Mines ({self.num_mines})", self.amount, "Loss")

        DATA["global_stats"]["bot_game_profit"] += self.amount
        save_data()

        await update_milestone_roles(interaction.user)

        unrevealed = [i for i in range(25) if i not in self.revealed and i != hit_index]
        mines_left = max(0, self.num_mines - 1)
        bomb_positions = set(random.sample(unrevealed, min(mines_left, len(unrevealed)))) if unrevealed else set()

        for idx, btn in self.tile_buttons.items():
            btn.disabled = True
            if idx == hit_index:
                btn.style = discord.ButtonStyle.danger
                btn.emoji = "💥"
                btn.label = None
            elif idx in self.revealed:
                btn.style = discord.ButtonStyle.success
                btn.emoji = "💎"
                btn.label = None
            elif idx in bomb_positions:
                btn.style = discord.ButtonStyle.danger
                btn.emoji = "💣"
                btn.label = None
            else:
                btn.style = discord.ButtonStyle.success
                btn.emoji = "💎"
                btn.label = None

        embed = self.build_embed(status="hit_bomb")
        await interaction.response.edit_message(embed=embed, view=self)

        await send_log(
            interaction.guild,
            "💥 Mines Hit a Bomb",
            f"Player: {interaction.user.mention}\nAmount: **{format_amount(self.amount)}**\nMines: **{self.num_mines}**",
            discord.Colour.red()
        )
        self.stop()

def calculate_mines_multiplier(mines_count: int, revealed_count: int) -> float:
    if revealed_count <= 0:
        return 1.00

    mults = MINES_MULTIPLIERS.get(mines_count)
    if not mults:
        return 1.00

    index = revealed_count - 1
    if index >= len(mults):
        return mults[-1]
    return mults[index]

@tree.command(name="mines", description="Play Aqua Gems Casino Mines game.")
@game_cooldown()
@app_commands.describe(
    mines="Number of mines (1-24)",
    bet="Bet amount (e.g., 10m, 500m, 1b)"
)
async def mines(interaction: discord.Interaction, mines: app_commands.Range[int, 1, 24], bet: str):
    if not await verification_check(interaction) or await game_paused(interaction):
        return

    parsed = parse_amount(bet)
    if parsed is None or parsed < MIN_GAME_AMOUNT:
        await interaction.response.send_message("❌ Minimum bet amount is **10M**.", ephemeral=True)
        return

    user = ensure_user(interaction.user.id)
    if user["balance"] < parsed:
        await interaction.response.send_message("❌ Insufficient balance.", ephemeral=True)
        return

    user["balance"] -= parsed
    save_data()

    view = MinesGameView(interaction.user.id, parsed, mines)
    embed = view.build_embed(status="in_progress")

    await interaction.response.send_message(embed=embed, view=view)