(function () {
  const REDS = new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);
  // European order around the wheel
  const ORDER = [0,32,15,19,4,21,2,25,17,34,6,27,13,36,11,30,8,23,10,5,24,16,33,1,20,14,31,9,22,18,29,7,28,12,35,3,26];
  const board = document.getElementById("rouBoard");
  const outside = document.getElementById("rouOutside");
  const timerEl = document.getElementById("rouTimer");
  const chipsEl = document.getElementById("rouChips");
  const balEl = document.getElementById("rouBal");
  const selBet = document.getElementById("selBet");
  const placeBtn = document.getElementById("placeBet");
  const wheel = document.getElementById("rouWheel");
  const ball = document.getElementById("rouBall");
  const svg = document.getElementById("rouSvg");
  let selected = null;
  let lastSpinResult = null;

  function buildSvg() {
    const cx = 100, cy = 100, r = 98;
    const n = ORDER.length;
    const slice = 360 / n;
    let html = "";
    ORDER.forEach((num, i) => {
      const a0 = ((i * slice) - 90) * Math.PI / 180;
      const a1 = (((i + 1) * slice) - 90) * Math.PI / 180;
      const x0 = cx + r * Math.cos(a0);
      const y0 = cy + r * Math.sin(a0);
      const x1 = cx + r * Math.cos(a1);
      const y1 = cy + r * Math.sin(a1);
      const color = num === 0 ? "#0a5c2e" : (REDS.has(num) ? "#8b1515" : "#111");
      html += `<path d="M${cx},${cy} L${x0},${y0} A${r},${r} 0 0,1 ${x1},${y1} Z" fill="${color}" stroke="#222" stroke-width="0.4"/>`;
      const mid = ((i + 0.5) * slice - 90) * Math.PI / 180;
      const tx = cx + (r * 0.72) * Math.cos(mid);
      const ty = cy + (r * 0.72) * Math.sin(mid);
      const rot = (i + 0.5) * slice;
      html += `<text x="${tx}" y="${ty}" fill="#fff" font-size="5.5" font-weight="700" text-anchor="middle" dominant-baseline="middle" transform="rotate(${rot},${tx},${ty})">${num}</text>`;
    });
    svg.innerHTML = html;
  }
  buildSvg();

  function buildBoard() {
    board.innerHTML = "";
    const z = document.createElement("div");
    z.className = "cell green";
    z.textContent = "0";
    z.dataset.bet = "0";
    z.style.gridRow = "span 3";
    board.appendChild(z);
    for (let n = 1; n <= 36; n++) {
      const c = document.createElement("div");
      c.className = "cell " + (REDS.has(n) ? "red" : "black");
      c.textContent = n;
      c.dataset.bet = String(n);
      board.appendChild(c);
    }
    outside.innerHTML = "";
    ["red", "black", "odd", "even", "1-18", "19-36"].forEach((b) => {
      const c = document.createElement("div");
      c.className = "cell";
      c.textContent = b.toUpperCase();
      c.dataset.bet = b;
      outside.appendChild(c);
    });
    document.querySelectorAll(".cell").forEach((cell) => {
      cell.addEventListener("click", () => {
        selected = cell.dataset.bet;
        selBet.textContent = selected;
        document.querySelectorAll(".cell").forEach((x) => (x.style.outline = ""));
        cell.style.outline = "2px solid var(--gold)";
      });
    });
  }
  buildBoard();

  function angleForNumber(n) {
    const idx = ORDER.indexOf(Number(n));
    if (idx < 0) return 0;
    const slice = 360 / ORDER.length;
    // pointer at top; rotate wheel so number sits under pointer
    return -(idx * slice + slice / 2);
  }

  function spinTo(n) {
    const base = angleForNumber(n);
    const extra = 360 * 6;
    wheel.style.transform = `rotate(${extra + base}deg)`;
    // ball travels opposite then settles on number
    const ballRot = -(extra * 1.15) + 0;
    ball.style.transform = `rotate(${ballRot}deg)`;
    setTimeout(() => {
      ball.style.transition = "transform 0.8s ease-out";
      ball.style.transform = `rotate(${-(extra + base)}deg)`;
      setTimeout(() => { ball.style.transition = "transform 5s cubic-bezier(0.12, 0.7, 0.15, 1)"; }, 900);
    }, 5000);
  }

  function formatShort(n) {
    n = Number(n);
    if (n >= 1e9) return (n / 1e9).toFixed(1) + "B";
    if (n >= 1e6) return (n / 1e6).toFixed(1) + "M";
    if (n >= 1e3) return (n / 1e3).toFixed(1) + "K";
    return String(n);
  }

  function colorClass(n) {
    if (n === 0 || n === "0") return "green";
    if (REDS.has(Number(n))) return "red";
    return "black";
  }

  async function refresh() {
    try {
      const r = await fetch("/api/roulette/state");
      const j = await r.json();
      if (!j.ok) return;
      if (chipsEl) chipsEl.textContent = j.chips_fmt || "0";
      if (balEl && j.balance_fmt) balEl.textContent = j.balance_fmt;
      timerEl.textContent = j.seconds_left > 0 ? j.seconds_left + "s" : "SPINNING";
      if (j.last_number != null && j.last_number !== lastSpinResult) {
        const el = document.getElementById("rouLast");
        el.textContent = j.last_number;
        el.className = "chip " + colorClass(j.last_number);
        if (j.seconds_left === 0 || j.spinning) {
          spinTo(j.last_number);
        }
        lastSpinResult = j.last_number;
      }
      if (j.fair_hash) {
        document.getElementById("rouFair").textContent = "Fair: " + j.fair_hash.slice(0, 18) + "…";
      }
      board.querySelectorAll(".chip-stack").forEach((e) => e.remove());
      outside.querySelectorAll(".chip-stack").forEach((e) => e.remove());
      Object.entries(j.my_bets || {}).forEach(([k, v]) => {
        const cell = document.querySelector(`[data-bet="${k}"]`);
        if (cell && v > 0) {
          const s = document.createElement("span");
          s.className = "chip-stack";
          s.textContent = formatShort(v);
          cell.appendChild(s);
        }
      });
    } catch (e) {}
  }

  document.querySelectorAll("[data-buy]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const amount = Number(btn.dataset.buy);
      const r = await fetch("/api/roulette/buy_chips", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount }),
      });
      const j = await r.json();
      if (!j.ok) alert(j.error || "Failed");
      refresh();
    });
  });

  document.getElementById("sellChips")?.addEventListener("click", async () => {
    const r = await fetch("/api/roulette/sell_chips", { method: "POST" });
    const j = await r.json();
    if (!j.ok) alert(j.error || "Failed");
    else alert("Sold for " + j.credited_fmt);
    refresh();
  });

  placeBtn?.addEventListener("click", async () => {
    if (!selected) return alert("Select a number or bet first");
    const r = await fetch("/api/roulette/bet", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bet: selected, chips: 1 }),
    });
    const j = await r.json();
    if (!j.ok) alert(j.error || "Failed");
    refresh();
  });

  refresh();
  setInterval(refresh, 2000);
})();
