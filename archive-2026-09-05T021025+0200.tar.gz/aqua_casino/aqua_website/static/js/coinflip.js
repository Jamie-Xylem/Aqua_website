(function () {
  const list = document.getElementById("cfList");
  const createBtn = document.getElementById("cfCreate");
  const active = document.getElementById("cfActive");

  async function refresh() {
    try {
      const r = await fetch("/api/coinflip/list");
      const j = await r.json();
      if (!j.ok) return;
      if (!j.games.length) {
        list.innerHTML = '<p style="color:var(--muted);">No open games. Create one.</p>';
        return;
      }
      list.innerHTML = "";
      j.games.forEach((g) => {
        const d = document.createElement("div");
        d.className = "cf-game";
        d.innerHTML = `
          <div class="cf-side">
            <img src="${g.creator_headshot || "/static/img/logo.png"}" alt="" />
            <div>${escape(g.creator_name)}</div>
            <div style="color:var(--muted);font-size:0.8rem;">${g.side}</div>
          </div>
          <div style="text-align:center;">
            <div style="font-weight:800;color:var(--gold);">${g.amount_fmt}</div>
            <button class="btn btn-red join-btn" data-id="${g.id}" style="margin-top:8px;">Join (opposite)</button>
          </div>
          <div class="cf-side" style="opacity:0.4;">
            <img src="/static/img/logo.png" alt="" />
            <div>Waiting…</div>
          </div>`;
        list.appendChild(d);
      });
      list.querySelectorAll(".join-btn").forEach((btn) => {
        btn.addEventListener("click", () => join(btn.dataset.id));
      });
    } catch (e) {}
  }

  function escape(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;");
  }

  async function create() {
    const side = document.getElementById("cfSide").value;
    const amount = document.getElementById("cfAmount").value;
    const r = await fetch("/api/coinflip/create", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ side, amount }),
    });
    const j = await r.json();
    if (!j.ok) return alert(j.error || "Failed");
    refresh();
  }

  async function join(id) {
    const r = await fetch("/api/coinflip/join", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ game_id: id }),
    });
    const j = await r.json();
    if (!j.ok) return alert(j.error || "Failed");
    showResult(j);
    refresh();
  }

  function showResult(j) {
    active.style.display = "block";
    document.getElementById("cfP1img").src = j.p1_headshot || "/static/img/logo.png";
    document.getElementById("cfP2img").src = j.p2_headshot || "/static/img/logo.png";
    document.getElementById("cfP1name").textContent = j.p1_name || "P1";
    document.getElementById("cfP2name").textContent = j.p2_name || "P2";
    const coin = document.getElementById("cfCoin");
    if (coin) {
      coin.classList.remove("flipping");
      void coin.offsetWidth;
      coin.classList.add("flipping");
      coin.textContent = "?";
    }
    const resultEl = document.getElementById("cfResult");
    if (resultEl) resultEl.textContent = "Flipping…";
    // Hold animation so creator AND joiner both see it (~3.2s)
    setTimeout(function () {
      if (coin) {
        coin.classList.remove("flipping");
        coin.textContent = (j.winner_side || j.result || "?").toString().slice(0, 1).toUpperCase();
      }
      if (resultEl) {
        resultEl.innerHTML = "<strong style=\"color:var(--gold)\">Winner: " + (j.winner_name || j.winner || "—") + "</strong><br>💎 " + (j.payout_fmt || j.payout || "");
      }
      if (j.balance_fmt) {
        const bal = document.getElementById("topBalance");
        if (bal) bal.textContent = "💎 " + j.balance_fmt;
        if (window.AQUA) window.AQUA.balance = j.balance;
      }
    }, 3200);
  }

  if (createBtn) createBtn.addEventListener("click", create);
  refresh();
  setInterval(refresh, 5000);
})();
