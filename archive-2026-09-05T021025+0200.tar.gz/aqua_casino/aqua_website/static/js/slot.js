(function () {
  const cfg = window.SLOT_CONFIG;
  if (!cfg) return;
  const reelsEl = document.getElementById("reels");
  const spinBtn = document.getElementById("spinBtn");
  const betInput = document.getElementById("betInput");
  const betLabel = document.getElementById("betLabel");
  const balEl = document.getElementById("slotBal");
  const winOverlay = document.getElementById("winOverlay");
  const winBadge = document.getElementById("winBadge");
  const featureOverlay = document.getElementById("featureOverlay");
  const featureText = document.getElementById("featureText");
  const btnAuto = document.getElementById("btnAuto");
  const btnInfo = document.getElementById("btnInfo");
  const infoSheet = document.getElementById("infoSheet");
  const infoClose = document.getElementById("infoClose");

  const cols = cfg.reels || 5;
  const rows = cfg.rows || 3;
  const symbols = cfg.symbols || [];
  const SYM_H = 66;
  const base = (window.STATIC_BASE || "/static").replace(/\/$/, "");
  const symMap = {};
  symbols.forEach((s, i) => {
    symMap[s] = base + "/symbols/" + cfg.id + "/s" + i + ".svg";
  });

  const presets = ["100k","250k","500k","1m","2.5m","5m","10m","25m","50m","100m","250m","500m","1b","2.5b","5b","10b","25b","50b","100b"];
  let spinning = false;
  let autoMode = false;
  const reelInners = [];

  function makeSym(el, text, extraClass) {
    el.innerHTML = "";
    el.className = "sym" + (extraClass ? " " + extraClass : "");
    const tile = document.createElement("div");
    tile.className = "sym-tile";
    const url = symMap[text];
    if (url) {
      const img = document.createElement("img");
      img.src = url;
      img.alt = text;
      img.draggable = false;
      img.onerror = function () {
        tile.textContent = text;
        tile.style.fontSize = "1.6rem";
      };
      tile.appendChild(img);
    } else {
      tile.textContent = text;
      tile.style.fontSize = "1.6rem";
    }
    el.appendChild(tile);
  }

  // Build reels with long strip for spin illusion
  for (let c = 0; c < cols; c++) {
    const reel = document.createElement("div");
    reel.className = "reel";
    const inner = document.createElement("div");
    inner.className = "reel-inner";
    for (let i = 0; i < 48; i++) {
      const s = document.createElement("div");
      makeSym(s, symbols[Math.floor(Math.random() * symbols.length)]);
      inner.appendChild(s);
    }
    reel.appendChild(inner);
    reelsEl.appendChild(reel);
    reelInners.push(inner);
  }

  // Jackpot fake tickers
  function tickJackpots() {
    const fmt = (n) => {
      if (n >= 1e9) return (n / 1e9).toFixed(1) + "B";
      if (n >= 1e6) return (n / 1e6).toFixed(1) + "M";
      return Math.floor(n / 1e3) + "K";
    };
    const base = Date.now() % 100000;
    const el = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
    el("jMini", fmt(1e6 + base * 12));
    el("jMinor", fmt(5e6 + base * 40));
    el("jMajor", fmt(25e6 + base * 90));
  }
  tickJackpots();
  setInterval(tickJackpots, 2000);

  function parseBet(s) {
    s = String(s || "").toLowerCase().replace(/,/g, "").trim();
    const m = s.match(/^([\d.]+)\s*([kmbt])?$/);
    if (!m) return 0;
    let n = parseFloat(m[1]);
    const mult = { k: 1e3, m: 1e6, b: 1e9, t: 1e12 }[m[2]] || 1;
    return Math.floor(n * mult);
  }
  function fmt(n) {
    n = Number(n) || 0;
    if (n >= 1e12) return (n / 1e12).toFixed(2).replace(/\.?0+$/, "") + "T";
    if (n >= 1e9) return (n / 1e9).toFixed(2).replace(/\.?0+$/, "") + "B";
    if (n >= 1e6) return (n / 1e6).toFixed(2).replace(/\.?0+$/, "") + "M";
    if (n >= 1e3) return (n / 1e3).toFixed(2).replace(/\.?0+$/, "") + "K";
    return String(n);
  }
  function syncBetLabel() {
    const v = parseBet(betInput.value);
    betLabel.textContent = fmt(v) || "—";
  }
  betInput.addEventListener("input", syncBetLabel);
  syncBetLabel();

  document.getElementById("betMinus").onclick = () => {
    const v = parseBet(betInput.value);
    let idx = presets.findIndex((p) => parseBet(p) >= v);
    if (idx < 0) idx = presets.length - 1;
    idx = Math.max(0, idx - 1);
    betInput.value = presets[idx];
    syncBetLabel();
  };
  document.getElementById("betPlus").onclick = () => {
    const v = parseBet(betInput.value);
    let idx = presets.findIndex((p) => parseBet(p) > v);
    if (idx < 0) idx = presets.length - 1;
    betInput.value = presets[idx];
    syncBetLabel();
  };

  btnAuto.onclick = () => {
    autoMode = !autoMode;
    btnAuto.classList.toggle("active", autoMode);
    if (autoMode && !spinning) spin();
  };
  btnInfo.onclick = () => {
    const body = document.getElementById("paytableBody");
    let html = "<table style='width:100%;font-size:0.85rem;border-collapse:collapse'>";
    html += "<tr style='color:#ffd56a'><th></th><th>×3</th><th>×4</th><th>×5</th></tr>";
    (cfg.symbols || []).forEach((sym, i) => {
      const pt = (cfg.paytable || {})[sym] || {};
      const img = symMap[sym]
        ? "<img src='" + symMap[sym] + "' style='width:28px;height:28px;vertical-align:middle' />"
        : sym;
      html += "<tr><td style='padding:4px'>" + img + "</td><td>" + (pt["3"] || pt[3] || "—") +
        "</td><td>" + (pt["4"] || pt[4] || "—") + "</td><td>" + (pt["5"] || pt[5] || "—") + "</td></tr>";
    });
    html += "</table>";
    body.innerHTML = html;
    infoSheet.classList.add("open");
  };
  infoClose.onclick = () => infoSheet.classList.remove("open");
  infoSheet.onclick = (e) => { if (e.target === infoSheet) infoSheet.classList.remove("open"); };

  function showWin(text, ms) {
    winBadge.textContent = text;
    winOverlay.classList.add("show");
    // Particle burst for big wins
    if (String(text).indexOf("BIG") !== -1 || String(text).indexOf("FEATURE") !== -1) {
      spawnParticles();
    }
    setTimeout(() => winOverlay.classList.remove("show"), ms || 2200);
  }

  function spawnParticles() {
    const stage = document.getElementById("reelsStage");
    if (!stage) return;
    for (let i = 0; i < 18; i++) {
      const p = document.createElement("div");
      p.style.cssText = "position:absolute;width:8px;height:8px;border-radius:50%;background:#ffd56a;z-index:30;pointer-events:none;left:50%;top:50%;";
      stage.appendChild(p);
      const ang = (Math.PI * 2 * i) / 18;
      const dist = 60 + Math.random() * 100;
      const x = Math.cos(ang) * dist;
      const y = Math.sin(ang) * dist;
      p.animate([
        { transform: "translate(-50%,-50%) scale(1)", opacity: 1 },
        { transform: "translate(calc(-50% + " + x + "px), calc(-50% + " + y + "px)) scale(0)", opacity: 0 }
      ], { duration: 900 + Math.random() * 400, easing: "cubic-bezier(0.2,0.8,0.2,1)" });
      setTimeout(() => p.remove(), 1400);
    }
  }

  function countUpWin(amountFmt, label, ms) {
    winBadge.textContent = label + "\n0";
    winOverlay.classList.add("show");
    spawnParticles();
    const target = parseBet(String(amountFmt).replace(/[^\d.kmb]/gi, "")) || 0;
    // If parse fails just show final
    let steps = 20;
    let step = 0;
    const iv = setInterval(() => {
      step++;
      const v = Math.floor((target * step) / steps);
      winBadge.textContent = label + "\n" + fmt(v);
      if (step >= steps) {
        clearInterval(iv);
        winBadge.textContent = label + "\n" + amountFmt;
      }
    }, 40);
    setTimeout(() => winOverlay.classList.remove("show"), ms || 3000);
  }

  function clearWinGlow() {
    document.querySelectorAll(".sym.win-glow, .sym.scatter-land").forEach((el) => {
      el.classList.remove("win-glow", "scatter-land");
    });
    ["pl0", "pl1", "pl2"].forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.classList.remove("show");
    });
  }

  function landGrid(grid, scatter, feature) {
    // Final visible window is 3 symbols per reel at a fixed offset
    const offset = 20; // middle of strip
    for (let c = 0; c < cols; c++) {
      const inner = reelInners[c];
      const kids = inner.children;
      for (let r = 0; r < rows; r++) {
        const el = kids[offset + r];
        if (!el) continue;
        const sym = grid[c][r];
        const isScatter = scatter && sym === scatter;
        makeSym(el, sym, isScatter && feature ? "scatter-land" : "");
      }
      // snap transform to show offset..offset+rows
      inner.style.transition = "none";
      inner.style.transform = "translateY(" + (-offset * SYM_H) + "px)";
    }
  }

  async function animateSpinTo(grid, scatter, feature, winLines) {
    // EXACT original spin behaviour — do not change
    clearWinGlow();
    const offset = 20;
    const anims = [];
    for (let c = 0; c < cols; c++) {
      const inner = reelInners[c];
      const kids = inner.children;
      // Fill random symbols during spin
      for (let i = 0; i < kids.length; i++) {
        makeSym(kids[i], symbols[Math.floor(Math.random() * symbols.length)]);
      }
      // Place final result near end of strip
      for (let r = 0; r < rows; r++) {
        makeSym(kids[offset + r], grid[c][r]);
      }
      // Start from top (fast spin look)
      inner.style.transition = "none";
      inner.style.transform = "translateY(0px)";
      void inner.offsetWidth;
      // Stagger stop (left → right)
      const dur = 1.1 + c * 0.28;
      const targetY = -offset * SYM_H;
      inner.style.transition = "transform " + dur + "s cubic-bezier(0.15, 0.85, 0.15, 1)";
      inner.style.transform = "translateY(" + targetY + "px)";
      anims.push(
        new Promise((res) => {
          setTimeout(() => {
            // Scatter pop on land
            if (feature && scatter) {
              for (let r = 0; r < rows; r++) {
                if (grid[c][r] === scatter) {
                  const el = kids[offset + r];
                  if (el) el.classList.add("scatter-land");
                }
              }
            }
            res();
          }, dur * 1000 + 30);
        })
      );
    }
    await Promise.all(anims);

    // Highlight winning lines
    if (winLines && winLines.length) {
      winLines.forEach((row) => {
        const pl = document.getElementById("pl" + row);
        if (pl) pl.classList.add("show");
        for (let c = 0; c < cols; c++) {
          const el = reelInners[c].children[offset + row];
          if (el) el.classList.add("win-glow");
        }
      });
    }
  }


  async function animateExpandWild(col) {
    if (col == null || col < 0 || col >= cols) return;
    const offset = 20;
    const inner = reelInners[col];
    if (!inner) return;
    const kids = inner.children;
    const wildSym = cfg.wild;
    // Slide wild from top down through the visible rows
    for (let r = 0; r < rows; r++) {
      const el = kids[offset + r];
      if (!el) continue;
      // brief flash then set wild
      el.classList.add("wild-expand");
      makeSym(el, wildSym, "wild-expand");
      await new Promise((res) => setTimeout(res, 180));
    }
    // Hold glow briefly
    await new Promise((res) => setTimeout(res, 400));
    document.querySelectorAll(".sym.wild-expand").forEach((el) => el.classList.remove("wild-expand"));
  }

  async function spin() {
    if (spinning) return;
    if (!window.AQUA || !window.AQUA.verified) {
      alert("Login & verify first");
      return;
    }
    const bet = parseBet(betInput.value);
    if (!bet) {
      alert("Invalid bet");
      return;
    }
    spinning = true;
    spinBtn.disabled = true;
    spinBtn.classList.add("holding");
    clearWinGlow();
    winOverlay.classList.remove("show");
    featureOverlay.classList.remove("show");

    try {
      const r = await fetch("/api/slots/spin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slot_id: cfg.id, bet: String(bet) }),
      });
      const j = await r.json();
      if (!j.ok) {
        alert(j.error || "Spin failed");
        spinning = false;
        spinBtn.disabled = false;
        spinBtn.classList.remove("holding");
        autoMode = false;
        btnAuto.classList.remove("active");
        return;
      }

      // Detect which rows won for highlight (client-side approximate)
      const winLines = [];
      if (j.win > 0) {
        for (let row = 0; row < rows; row++) {
          const line = [];
          for (let c = 0; c < cols; c++) line.push(j.grid[c][row]);
          const first = line[0];
          let streak = 1;
          for (let i = 1; i < cols; i++) {
            if (line[i] === first || line[i] === cfg.wild) streak++;
            else break;
          }
          if (streak >= 3) winLines.push(row);
        }
      }

      await animateSpinTo(j.grid, cfg.scatter, j.feature, winLines);

      if (balEl && j.balance_fmt) balEl.textContent = j.balance_fmt;
      if (window.AQUA) window.AQUA.balance = j.balance;
      const topBal = document.getElementById("topBalance");
      if (topBal && j.balance_fmt) topBal.textContent = j.balance_fmt;

      if (j.feature) {
        // Full feature name from config when possible
        const featName = (cfg.feature || j.feature || "FEATURE").toString();
        featureText.textContent = featName;
        featureOverlay.classList.add("show");
        document.querySelectorAll(".sym.scatter-land").forEach(function(el) {
          el.classList.add("win-glow");
        });
        // Longer cinematic hold so logo + feature text land
        await new Promise((r) => setTimeout(r, 1800));
        featureOverlay.classList.remove("show");
        // Expanding wilds: slide wild down the chosen reel
        if (j.expand_col != null && cfg.feature && String(cfg.feature).toLowerCase().indexOf("expand") !== -1) {
          await animateExpandWild(j.expand_col);
        }
        // Other feature types: pulse all reels
        else if (j.feature) {
          document.querySelectorAll(".reel").forEach(function(reel) {
            reel.classList.add("feature-pulse");
            setTimeout(function() { reel.classList.remove("feature-pulse"); }, 650);
          });
          await new Promise((r) => setTimeout(r, 550));
        }
        countUpWin(j.win_fmt, "FEATURE!\n" + featName, 3400);
      } else if (j.win > 0) {
        if (j.win >= j.bet * 15) countUpWin(j.win_fmt, "BIG WIN", 3200);
        else if (j.win >= j.bet * 5) showWin("NICE WIN\n" + j.win_fmt, 2400);
        else showWin("+" + j.win_fmt, 1600);
      }
    } catch (e) {
      alert("Network error");
      autoMode = false;
      btnAuto.classList.remove("active");
    }

    spinning = false;
    spinBtn.disabled = false;
    spinBtn.classList.remove("holding");
    if (autoMode) setTimeout(spin, 600);
  }

  spinBtn.addEventListener("click", spin);
  // Long-press auto
  let holdTimer;
  spinBtn.addEventListener("mousedown", () => {
    holdTimer = setTimeout(() => {
      autoMode = true;
      btnAuto.classList.add("active");
      if (!spinning) spin();
    }, 650);
  });
  spinBtn.addEventListener("mouseup", () => clearTimeout(holdTimer));
  spinBtn.addEventListener("mouseleave", () => clearTimeout(holdTimer));
  spinBtn.addEventListener("touchstart", () => {
    holdTimer = setTimeout(() => {
      autoMode = true;
      btnAuto.classList.add("active");
      if (!spinning) spin();
    }, 650);
  }, { passive: true });
  spinBtn.addEventListener("touchend", () => clearTimeout(holdTimer));
})();
