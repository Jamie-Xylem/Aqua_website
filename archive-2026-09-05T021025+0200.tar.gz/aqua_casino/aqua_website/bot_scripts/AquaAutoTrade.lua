--[[
  Aqua Gems — Auto Trade Bot (aggressive accept + credit)
  Bot: beingbraindedisfun12

  Deposits: trade only → credit site → Accept + Confirm
  Withdraws: poll every 60s → Accept when that user trades
]]

local CONFIG = {
    API_BASE = "https://aqua-gems.com",
    BOT_KEY = "Meth6918",
    BOT_USERNAME = "beingbraindedisfun12",
    SCAN_INTERVAL = 0.45,
    WITHDRAW_POLL_SEC = 60,
    ACCEPT_RETRIES = 16,
    API_RETRY_SEC = 12,
    DEBUG_UI = true,
}

local Players = game:GetService("Players")
local LP = Players.LocalPlayer
local HttpService = game:GetService("HttpService")
local RS = game:GetService("ReplicatedStorage")
local VIM = game:GetService("VirtualInputManager")
local CoreGui = game:GetService("CoreGui")

-- =========================================================
-- UI panel (Includes anti-cheat bypass using gethui/protectgui)
-- =========================================================
local function parentGui(g)
    if gethui then
        g.Parent = gethui()
        return
    end

    if syn and syn.protect_gui then
        pcall(function() syn.protect_gui(g) end)
    elseif protectgui then
        pcall(function() protectgui(g) end)
    end

    local ok = pcall(function() g.Parent = CoreGui end)
    if not ok or not g.Parent then
        pcall(function() g.Parent = LP:WaitForChild("PlayerGui", 5) end)
    end
end

local gui = Instance.new("ScreenGui")
gui.Name = "AquaBotDiag"
gui.ResetOnSpawn = false
gui.DisplayOrder = 99999
gui.IgnoreGuiInset = true
parentGui(gui)

local frame = Instance.new("Frame")
frame.Size = UDim2.new(0, 380, 0, 300)
frame.Position = UDim2.new(0, 10, 0.28, 0)
frame.BackgroundColor3 = Color3.fromRGB(8, 12, 24)
frame.BackgroundTransparency = 0.04
frame.BorderSizePixel = 0
frame.Active = true
frame.Draggable = true
frame.Parent = gui
Instance.new("UICorner", frame).CornerRadius = UDim.new(0, 14)
local stroke = Instance.new("UIStroke", frame)
stroke.Color = Color3.fromRGB(91, 140, 255)
stroke.Thickness = 2

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, -50, 0, 28)
title.Position = UDim2.new(0, 12, 0, 8)
title.BackgroundTransparency = 1
title.Text = "AQUA BOT · " .. CONFIG.BOT_USERNAME
title.Font = Enum.Font.GothamBold
title.TextSize = 16
title.TextColor3 = Color3.fromRGB(91, 140, 255)
title.TextXAlignment = Enum.TextXAlignment.Left
title.Parent = frame

local pulse = Instance.new("Frame")
pulse.Size = UDim2.new(0, 14, 0, 14)
pulse.Position = UDim2.new(1, -28, 0, 14)
pulse.BackgroundColor3 = Color3.fromRGB(60, 255, 140)
pulse.BorderSizePixel = 0
pulse.Parent = frame
Instance.new("UICorner", pulse).CornerRadius = UDim.new(1, 0)

local body = Instance.new("TextLabel")
body.Size = UDim2.new(1, -20, 1, -48)
body.Position = UDim2.new(0, 10, 0, 40)
body.BackgroundTransparency = 1
body.Text = "Booting…"
body.Font = Enum.Font.Code
body.TextSize = 12
body.TextColor3 = Color3.fromRGB(220, 230, 245)
body.TextXAlignment = Enum.TextXAlignment.Left
body.TextYAlignment = Enum.TextYAlignment.Top
body.TextWrapped = true
body.Parent = frame

local logLines = {}
local function ui(msg)
    table.insert(logLines, os.date("%H:%M:%S") .. " " .. tostring(msg))
    while #logLines > 16 do table.remove(logLines, 1) end
    body.Text = table.concat(logLines, "\n")
end

task.spawn(function()
    local on = true
    while gui.Parent do
        pulse.BackgroundColor3 = on and Color3.fromRGB(60, 255, 140) or Color3.fromRGB(20, 40, 30)
        on = not on
        task.wait(0.5)
    end
end)

ui("Script loaded · " .. (LP and LP.Name or "?"))
ui("Target: " .. CONFIG.BOT_USERNAME)

-- =========================================================
-- HTTP
-- =========================================================
local function rawRequest(opts)
    local fns = {
        function() return request(opts) end,
        function() return http_request(opts) end,
        function() return syn and syn.request and syn.request(opts) end,
        function() return fluxus and fluxus.request and fluxus.request(opts) end,
        function() return http and http.request and http.request(opts) end,
        function() return (getgenv and getgenv().request) and getgenv().request(opts) end,
    }
    for _, fn in ipairs(fns) do
        local ok, res = pcall(fn)
        if ok and res and (res.Body or res.body) then
            return {
                StatusCode = res.StatusCode or res.Status or res.status_code,
                Body = res.Body or res.body,
            }
        end
    end
    return nil
end

local function http(method, path, bodyTable)
    local url = CONFIG.API_BASE .. path
    local opts = {
        Url = url,
        Method = method,
        Headers = {
            ["X-Bot-Key"] = CONFIG.BOT_KEY,
            ["Content-Type"] = "application/json",
        },
    }
    if bodyTable then
        opts.Body = HttpService:JSONEncode(bodyTable)
    end
    local res = rawRequest(opts)
    if not res then
        ui("HTTP FAIL — no request fn")
        return nil
    end
    local code = tonumber(res.StatusCode) or 0
    local ok, data = pcall(function()
        return HttpService:JSONDecode(res.Body)
    end)
    if not ok then
        ui("Bad JSON " .. tostring(code) .. ": " .. string.sub(tostring(res.Body), 1, 40))
        return nil
    end
    if code == 401 then
        ui("401 — BOT_KEY mismatch")
    end
    return data
end

-- =========================================================
-- Whitelist
-- =========================================================
ui("API: " .. CONFIG.API_BASE)
local WHITELIST = {}
local API_OK = false

local function loadWhitelist()
    local wl = http("GET", "/api/bot/pet_whitelist")
    if wl and wl.ok and wl.names then
        WHITELIST = {}
        for _, n in ipairs(wl.names) do WHITELIST[n:lower()] = true end
        API_OK = true
        ui("API OK · " .. #wl.names .. " pets")
        return true
    end
    return false
end

if not loadWhitelist() then
    ui("API down — retrying…")
    task.spawn(function()
        while not API_OK do
            task.wait(CONFIG.API_RETRY_SEC)
            if loadWhitelist() then break end
            ui("API still down…")
        end
    end)
end

local function isAllowed(name)
    local n = (name or ""):lower()
    if not (n:find("huge") or n:find("titanic")) then return false end
    if next(WHITELIST) == nil then return true end
    return WHITELIST[n] == true
end

local function isJunk(low)
    if low:find("chance for") then return true end
    if low:find("chance of") then return true end
    if low:find("%*") then return true end
    if low:find("hatch") then return true end
    if low:find("egg #") or low:find("egg#") or low:find("from egg") then return true end
    if low:find("rotation") or low:find("next huge") then return true end
    if low:find("breakable") or low:find("best area") then return true end
    if low:find("accept") or low:find("decline") or low:find("cancel") or low:find("confirm") then return true end
    if low:find("ready") or low:find("reward") or low:find("league") then return true end
    if low:find("inventory") or low:find("equip") or low:find("unequip") then return true end
    if low:find("|") then return true end
    if low:find("%%") then return true end
    if low:find("lucky") or low:find("breakout") then return true end
    if #low > 40 then return true end
    if not (low:match("^huge%s+%w") or low:match("^titanic%s+%w")) then
        return true
    end
    return false
end

-- =========================================================
-- Helper to extract text from ImageButtons with child TextLabels
-- =========================================================
local function getButtonText(d)
    local labelText = d:IsA("TextButton") and (d.Text or "") or ""
    if labelText == "" then
        pcall(function()
            for _, child in ipairs(d:GetDescendants()) do
                if child:IsA("TextLabel") and child.Text and child.Text ~= "" then
                    labelText = child.Text
                    break
                end
            end
        end)
    end
    return labelText
end

local function clickBtn(btn)
    if not btn then return end
    pcall(function()
        if getconnections then
            for _, sig in ipairs({ "MouseButton1Click", "Activated", "MouseButton1Down" }) do
                local ok, cons = pcall(function() return getconnections(btn[sig]) end)
                if ok and cons then
                    for _, c in ipairs(cons) do pcall(function() c:Fire() end) end
                end
            end
        end
    end)
    pcall(function()
        if firesignal then
            pcall(function() firesignal(btn.MouseButton1Click) end)
            pcall(function() firesignal(btn.Activated) end)
        end
    end)
    pcall(function()
        local p, s = btn.AbsolutePosition, btn.AbsoluteSize
        if s and s.X > 2 and s.Y > 2 then
            VIM:SendMouseButtonEvent(p.X + s.X / 2, p.Y + s.Y / 2, 0, true, game, 0)
            task.wait(0.04)
            VIM:SendMouseButtonEvent(p.X + s.X / 2, p.Y + s.Y / 2, 0, false, game, 0)
        end
    end)
end

local function allGuiRoots()
    local roots = {}
    if gethui then
        pcall(function() table.insert(roots, gethui()) end)
    end
    if CoreGui then
        pcall(function() table.insert(roots, CoreGui) end)
    end
    if LP and LP:FindFirstChild("PlayerGui") then
        pcall(function() table.insert(roots, LP.PlayerGui) end)
    end
    return roots
end

-- =========================================================
-- PS99 trade remotes & metatable interception
-- Network: "Server: Trading: Set Ready" / Set Confirmed / Decline
-- =========================================================
local Network = nil
pcall(function()
    Network = RS:FindFirstChild("Network") or RS:WaitForChild("Network", 5)
end)

local currentTradeId = nil

pcall(function()
    local mt = getrawmetatable(game)
    local oldNamecall = mt.__namecall
    setreadonly(mt, false)
    mt.__namecall = newcclosure(function(self, ...)
        local method = getnamecallmethod()
        if method == "FireServer" or method == "InvokeServer" then
            local args = {...}
            local cmd = args[1]
            if type(cmd) == "string" and cmd:find("Trading") then
                if type(args[2]) == "number" then
                    currentTradeId = args[2]
                end
            end
        end
        return oldNamecall(self, ...)
    end)
    setreadonly(mt, true)
end)

local function firePS99Remote(cmd, ...)
    pcall(function()
        local net = Network or RS:FindFirstChild("Network")
        if net then
            local func = net:FindFirstChild("Invoke") or net:FindFirstChild("Fire")
            if func then
                if func:IsA("RemoteFunction") then
                    func:InvokeServer(cmd, ...)
                else
                    func:FireServer(cmd, ...)
                end
            end
        end
    end)
end

local function findTradingRemote(suffix)
    if not Network then
        pcall(function() Network = RS:FindFirstChild("Network") end)
    end
    local roots = { Network, RS }
    for _, root in ipairs(roots) do
        if root then
            local want = "Server: Trading: " .. suffix
            local r = root:FindFirstChild(want, true)
            if r then return r end
            for _, c in ipairs(root:GetDescendants()) do
                if c:IsA("RemoteEvent") or c:IsA("RemoteFunction") then
                    local n = c.Name
                    if n:find("Trading") and n:lower():find(suffix:lower()) then
                        return c
                    end
                    if n:lower():find("trad") and n:lower():find(suffix:lower()) then
                        return c
                    end
                end
            end
        end
    end
    return nil
end

local function getTradeId()
    if currentTradeId then return currentTradeId end
    pcall(function()
        local TradingCmds = require(RS.Library.Client.TradingCmds)
        if TradingCmds then
            if TradingCmds.GetTradeId then
                currentTradeId = TradingCmds.GetTradeId()
            elseif TradingCmds.GetState then
                local st = TradingCmds.GetState()
                if type(st) == "table" and st.Id then currentTradeId = st.Id end
                if type(st) == "table" and st.id then currentTradeId = st.id end
            end
        end
    end)
    return currentTradeId
end

local function doReady()
    pcall(function()
        local TradingCmds = require(RS.Library.Client.TradingCmds)
        if TradingCmds then
            if TradingCmds.SetReady then TradingCmds.SetReady(true) end
            if TradingCmds.Ready then TradingCmds.Ready() end
            if TradingCmds.Confirm then TradingCmds.Confirm() end
        end
    end)

    local id = getTradeId()
    if id then
        firePS99Remote("Trading: Set Ready", id, true)
        firePS99Remote("Trading: Set Ready", id, true, 1)
    else
        firePS99Remote("Trading: Set Ready", true)
    end

    local remote = findTradingRemote("Set Ready") or findTradingRemote("Ready")
    if remote and id then
        pcall(function()
            if remote:IsA("RemoteFunction") then
                remote:InvokeServer(id, true, 1)
                remote:InvokeServer(id, true)
            else
                remote:FireServer(id, true, 1)
                remote:FireServer(id, true)
            end
        end)
        ui("Ready OK id=" .. tostring(id))
        return true
    end
    return false
end

local function doConfirm()
    local id = getTradeId()
    if id then
        firePS99Remote("Trading: Set Confirmed", id, true)
    else
        firePS99Remote("Trading: Set Confirmed", true)
    end

    local remote = findTradingRemote("Set Confirmed") or findTradingRemote("Confirm")
    if remote and id then
        pcall(function()
            if remote:IsA("RemoteFunction") then
                remote:InvokeServer(id, true)
            else
                remote:FireServer(id, true)
            end
        end)
        ui("Confirm OK")
        return true
    end
    return false
end

local function tryDecline()
    local id = getTradeId()
    if id then
        firePS99Remote("Trading: Decline", id)
    else
        firePS99Remote("Trading: Decline")
    end

    local remote = findTradingRemote("Decline")
    if remote then
        pcall(function()
            if id then
                if remote:IsA("RemoteFunction") then remote:InvokeServer(id) else remote:FireServer(id) end
            else
                if remote:IsA("RemoteFunction") then remote:InvokeServer() else remote:FireServer() end
            end
        end)
    end

    for _, root in ipairs(allGuiRoots()) do
        pcall(function()
            for _, d in ipairs(root:GetDescendants()) do
                if (d:IsA("TextButton") or d:IsA("ImageButton")) and d.Visible then
                    local t = (getButtonText(d) .. " " .. d.Name):lower()
                    if t:find("decline") or t:find("cancel") then
                        clickBtn(d)
                    end
                end
            end
        end)
    end
end

local function clickReadyButtons()
    for _, root in ipairs(allGuiRoots()) do
        pcall(function()
            for _, d in ipairs(root:GetDescendants()) do
                if (d:IsA("TextButton") or d:IsA("ImageButton")) and d.Visible and d.AbsoluteSize.X > 8 then
                    local txt = getButtonText(d)
                    local t = (txt .. " " .. d.Name):lower()
                    if t:find("ready") or t:find("accept") or t:find("confirm") then
                        if not (t:find("decline") or t:find("cancel")) then
                            clickBtn(d)
                        end
                    end
                end
            end
        end)
    end
end

local function forceAcceptBurst()
    ui(">>> READY + CONFIRM")
    for _ = 1, CONFIG.ACCEPT_RETRIES do
        doReady()
        clickReadyButtons()
        task.wait(0.08)
    end
    task.wait(0.15)
    for _ = 1, 10 do
        doConfirm()
        doReady()
        clickReadyButtons()
        task.wait(0.1)
    end
    ui("Ready/Confirm burst done")
end

-- =========================================================
-- Detect trade window open
-- =========================================================

local function hasReadyButton()
    for _, root in ipairs(allGuiRoots()) do
        local found = false
        pcall(function()
            for _, d in ipairs(root:GetDescendants()) do
                if (d:IsA("TextButton") or d:IsA("ImageButton")) and d.Visible then
                    local t = getButtonText(d)
                    if t == "Ready!" or t == "Ready" or t == "Confirm" or t == "Confirmed!" or t:lower():find("ready") then
                        found = true
                        break
                    end
                end
            end
        end)
        if found then return true end
    end
    return false
end

local function tradeWindowOpen()
    local score = 0
    local hints = {}
    for _, root in ipairs(allGuiRoots()) do
        pcall(function()
            for _, d in ipairs(root:GetDescendants()) do
                if d:IsA("TextLabel") or d:IsA("TextButton") or d:IsA("ImageButton") then
                    local tx = (getButtonText(d) .. " " .. (d:IsA("TextLabel") and d.Text or "") .. " " .. d.Name):lower()
                    if tx:find("your offer") or tx:find("their offer") then
                        score = score + 4
                        table.insert(hints, "offer")
                    end
                    if tx:find("trade value") then
                        score = score + 3
                        table.insert(hints, "trade-value")
                    end
                    if tx:find("confirmed") or tx:find("unconfirm") then
                        score = score + 4
                        table.insert(hints, "confirmed")
                    end
                    if tx:find("ready") then
                        score = score + 3
                        table.insert(hints, "ready-btn")
                    end
                    if tx:find("cancel") and d.Visible then
                        score = score + 2
                        table.insert(hints, "cancel-btn")
                    end
                    if tx:find("trading with") or tx:find("trade with") then
                        score = score + 3
                        table.insert(hints, "trading-with")
                    end
                    if tx:find("seconds left") then
                        score = score + 5
                        table.insert(hints, "countdown")
                    end
                end
                if d:IsA("Frame") or d:IsA("ScreenGui") then
                    local n = d.Name:lower()
                    if (n:find("trade") or n:find("trading")) and not n:find("trademark") and not n:find("travel") then
                        score = score + 1
                        table.insert(hints, "frame:" .. d.Name:sub(1, 20))
                    end
                end
            end
        end)
    end
    return score >= 4, score, hints
end

local function getOtherPlayer()
    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= LP then
            return plr.Name
        end
    end
    return "unknown"
end

local function scanPetNames()
    local pets, seen = {}, {}
    for _, root in ipairs(allGuiRoots()) do
        pcall(function()
            for _, d in ipairs(root:GetDescendants()) do
                if d:IsA("TextLabel") or d:IsA("TextButton") then
                    local txt = (d.Text or ""):match("^%s*(.-)%s*$") or ""
                    local low = txt:lower()
                    if not isJunk(low) and not seen[low] then
                        seen[low] = true
                        table.insert(pets, txt)
                    end
                end
            end
        end)
    end
    if #pets > 8 then
        return {}
    end
    return pets
end

local function hoverScanTradePets()
    local pets, seen = {}, {}
    local slots = {}
    for _, root in ipairs(allGuiRoots()) do
        pcall(function()
            for _, d in ipairs(root:GetDescendants()) do
                if d.Visible and (d:IsA("ImageButton") or d:IsA("ImageLabel") or d:IsA("TextButton") or d:IsA("Frame")) then
                    local sz = d.AbsoluteSize
                    if sz.X >= 30 and sz.X <= 100 and sz.Y >= 30 and sz.Y <= 100 then
                        local n = (d.Name or ""):lower()
                        local txt = getButtonText(d):lower()
                        local isPlaceholder = txt:find("%?")
                        local nameHint = n:find("pet") or n:find("item") or n:find("slot") or n:find("offer") or n:find("icon")
                        local childQ = false
                        for _, ch in ipairs(d:GetChildren()) do
                            if ch:IsA("TextLabel") and (ch.Text or ""):find("%?") then
                                childQ = true
                            end
                        end
                        if isPlaceholder or nameHint or childQ then
                            table.insert(slots, d)
                        end
                    end
                end
            end
        end)
    end
    local maxSlots = math.min(#slots, 10)
    if maxSlots > 0 then
        ui("Hover-scanning " .. maxSlots .. " slots…")
    end
    for i = 1, maxSlots do
        local d = slots[i]
        pcall(function()
            local pos, sz = d.AbsolutePosition, d.AbsoluteSize
            local cx, cy = pos.X + sz.X/2, pos.Y + sz.Y/2
            VIM:SendMouseMoveEvent(cx, cy, game)
            task.wait(0.2)
            for _, root in ipairs(allGuiRoots()) do
                for _, lab in ipairs(root:GetDescendants()) do
                    if lab:IsA("TextLabel") or lab:IsA("TextButton") then
                        local tt = (lab.Text or ""):match("^%s*(.-)%s*$") or ""
                        local low = tt:lower()
                        if #tt > 4 and (low:match("^huge%s+%w") or low:match("^titanic%s+%w")) then
                            if not seen[low] and not isJunk(low) then
                                seen[low] = true
                                table.insert(pets, tt)
                            end
                        end
                    end
                end
            end
        end)
    end
    return pets
end

-- =========================================================
-- Main deposit logic
-- =========================================================
local lastHash, cool, lastDebug = "", 0, 0
local creditedHashes = {}

local function doDeposit(pets, other)
    local key = table.concat(pets, "|") .. "|" .. other
    if creditedHashes[key] then
        ui("Already credited this trade")
        forceAcceptBurst()
        return
    end

    ui("CREDIT → " .. other)
    local res = http("POST", "/api/bot/deposit", {
        roblox_user = other,
        pets = pets,
        bot = CONFIG.BOT_USERNAME,
    })

    if res and res.ok then
        creditedHashes[key] = true
        ui("CREDITED " .. tostring(res.credit_fmt or res.credit))
    else
        local err = tostring(res and res.error or "api fail")
        ui("CREDIT FAIL: " .. err:sub(1, 55))
        local anyOk = false
        for _, p in ipairs(pets) do
            if isAllowed(p) then anyOk = true break end
        end
        if not anyOk then
            ui("Pets not allowed → decline")
            tryDecline()
            return
        end
        ui("Accepting anyway (local OK)")
    end

    forceAcceptBurst()
    ui("DONE trade w/ " .. other)
end

local function scanTrade()
    if tick() < cool then return end

    local open, score, hints = tradeWindowOpen()
    if hasReadyButton() then
        open = true
        score = math.max(score, 10)
        table.insert(hints, "ready-btn-visible")
    end
    local pets = scanPetNames()
    if open and #pets == 0 then
        local hovered = hoverScanTradePets()
        if #hovered > 0 then
            pets = hovered
            ui("Hover found: " .. table.concat(hovered, ", "):sub(1, 40))
        end
    end

    if CONFIG.DEBUG_UI and tick() - lastDebug > 4 then
        if open or #pets > 0 then
            ui("DBG tradeScore=" .. score .. " pets=" .. #pets)
            if #hints > 0 then
                ui("DBG " .. table.concat(hints, ","):sub(1, 40))
            end
            if #pets > 0 then
                ui("DBG pets: " .. table.concat(pets, ", "):sub(1, 40))
            end
            lastDebug = tick()
        end
    end

    if #pets > 0 then
        local hash = table.concat(pets, "|")
        if hash == lastHash then
            forceAcceptBurst()
            return
        end

        ui("TRADE PETS: " .. hash:sub(1, 45))
        local allOk = true
        for _, p in ipairs(pets) do
            if not isAllowed(p) then
                ui("Refuse (not in DB): " .. p:sub(1, 28))
                tryDecline()
                lastHash = hash
                cool = tick() + 8
                allOk = false
                break
            end
        end
        if not allOk then return end

        local other = getOtherPlayer()
        ui("Trader: " .. other)
        doDeposit(pets, other)
        lastHash = hash
        cool = tick() + 5
        return
    end

    if open then
        if CONFIG.DEBUG_UI and tick() - lastDebug > 2.5 then
            ui("TRADE UI open score=" .. score)
            if #hints > 0 then ui("hints: " .. table.concat(hints, ","):sub(1, 45)) end
            lastDebug = tick()
        end
        forceAcceptBurst()
        local hasCountdown = false
        for _, h in ipairs(hints) do
            if h == "countdown" or h == "confirmed" then hasCountdown = true end
        end
        if hasCountdown and #pets == 0 then
            ui("Trade finishing but no pet names parsed — check UI text")
        end
    end
end

-- =========================================================
-- Withdraws
-- =========================================================
local pendingWithdraws = {}

local function pollWithdraws()
    local res = http("GET", "/api/bot/pending_withdraws")
    if not (res and res.ok and res.withdraws) then
        return
    end
    pendingWithdraws = res.withdraws
    if #pendingWithdraws > 0 then
        ui("Pending WDs: " .. #pendingWithdraws)
        for _, w in ipairs(pendingWithdraws) do
            ui("  → " .. tostring(w.roblox_user) .. " " .. tostring(w.amount_fmt or w.amount))
        end
    end
end

local function markWithdrawDone(wid)
    local res = http("POST", "/api/bot/withdraw_claimed", { id = wid })
    if res and res.ok then
        ui("WD claimed " .. tostring(wid):sub(1, 10))
    end
end

local function handleWithdrawTrade()
    if #pendingWithdraws == 0 then return end
    local others = {}
    for _, plr in ipairs(Players:GetPlayers()) do
        if plr ~= LP then
            others[plr.Name:lower()] = plr.Name
        end
    end
    for _, w in ipairs(pendingWithdraws) do
        local target = (w.roblox_user or ""):lower()
        if target ~= "" and others[target] then
            local open = tradeWindowOpen()
            if open then
                ui("WD trade with " .. others[target])
                forceAcceptBurst()
                markWithdrawDone(w.id)
                task.wait(0.8)
            end
        end
    end
end

-- =========================================================
-- Button Clicker Loop
-- =========================================================
local lastReadyClick = 0
local function clickAllReadyButtons()
    local clicked = 0
    for _, root in ipairs(allGuiRoots()) do
        pcall(function()
            for _, d in ipairs(root:GetDescendants()) do
                if (d:IsA("TextButton") or d:IsA("ImageButton")) and d.Visible then
                    local labelText = getButtonText(d)
                    local low = (labelText .. " " .. d.Name):lower()

                    if labelText == "Ready!" or labelText == "Ready" or low:find("ready!") or low:find("ready") then
                        if not (low:find("decline") or low:find("cancel")) then
                            clickBtn(d)
                            clicked = clicked + 1
                        end
                    elseif (low:find("confirm") or labelText == "Confirm") and not low:find("unconfirm") then
                        clickBtn(d)
                        clicked = clicked + 1
                    end
                end
            end
        end)
    end
    return clicked
end

task.spawn(function()
    while gui.Parent do
        local n = 0
        pcall(function() n = clickAllReadyButtons() end)
        if n > 0 and tick() - lastReadyClick > 1.2 then
            ui("Clicked Ready/Confirm x" .. n)
            lastReadyClick = tick()
            pcall(doReady)
            pcall(doConfirm)
        end
        task.wait(0.25)
    end
end)

-- =========================================================
-- Loops
-- =========================================================
task.spawn(function()
    while gui.Parent do
        pcall(scanTrade)
        pcall(handleWithdrawTrade)
        task.wait(CONFIG.SCAN_INTERVAL)
    end
end)

task.spawn(function()
    pollWithdraws()
    while gui.Parent do
        task.wait(CONFIG.WITHDRAW_POLL_SEC)
        pcall(pollWithdraws)
    end
end)

task.spawn(function()
    local n = 0
    while gui.Parent do
        task.wait(8)
        n = n + 1
        if n % 3 == 0 then
            ui("Alive · scanning… " .. n)
        end
    end
end)

ui("Ready · trade only · WD 60s")
ui("Open a REAL trade with a Huge/Titanic")
ui("Watch for TRADE PETS / CREDITED")
