# Aqua Gems — Auto Trade Bot

Bot Roblox user: **beingbraindedisfun12**

API key is **hardcoded** (env is not used):
- Server + Lua: `Meth6918`
- Header: `X-Bot-Key: Meth6918`

## Lua script
`AquaAutoTrade.lua` — run on the bot account in PS99 via executor.

### Behaviour
- **Deposits: trade only** (no mail)
- **Withdraws: trade only** (no mailbox)
- Scans open trade UI ~every 0.8s
- Polls `/api/bot/pending_withdraws` **every 60 seconds**
- Accepts deposit trades when all offered pets are Huge/Titanic in the whitelist
- Runs deposit scan + withdraw handling **at the same time**
- Multiple Accept retries so trades complete when the right items are added

### API
- `GET  /api/bot/pet_whitelist`  (X-Bot-Key)
- `GET  /api/bot/pets`
- `POST /api/bot/deposit`  `{ roblox_user, pets: ["Titanic Cat", ...] }`
- `GET  /api/bot/pending_withdraws`
- `POST /api/bot/withdraw_claimed` `{ id }`

### Pet DB
`static/data/pets_db.json` — Huge/Titanic only with RAP + image.

