# Aqua Gems — Full Website

Flask backend + all templates + static assets.

## Features
- Discord OAuth + Roblox bio verification
- Coinflip, Roulette, Blackjack, Wheel, Lottery, Slots (10 machines)
- Deposit / Withdraw (in-game trade with bot `beingbraindedisfun12`)
- Shop, Rakeback, Profile, Live chat
- Admin panel with **Auto Deposits & Withdrawals** toggle
  - ON → auto section visible
  - OFF → section hidden, forces manual Accept/Deny
- Lottery: **50M per ticket**, pot increases by ticket amount, **draws every hour**

## Run
```bash
cd aqua_website
pip install -r requirements.txt
# set env vars (DISCORD_CLIENT_SECRET, etc.) or edit config.py
python main.py
```

Default port: 25632

## Important files
- `main.py` — all routes + game logic
- `config.py` — secrets / bot username
- `data_store.py` — shared casino_data.json helpers
- `templates/` — all HTML (cleaned, no numbered filenames)
- `static/` — CSS, JS, slot symbols, logo

## Lottery rules (updated)
- Ticket price: **50,000,000**
- Every purchase adds the full amount to the pot
- Automatic draw once per hour if ≥1 ticket exists
- Winner takes entire pot

