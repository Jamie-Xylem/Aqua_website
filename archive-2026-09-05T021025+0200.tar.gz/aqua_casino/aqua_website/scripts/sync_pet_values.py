#!/usr/bin/env python3
"""
Sync EVERY Huge + Titanic from official BIG Games APIs.
Uses:
  - /api/collection/Pets  → complete list of every Huge & Titanic that exists
  - /api/rap              → live RAP values

Crontab (hourly):
  0 * * * * cd /path/to/aqua_website && python3 scripts/sync_pet_values.py
"""
from __future__ import annotations
import json, re, time, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = ROOT / "static" / "data" / "pets_db.json"
WL_PATH = ROOT / "static" / "data" / "pet_whitelist.json"

def fetch(url: str):
    req = urllib.request.Request(url, headers={"User-Agent": "AquaGemsBot/1.0"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.loads(r.read().decode())

def asset_url(thumb: str) -> str:
    if not thumb:
        return ""
    if str(thumb).startswith("http"):
        return thumb
    m = re.search(r"(\d{6,})", str(thumb))
    if m:
        return f"https://www.roblox.com/asset-thumbnail/image?assetId={m.group(1)}&width=420&height=420&format=png"
    return ""

def main():
    rap_data = fetch("https://biggamesapi.io/api/rap")
    pet_raps = {}
    for it in rap_data.get("data") or []:
        if it.get("category") != "Pet":
            continue
        name = (it.get("configData") or {}).get("id") or ""
        if not name:
            continue
        low = name.lower()
        if "huge" not in low and "titanic" not in low:
            continue
        pet_raps[name] = int(it.get("value") or 0)
        pet_raps[low] = int(it.get("value") or 0)

    coll = fetch("https://biggamesapi.io/api/collection/Pets")
    by_name = {}

    for p in coll.get("data") or []:
        cfg = p.get("configData") or {}
        name = cfg.get("name") or p.get("configName") or ""
        if not name:
            continue
        cat = (p.get("category") or "").lower()
        low = name.lower()
        is_huge = cat == "huge" or cfg.get("huge") is True or bool(re.search(r"\bhuge\b", low))
        is_titanic = cat == "titanic" or cfg.get("titanic") is True or bool(re.search(r"\btitanic\b", low))
        if not (is_huge or is_titanic):
            continue
        if "gargantuan" in low and "huge" not in low and "titanic" not in low:
            continue
        tier = "titanic" if (is_titanic or "titanic" in low) else "huge"
        rap_v = pet_raps.get(name) or pet_raps.get(low) or 0
        by_name[low] = {
            "id": re.sub(r"[^a-z0-9]+", "_", low).strip("_"),
            "name": name,
            "tier": tier,
            "rap": rap_v,
            "cosmic": rap_v,
            "credit_75": int(rap_v * 0.75) if rap_v else 0,
            "image": asset_url(cfg.get("thumbnail") or cfg.get("goldenThumbnail") or ""),
            "accepted": True,
        }

    # RAP-only entries not in collection
    for name, rap_v in list(pet_raps.items()):
        if name != name.lower():  # skip lowercase dup keys
            continue
        # name here is lowercase from second write - skip
        pass
    for name, rap_v in pet_raps.items():
        if name.islower():
            continue
        low = name.lower()
        if low in by_name:
            if rap_v > by_name[low]["rap"]:
                by_name[low]["rap"] = rap_v
                by_name[low]["cosmic"] = rap_v
                by_name[low]["credit_75"] = int(rap_v * 0.75)
            continue
        if "huge" not in low and "titanic" not in low:
            continue
        tier = "titanic" if "titanic" in low else "huge"
        by_name[low] = {
            "id": re.sub(r"[^a-z0-9]+", "_", low).strip("_"),
            "name": name,
            "tier": tier,
            "rap": rap_v,
            "cosmic": rap_v,
            "credit_75": int(rap_v * 0.75),
            "image": "",
            "accepted": True,
        }

    pets = sorted(by_name.values(), key=lambda x: (-x["rap"], x["name"]))
    out = {
        "pets": pets,
        "deposit_rate": 0.75,
        "win_pet_gem_rate": 0.925,
        "source": "biggamesapi.io collection/Pets + rap (complete Huge+Titanic)",
        "updated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    DB_PATH.write_text(json.dumps(out, indent=2))
    WL_PATH.write_text(json.dumps([p["name"] for p in pets], indent=2))
    h = sum(1 for p in pets if p["tier"] == "huge")
    t = sum(1 for p in pets if p["tier"] == "titanic")
    print(f"Synced {len(pets)} pets ({h} huges, {t} titanics) — RAP>0: {sum(1 for p in pets if p['rap']>0)}")

if __name__ == "__main__":
    main()
