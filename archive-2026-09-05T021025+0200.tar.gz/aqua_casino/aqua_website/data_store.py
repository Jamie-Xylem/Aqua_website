"""
Shared data layer — same casino_data.json as Discord bot.
"""
import json
import os
import random
import re
import time
import threading
from pathlib import Path

_lock = threading.RLock()

_ROOT = Path(__file__).resolve().parent.parent
DATA_FILE = Path(os.environ.get("CASINO_DATA_FILE", str(_ROOT / "casino_data.json")))

DEFAULT_DATA = {
    "users": {},
    "verification": {},
    "tickets": {},
    "affiliates": {},
    "global_stats": {
        "total_deposits": 0,
        "total_withdraws": 0,
        "bot_game_profit": 0,
    },
    "settings": {
        "paused": False,
        "active_deposit_bonus": None,
    },
    "website_codes": {},
    "website_verify_pending": {},
    "website_chat": [],
    "admin_chat": [],
    "admins": {},
    "website_pending_deposits": {},
    "website_pending_withdraws": {},
    "blacklist": [],
    "whitelist": [],
    "coinflip_games": {},
    "roulette_round": {},
    "roulette_history": [],
    "active_rains": {},
    "rain_history": [],
}


def _load():
    if DATA_FILE.exists():
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                data = DEFAULT_DATA.copy()
        except Exception:
            data = DEFAULT_DATA.copy()
    else:
        data = DEFAULT_DATA.copy()
        DATA_FILE.parent.mkdir(parents=True, exist_ok=True)

    for k, v in DEFAULT_DATA.items():
        if k not in data:
            data[k] = v.copy() if isinstance(v, dict) else (v[:] if isinstance(v, list) else v)
    data.setdefault("users", {})
    data.setdefault("website_chat", [])
    data.setdefault("admin_chat", [])
    data.setdefault("coinflip_games", {})
    data.setdefault("roulette_round", {})
    data.setdefault("roulette_history", [])
    data.setdefault("active_rains", {})
    data.setdefault("rain_history", [])
    data.setdefault("website_pending_deposits", {})
    data.setdefault("website_pending_withdraws", {})
    return data


def save_data(data):
    with _lock:
        tmp = str(DATA_FILE) + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        os.replace(tmp, DATA_FILE)


def get_data():
    with _lock:
        return _load()


def ensure_user(user_id, data=None):
    if data is None:
        data = get_data()
    uid = str(user_id)
    if uid not in data["users"]:
        data["users"][uid] = {
            "balance": 0,
            "wagered": 0,
            "deposited": 0,
            "withdrawn": 0,
            "to_wager": 0,
            "history": [],
            "roblox": None,
            "roblox_id": None,
            "discord_id": None,
            "discord_name": None,
            "codes": [],
            "affiliate_code": f"REF-{random.randint(1000, 9999)}",
            "referred_by": None,
            "referred_users": [],
            "chips": 0,
            "avatar": None,
            "display_name": None,
            "name_color": "#2ee6d6",
            "text_color": "#e8ecf4",
            "avatar_border": "none",
            "custom_pfp": None,
            "rakeback_pending": 0,
            "rakeback_claimed": {},
            "wagered_hour": 0,
            "wagered_day": 0,
            "wagered_week": 0,
            "wagered_month": 0,
            "rb_period_start": {},
        }
    u = data["users"][uid]
    for k, v in {
        "deposited": 0, "withdrawn": 0, "to_wager": 0, "history": [],
        "codes": [], "chips": 0, "roblox": None, "roblox_id": None,
        "discord_id": None, "discord_name": None, "avatar": None,
        "display_name": None, "name_color": "#2ee6d6", "text_color": "#e8ecf4",
        "avatar_border": "none", "custom_pfp": None,
        "rakeback_pending": 0, "rakeback_claimed": {},
        "wagered_hour": 0, "wagered_day": 0, "wagered_week": 0, "wagered_month": 0,
        "rb_period_start": {},
    }.items():
        u.setdefault(k, v)
    return u


def user_level(wagered: int) -> dict:
    """Level from total wagered. Level N needs ~N^2 * 50M."""
    w = int(wagered or 0)
    level = 1
    while True:
        need = level * level * 50_000_000
        if w < need:
            break
        level += 1
        if level > 500:
            break
    prev = (level - 1) * (level - 1) * 50_000_000
    cur_need = level * level * 50_000_000
    progress = 0 if cur_need == prev else min(1.0, (w - prev) / (cur_need - prev))
    return {"level": level, "progress": progress, "next_at": cur_need, "wagered": w}


def find_user_by_roblox_id(roblox_id, data=None):
    if data is None:
        data = get_data()
    rid = str(roblox_id)
    for uid, u in data["users"].items():
        if str(u.get("roblox_id") or "") == rid:
            return uid, u
    return None, None


def find_user_by_roblox_name(name, data=None):
    if data is None:
        data = get_data()
    name_l = (name or "").lower().strip()
    for uid, u in data["users"].items():
        if (u.get("roblox") or "").lower() == name_l:
            return uid, u
    return None, None


def find_user_by_discord_id(discord_id, data=None):
    if data is None:
        data = get_data()
    did = str(discord_id)
    for uid, u in data["users"].items():
        if str(u.get("discord_id") or "") == did:
            return uid, u
    return None, None


def parse_amount(amount_str: str):
    if not isinstance(amount_str, str):
        return None
    amount_str = amount_str.lower().strip().replace(",", "").replace(" ", "")
    match = re.match(r"^(\d+(?:\.\d+)?)([kmbt])?$", amount_str)
    if not match:
        try:
            return int(float(amount_str))
        except ValueError:
            return None
    val, mult = match.groups()
    val = float(val)
    multipliers = {None: 1, "k": 1_000, "m": 1_000_000, "b": 1_000_000_000, "t": 1_000_000_000_000}
    val *= multipliers.get(mult, 1)
    return int(val)


def format_amount(amount) -> str:
    amount = int(amount or 0)
    sign = "-" if amount < 0 else ""
    amount = abs(amount)
    if amount >= 1_000_000_000_000:
        val = amount / 1_000_000_000_000
        return f"{sign}{val:.2f}".rstrip("0").rstrip(".") + "T"
    if amount >= 1_000_000_000:
        val = amount / 1_000_000_000
        return f"{sign}{val:.2f}".rstrip("0").rstrip(".") + "B"
    if amount >= 1_000_000:
        val = amount / 1_000_000
        return f"{sign}{val:.2f}".rstrip("0").rstrip(".") + "M"
    if amount >= 1_000:
        val = amount / 1_000
        return f"{sign}{val:.2f}".rstrip("0").rstrip(".") + "K"
    return f"{sign}{amount}"


def add_history(user_id, game, amount, result, data=None):
    if data is None:
        data = get_data()
    user = ensure_user(user_id, data)
    user["history"].append({
        "game": game,
        "amount": amount,
        "result": result,
        "time": int(time.time()),
    })
    user["history"] = user["history"][-100:]
