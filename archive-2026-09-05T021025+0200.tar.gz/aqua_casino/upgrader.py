"""Aqua Gems Casino — Upgrader game."""
import discord
from discord import app_commands
from discord.ext import commands, tasks
import aiohttp
import asyncio
import json
import math
import os
import random
import re
import time
import uuid
from datetime import datetime, timezone

from bot_instance import bot, tree, game_cooldown
from config import *
from data import DATA, save_data, ensure_user, add_history, parse_amount, parse_signed_amount, format_amount
from utils import (
    is_staff, is_verified, verification_check, normal_embed,
    get_live_profit_embed, send_log, update_milestone_roles,
    game_paused, get_user_rank_mention,
)


# ============================================================
# UPGRADER CONFIG
# ============================================================

UPGRADER_MULTIPLIERS = {
    1.60: 60.0,
    1.70: 54.1,
    1.80: 50.0,
    2.00: 45.0,
    2.50: 35.0,
    3.00: 28.0,
    4.00: 20.0,
    5.00: 15.0,
}


def get_valid_multipliers():
    return {
        float(multiplier): float(chance)
        for multiplier, chance in UPGRADER_MULTIPLIERS.items()
        if float(multiplier) > 1.5
        and 0 < float(chance) <= 100
    }


# ============================================================
# GAME VIEW
# ============================================================

class UpgraderView(discord.ui.View):

    def __init__(self, user_id: int, bet: int, multiplier: float):
        super().__init__(timeout=120)

        self.user_id = user_id
        self.bet = bet
        self.multiplier = multiplier
        self.finished = False

        valid = get_valid_multipliers()
        self.win_chance = valid.get(multiplier)

    def game_embed(self):
        potential = int(self.bet * self.multiplier)

        embed = discord.Embed(
            title="💎 Aqua Gems",
            description="Upgrader",
            colour=discord.Colour.from_rgb(0, 170, 255),
        )

        embed.add_field(
            name="💎 Bet",
            value=f"{format_amount(self.bet)}",
            inline=True,
        )

        embed.add_field(
            name="⭐ Multiplier",
            value=f"×{self.multiplier:.2f}",
            inline=True,
        )

        embed.add_field(
            name="🍀 Win Chance",
            value=f"{self.win_chance:.1f}%",
            inline=True,
        )

        embed.add_field(
            name="💰 Potential",
            value=f"{format_amount(potential)}",
            inline=False,
        )

        embed.set_footer(text="Aqua Gems • Upgrader")

        return embed

    async def interaction_check(self, interaction: discord.Interaction):

        if interaction.user.id != self.user_id:
            await interaction.response.send_message(
                "❌ This upgrader belongs to someone else.",
                ephemeral=True,
            )
            return False

        if self.finished:
            await interaction.response.send_message(
                "❌ This game has already finished.",
                ephemeral=True,
            )
            return False

        return True

    @discord.ui.button(
        label="Upgrade",
        emoji="💎",
        style=discord.ButtonStyle.primary,
    )
    async def upgrade(
        self,
        interaction: discord.Interaction,
        button: discord.ui.Button,
    ):

        self.finished = True

        for child in self.children:
            child.disabled = True

        # -------------------------------
        # START
        # -------------------------------

        await interaction.response.edit_message(
            embed=discord.Embed(
                title="💎 Aqua Gems",
                description=(
                    "## ⬆️ Upgrading...\n\n"
                    f"💎 **Bet:** {format_amount(self.bet)}\n"
                    f"⭐ **Multiplier:** ×{self.multiplier:.2f}\n\n"
                    "🎰 Rolling..."
                ),
                colour=discord.Colour.from_rgb(0, 170, 255),
            ),
            view=self,
        )

        await asyncio.sleep(1)

        # Visual-only result.
        won = random.random() <= (self.win_chance / 100)

        if won:
            result = discord.Embed(
                title="💎 Aqua Gems",
                description=(
                    "## 🟢 UPGRADE SUCCESSFUL!\n\n"
                    f"💎 **Bet:** {format_amount(self.bet)}\n"
                    f"⭐ **Multiplier:** ×{self.multiplier:.2f}\n"
                    f"🍀 **Chance:** {self.win_chance:.1f}%\n\n"
                    "✨ **WIN!**"
                ),
                colour=discord.Colour.green(),
            )
        else:
            result = discord.Embed(
                title="💎 Aqua Gems",
                description=(
                    "## 🔴 UPGRADE FAILED\n\n"
                    f"💎 **Bet:** {format_amount(self.bet)}\n"
                    f"⭐ **Multiplier:** ×{self.multiplier:.2f}\n"
                    f"🍀 **Chance:** {self.win_chance:.1f}%\n\n"
                    "💥 **LOSS!**"
                ),
                colour=discord.Colour.red(),
            )

        result